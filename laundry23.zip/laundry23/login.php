<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

$settings = [
    'site_name' => 'Laundry Co.',
    'logo' => '',
    'sidebar_color' => '#667eea'
];

$settingsFile = __DIR__ . '/includes/settings.php';
if (file_exists($settingsFile)) {
    $loaded = include $settingsFile;
    if (is_array($loaded)) {
        $settings = array_merge($settings, $loaded);
    }
}

$themeColor = isset($settings['sidebar_color']) && $settings['sidebar_color'] ? $settings['sidebar_color'] : '#667eea';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($auth->login($_POST['username'], $_POST['password'])) {
        header('Location: pages/dashboard.php');
        exit();
    } else {
        $error = 'Invalid username or password';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo htmlspecialchars($settings['site_name']); ?> POS</title>
    <?php
    // Dynamic favicon using settings logo or newest logo_* file
    $logoRaw = $settings['logo'] ?? '';
    $normalized = preg_replace('#^\.\./(uploads/.*)$#','$1',$logoRaw); // strip leading ../ if present
    $checkPath = $normalized;
    $absLogo = $checkPath ? realpath(__DIR__ . '/' . ltrim(str_replace(['../','./'],'', $checkPath), '/')) : false;
    if (!$absLogo || !is_file($absLogo)) {
        // Try auto-detect newest logo_* file
        $candDir = realpath(__DIR__ . '/uploads');
        if ($candDir) {
            $cands = glob($candDir . '/logo_*.*');
            if ($cands) { usort($cands, fn($a,$b)=>filemtime($b)<=>filemtime($a)); $absLogo = $cands[0]; $normalized = 'uploads/' . basename($absLogo); }
        }
    }
    $faviconPath = $normalized && $absLogo && is_file($absLogo) ? $normalized : 'uploads/wash_and_fold.jpg';
    if ($absLogo && is_file($absLogo)) { $mtime = @filemtime($absLogo); if ($mtime) { $faviconPath .= (strpos($faviconPath,'?')===false?'?v=':'&v=') . $mtime; } }
    ?>
    <link rel="icon" type="image/png" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link rel="apple-touch-icon" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            background: <?php echo htmlspecialchars($themeColor); ?>;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
        }
        .login-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 400px;
            padding: 40px;
            box-sizing: border-box;
        }
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .brand-logo {
            width: 110px;
            height: 110px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid rgba(102, 126, 234, 0.2);
            background: #fff;
            display: block;
            margin: 0 auto 12px auto;
        }
        .brand-icon {
            font-size: 58px;
            margin-bottom: 12px;
        }
        .login-header h1 {
            color: <?php echo htmlspecialchars($themeColor); ?>;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .form-control:focus {
            border-color: <?php echo htmlspecialchars($themeColor); ?>;
            box-shadow: 0 0 0 0.2rem rgba(102,126,234,0.25);
        }
        .btn-login {
            background: <?php echo htmlspecialchars($themeColor); ?>;
            border: none;
            padding: 10px 20px;
            font-weight: bold;
        }
        .btn-login:hover {
            filter: brightness(0.9);
            color: #fff;
        }
        .alert {
            margin-bottom: 20px;
        }

        /* Mobile-first tweaks */
        @media (max-width: 575.98px) {
            body {
                padding: 16px;
                align-items: flex-start;
            }
            .login-container {
                margin-top: 24px;
                padding: 24px 18px;
                max-height: calc(100vh - 48px);
                overflow-y: auto;
            }
            .brand-icon {
                font-size: 44px;
            }
            .login-header h1 {
                font-size: 1.5rem;
            }
        }

        /* Tablets */
        @media (min-width: 576px) and (max-width: 991.98px) {
            body {
                padding: 24px;
            }
            .login-container {
                padding: 32px 28px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <?php if (!empty($settings['logo'])): ?>
                <img src="<?php echo htmlspecialchars($settings['logo']); ?>" alt="<?php echo htmlspecialchars($settings['site_name']); ?> logo" class="brand-logo">
            <?php else: ?>
                <div class="brand-icon">🧺</div>
            <?php endif; ?>
            <h1><?php echo htmlspecialchars($settings['site_name']); ?></h1>
            <p class="text-muted">POS System</p>
        </div>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-login w-100">Login</button>
        </form>

        <hr class="my-3">
        <p class="text-center text-muted small">
            <strong>Demo Credentials:</strong><br>
            Username: <code>admin</code><br>
            Password: <code>admin123</code>
        </p>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

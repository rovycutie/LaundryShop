<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

ensureReservationPaymentsTable($conn);

// Ensure services table has image column for per-service images
try {
    $colCheck = $conn->query("SHOW COLUMNS FROM services LIKE 'image'");
    if ($colCheck && $colCheck->num_rows === 0) {
        $conn->query("ALTER TABLE services ADD COLUMN image VARCHAR(255) DEFAULT NULL AFTER description");
    }
} catch (Exception $e) {
    // Silently ignore; column addition not critical for other actions
}

$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? sanitize($_GET['action']) : '';

// Create reservation
if ($method === 'POST' && $action === 'create_reservation') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $first_name = sanitize($data['first_name']);
    $last_name = sanitize($data['last_name']);
    // Email optional: gracefully handle missing or empty
    $email = isset($data['email']) && trim($data['email']) !== '' ? sanitize($data['email']) : '';
    $phone = sanitize($data['phone']);
    $reserved_date = sanitize($data['reserved_date']);
    $reserved_time = sanitize($data['reserved_time']);
    $service_id = (int)$data['service_id'];
    $weight_kg = (float)($data['weight_kg'] ?? 0); // allow 0 if not provided
    $special_requests = sanitize($data['special_requests'] ?? '');
    
    // Calculate estimated cost
    $service = $conn->query("SELECT * FROM services WHERE id = $service_id")->fetch_assoc();
    $estimated_cost = $service['base_price'] + ($weight_kg * $service['price_per_kg']);
    
    // Save customer
    $customer_id = saveCustomer($conn, $first_name, $last_name, $email, $phone);
    
    // Create reservation
    $reservation_number = generateReservationNumber();
    
    $query = "INSERT INTO reservations (reservation_number, customer_id, first_name, last_name, email, phone, 
              reserved_date, reserved_time, service_id, weight_kg, estimated_cost, special_requests, status) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')"; // reverted to 'pending'
    $stmt = $conn->prepare($query);
    // Types: reservation_number(s), customer_id(i), first_name(s), last_name(s), email(s), phone(s),
    // reserved_date(s), reserved_time(s), service_id(i), weight_kg(d), estimated_cost(d), special_requests(s)
    $stmt->bind_param("sissssssidds", $reservation_number, $customer_id, $first_name, $last_name, $email, $phone, 
                      $reserved_date, $reserved_time, $service_id, $weight_kg, $estimated_cost, $special_requests);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'reservation_id' => $conn->insert_id, 'reservation_number' => $reservation_number]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to create reservation']);
    }
}

// Get reservations
elseif ($method === 'GET' && $action === 'get_reservations') {
    $status = isset($_GET['status']) ? sanitize($_GET['status']) : '';
    // Map UI status 'processing' to legacy DB value 'confirmed' if DB still uses that enum
    $status_db = $status === 'processing' ? 'confirmed' : $status;

    $query = "SELECT r.*, s.name as service_name, COALESCE(rp.paid_amount, 0) AS paid_amount
              FROM reservations r 
              JOIN services s ON r.service_id = s.id
              LEFT JOIN (
                    SELECT reservation_id, SUM(amount) AS paid_amount
                    FROM reservation_payments
                    GROUP BY reservation_id
              ) rp ON rp.reservation_id = r.id";

    if ($status_db) {
        $query .= " WHERE r.status = '$status_db'";
    }

    $query .= " ORDER BY r.reserved_date ASC, r.reserved_time ASC";
    $result = $conn->query($query);
    $reservations = $result->fetch_all(MYSQLI_ASSOC);

    foreach ($reservations as &$reservation) {
        $estimated = (float)($reservation['estimated_cost'] ?? 0);
        $paid = (float)($reservation['paid_amount'] ?? 0);
        $outstanding = max(0, $estimated - $paid);
        $reservation['paid_amount'] = $paid;
        $reservation['outstanding_amount'] = $outstanding;
        if ($estimated <= 0 && $paid <= 0) {
            $reservation['payment_status'] = 'unpaid';
        } elseif ($outstanding <= 0) {
            $reservation['payment_status'] = 'paid';
        } else {
            $reservation['payment_status'] = $paid > 0 ? 'partial' : 'unpaid';
        }
    }
    unset($reservation);
    
    echo json_encode(['success' => true, 'reservations' => $reservations]);
}

// Update reservation status
elseif ($method === 'POST' && $action === 'update_reservation_status') {
    $data = json_decode(file_get_contents('php://input'), true);
    $reservation_id = (int)$data['reservation_id'];
    $status = sanitize($data['status']);
    // If DB still uses 'confirmed' enum, map incoming 'processing' to 'confirmed'
    $status_db = $status === 'processing' ? 'confirmed' : $status;

    $query = "UPDATE reservations SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $status_db, $reservation_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Reservation status updated']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to update reservation']);
    }
}

// Record reservation payment
elseif ($method === 'POST' && $action === 'record_reservation_payment') {
    $data = json_decode(file_get_contents('php://input'), true);
    $reservation_id = (int)($data['reservation_id'] ?? 0);
    $amount = (float)($data['amount'] ?? 0);
    $methodInput = strtolower(trim($data['payment_method'] ?? 'cash'));
    $notes = trim($data['notes'] ?? '');
    $weightInput = isset($data['weight_kg']) ? (float)$data['weight_kg'] : null;

    $allowedMethods = ['cash', 'card', 'online'];
    $payment_method = in_array($methodInput, $allowedMethods, true) ? $methodInput : 'cash';

    if ($reservation_id <= 0 || $amount <= 0) {
        echo json_encode(['success' => false, 'error' => 'Invalid reservation or amount']);
        exit;
    }

    $stmt = $conn->prepare("SELECT r.estimated_cost, r.weight_kg, s.base_price, s.price_per_kg FROM reservations r JOIN services s ON r.service_id = s.id WHERE r.id = ?");
    $stmt->bind_param('i', $reservation_id);
    $stmt->execute();
    $reservation = $stmt->get_result()->fetch_assoc();

    if (!$reservation) {
        echo json_encode(['success' => false, 'error' => 'Reservation not found']);
        exit;
    }

    $updatedEstimatedCost = (float)$reservation['estimated_cost'];
    $updatedWeight = $reservation['weight_kg'];
    if ($weightInput !== null && $weightInput >= 0) {
        $base = (float)($reservation['base_price'] ?? 0);
        $perKg = (float)($reservation['price_per_kg'] ?? 0);
        $updatedWeight = $weightInput;
        $updatedEstimatedCost = round($base + ($updatedWeight * $perKg), 2);
        $updateStmt = $conn->prepare("UPDATE reservations SET weight_kg = ?, estimated_cost = ? WHERE id = ?");
        $updateStmt->bind_param('ddi', $updatedWeight, $updatedEstimatedCost, $reservation_id);
        $updateStmt->execute();
    }

    $insert = $conn->prepare("INSERT INTO reservation_payments (reservation_id, amount, payment_method, notes) VALUES (?, ?, ?, ?)");
    $insert->bind_param('idss', $reservation_id, $amount, $payment_method, $notes);

    if (!$insert->execute()) {
        echo json_encode(['success' => false, 'error' => 'Failed to record payment']);
        exit;
    }

    $totalStmt = $conn->prepare("SELECT SUM(amount) as total_paid FROM reservation_payments WHERE reservation_id = ?");
    $totalStmt->bind_param('i', $reservation_id);
    $totalStmt->execute();
    $totals = $totalStmt->get_result()->fetch_assoc();
    $paid = (float)($totals['total_paid'] ?? 0);
    $outstanding = max(0, $updatedEstimatedCost - $paid);

    // Determine payment status for convenience
    $payment_status = 'unpaid';
    if ($updatedEstimatedCost <= 0 && $paid <= 0) {
        $payment_status = 'unpaid';
    } elseif ($outstanding <= 0) {
        $payment_status = 'paid';
    } else {
        $payment_status = $paid > 0 ? 'partial' : 'unpaid';
    }

    echo json_encode([
        'success' => true,
        'message' => 'Payment recorded',
        'paid' => $paid,
        'outstanding' => $outstanding,
        'estimated_total' => $updatedEstimatedCost,
        'weight_kg' => $updatedWeight,
        'total_paid' => $paid,
        'total_amount' => $updatedEstimatedCost,
        'payment_status' => $payment_status
    ]);
}

// Get single reservation details (including payments) for receipt printing
elseif ($method === 'GET' && $action === 'get_reservation') {
    $reservation_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if ($reservation_id <= 0) {
        echo json_encode(['success' => false, 'error' => 'Invalid reservation id']);
        exit;
    }

    $stmt = $conn->prepare("SELECT r.*, s.name as service_name, s.base_price, s.price_per_kg
                             FROM reservations r
                             JOIN services s ON r.service_id = s.id
                             WHERE r.id = ?");
    $stmt->bind_param('i', $reservation_id);
    $stmt->execute();
    $reservation = $stmt->get_result()->fetch_assoc();
    if (!$reservation) {
        echo json_encode(['success' => false, 'error' => 'Reservation not found']);
        exit;
    }

    // Payments
    $pay = $conn->prepare("SELECT * FROM reservation_payments WHERE reservation_id = ? ORDER BY payment_date ASC");
    $pay->bind_param('i', $reservation_id);
    $pay->execute();
    $payments = $pay->get_result()->fetch_all(MYSQLI_ASSOC);

    // Compute totals
    $paid = 0;
    foreach ($payments as $p) { $paid += (float)$p['amount']; }
    $estimated = (float)($reservation['estimated_cost'] ?? 0);
    $outstanding = max(0, $estimated - $paid);
    $reservation['paid_amount'] = $paid;
    $reservation['outstanding_amount'] = $outstanding;
    // Add unified naming for front-end JS parity with orders
    $reservation['total_paid'] = $paid;
    $reservation['total_amount'] = $estimated;
    if ($estimated <= 0 && $paid <= 0) {
        $reservation['payment_status'] = 'unpaid';
    } elseif ($outstanding <= 0) {
        $reservation['payment_status'] = 'paid';
    } else {
        $reservation['payment_status'] = $paid > 0 ? 'partial' : 'unpaid';
    }

    echo json_encode([
        'success' => true,
        'reservation' => $reservation,
        'payments' => $payments
    ]);
}

// Get available time slots
elseif ($method === 'GET' && $action === 'get_time_slots') {
    $reserved_date = sanitize($_GET['date']);
    
    // Get all reservations for the date
    $result = $conn->query("SELECT reserved_time FROM reservations WHERE reserved_date = '$reserved_date' AND status != 'cancelled'");
    $booked_times = [];
    while ($row = $result->fetch_assoc()) {
        $booked_times[] = $row['reserved_time'];
    }
    
    // Generate available slots (30-minute intervals)
    $available_slots = [];
    $start = strtotime('08:00');
    $end = strtotime('18:00');
    $interval = 30 * 60;
    
    for ($time = $start; $time <= $end; $time += $interval) {
        $time_str = date('H:i', $time);
        if (!in_array($time_str, $booked_times)) {
            $available_slots[] = $time_str;
        }
    }
    
    echo json_encode(['success' => true, 'slots' => $available_slots]);
}

// Get services (active only by default; admin can request inactive via includeInactive=1)
elseif ($method === 'GET' && $action === 'get_services') {
    $includeInactive = !empty($_GET['includeInactive']);
    $services = getServices($conn, $includeInactive);
    echo json_encode(['success' => true, 'services' => $services]);
}

// Unified create/update with optional image upload (multipart/form-data)
elseif ($method === 'POST' && $action === 'save_service') {
    // Distinguish JSON vs multipart
    $isJson = stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false;
    if ($isJson) {
        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $files = [];
    } else {
        $data = $_POST;
        $files = $_FILES;
    }

    $id = isset($data['id']) ? (int)$data['id'] : 0;
    $name = sanitize($data['name'] ?? '');
    $description = sanitize($data['description'] ?? '');
    $price_per_kg = (float)($data['price_per_kg'] ?? 0);
    $base_price = (float)($data['base_price'] ?? 0);
    $turnaround_hours = (int)($data['turnaround_hours'] ?? 24);
    $is_active = (isset($data['is_active']) && ($data['is_active'] === '0' || $data['is_active'] === 0)) ? 0 : 1;
    $delete_image = isset($data['delete_image']) && $data['delete_image'] == '1';
    $imagePath = null;

    // Handle upload if provided
    if (isset($files['image']) && $files['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        if ($files['image']['error'] === UPLOAD_ERR_OK) {
            $allowed = ['png','jpg','jpeg','gif','webp','svg'];
            $ext = strtolower(pathinfo($files['image']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $allowed, true)) {
                echo json_encode(['success' => false, 'error' => 'Unsupported image type']);
                exit;
            }
            $uploadDir = __DIR__ . '/../uploads/';
            if (!is_dir($uploadDir)) { mkdir($uploadDir, 0777, true); }
            $destName = 'service_' . time() . '_' . mt_rand(1000,9999) . '.' . $ext;
            $destPath = $uploadDir . $destName;
            if (move_uploaded_file($files['image']['tmp_name'], $destPath)) {
                $imagePath = '../uploads/' . $destName; // relative path for front-end usage
            } else {
                echo json_encode(['success' => false, 'error' => 'Failed to move uploaded file']);
                exit;
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'Image upload error code ' . $files['image']['error']]);
            exit;
        }
    }

    if ($id === 0) {
        // Create
        $query = "INSERT INTO services (name, description, price_per_kg, base_price, turnaround_hours, is_active, image) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('ssddiis', $name, $description, $price_per_kg, $base_price, $turnaround_hours, $is_active, $imagePath);
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'service_id' => $conn->insert_id, 'image' => $imagePath]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to create service', 'db_error' => $stmt->error]);
        }
    } else {
        // Update existing
        // If need to delete existing image
        if ($delete_image) {
            $old = $conn->query("SELECT image FROM services WHERE id = $id");
            if ($old && $oldRow = $old->fetch_assoc()) {
                $oldPath = $oldRow['image'];
                if ($oldPath && strpos($oldPath, '../uploads/') === 0) {
                    $fsPath = __DIR__ . '/../' . substr($oldPath, 3); // convert ../uploads/... to path
                    if (file_exists($fsPath)) { @unlink($fsPath); }
                }
            }
            $imagePath = null; // clear
        } else if ($imagePath === null) {
            // Keep previous image if not replaced
            $prev = $conn->query("SELECT image FROM services WHERE id = $id");
            if ($prev && $prevRow = $prev->fetch_assoc()) { $imagePath = $prevRow['image']; }
        }
        $query = "UPDATE services SET name = ?, description = ?, price_per_kg = ?, base_price = ?, turnaround_hours = ?, is_active = ?, image = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('ssddiisi', $name, $description, $price_per_kg, $base_price, $turnaround_hours, $is_active, $imagePath, $id);
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'service_id' => $id, 'image' => $imagePath]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to update service', 'db_error' => $stmt->error]);
        }
    }
}

// Delete (or deactivate) service
elseif ($method === 'POST' && $action === 'delete_service') {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = (int)($data['id'] ?? 0);
    // Soft-delete by setting is_active = 0
    $query = "UPDATE services SET is_active = 0 WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to delete service', 'db_error' => $stmt->error]);
    }
}

// Toggle service availability
elseif ($method === 'POST' && $action === 'toggle_service_availability') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) {
        echo json_encode(['success' => false, 'error' => 'Invalid JSON body']);
        exit;
    }

    $id = isset($input['id']) ? (int)$input['id'] : 0;
    if ($id <= 0) {
        echo json_encode(['success' => false, 'error' => 'Invalid service id']);
        exit;
    }

    // Flip or explicitly set the new is_active
    $newActive = isset($input['is_active']) ? (int)!empty($input['is_active']) : null;
    if ($newActive === null) {
        // If not provided, read current value and invert
        $stmt = $conn->prepare("SELECT is_active FROM services WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        if (!$res) {
            echo json_encode(['success' => false, 'error' => 'Service not found']);
            exit;
        }
        $newActive = $res['is_active'] ? 0 : 1;
    }

    $stmt = $conn->prepare("UPDATE services SET is_active = ? WHERE id = ?");
    $stmt->bind_param('ii', $newActive, $id);
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'is_active' => (bool)$newActive]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to update service']);
    }
    exit;
}

else {
    echo json_encode(['success' => false, 'error' => 'Invalid action']);
}

<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? sanitize($_GET['action']) : '';

// Create new order
if ($method === 'POST' && $action === 'create_order') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $first_name = sanitize($data['first_name']);
    $last_name = sanitize($data['last_name']);
    $phone = sanitize($data['phone']);
    // Email optional
    $email = isset($data['email']) && trim($data['email']) !== '' ? sanitize($data['email']) : '';
    $items = $data['items']; // Array of items
    $due_hours = $data['due_hours'] ?? 24;
    $notes = sanitize($data['notes'] ?? '');
    $total_amount = $data['total_amount'];
    
    $customer_id = saveCustomer($conn, $first_name, $last_name, $email, $phone);
    
    $order_number = generateOrderNumber();
    $due_date = calculateDueDate($due_hours);
    $user_id = $_SESSION['user_id'] ?? 1;
    
    // Set status to pending (requested behavior)
    $query = "INSERT INTO orders (order_number, customer_id, user_id, status, total_amount, notes, due_date) 
              VALUES (?, ?, ?, 'pending', ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("siidss", $order_number, $customer_id, $user_id, $total_amount, $notes, $due_date);
    
    if ($stmt->execute()) {
        $order_id = $conn->insert_id;
        
        foreach ($items as $item) {
            $service_id = $item['service_id'];
            $quantity = $item['quantity'];
            $unit_price = $item['unit_price'];
            $subtotal = $quantity * $unit_price;
            
            $query = "INSERT INTO order_items (order_id, service_id, quantity, unit_price, subtotal) 
                      VALUES (?, ?, ?, ?, ?)";
            $stmt_item = $conn->prepare($query);
            $stmt_item->bind_param("iiidd", $order_id, $service_id, $quantity, $unit_price, $subtotal);
            if (!$stmt_item->execute()) {
                echo json_encode(['success' => false, 'error' => 'Failed to create order item', 'db_error' => $stmt_item->error]);
                exit;
            }
        }
        
        echo json_encode(['success' => true, 'order_id' => $order_id, 'order_number' => $order_number]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to create order', 'db_error' => $stmt->error]);
    }
}

// Get orders
elseif ($method === 'GET' && $action === 'get_orders') {
    $status = isset($_GET['status']) ? sanitize($_GET['status']) : '';
    $query = "SELECT o.*, CONCAT(c.first_name, ' ', c.last_name) as customer_name, c.phone
              FROM orders o 
              LEFT JOIN customers c ON o.customer_id = c.id";
    if ($status) { $query .= " WHERE o.status = '$status'"; }
    $query .= " ORDER BY o.created_at DESC LIMIT 100";
    $result = $conn->query($query);
    $orders = $result->fetch_all(MYSQLI_ASSOC);
    
    echo json_encode(['success' => true, 'orders' => $orders]);
}

// Update order status
elseif ($method === 'POST' && $action === 'update_order_status') {
    $data = json_decode(file_get_contents('php://input'), true);
    $order_id = (int)$data['order_id'];
    $status = sanitize($data['status']);
    
    $query = "UPDATE orders SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $status, $order_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Order status updated']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to update order']);
    }
}

// Record payment
elseif ($method === 'POST' && $action === 'record_payment') {
    $data = json_decode(file_get_contents('php://input'), true);
    $order_id = (int)$data['order_id'];
    $amount = (float)$data['amount'];
    $payment_method = sanitize($data['payment_method']);
    $notes = sanitize($data['notes'] ?? '');
    
    $query = "INSERT INTO payments (order_id, amount, payment_method, notes) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("idss", $order_id, $amount, $payment_method, $notes);
    
    if ($stmt->execute()) {
        $result = $conn->query("SELECT SUM(amount) as paid FROM payments WHERE order_id = $order_id");
        $paid = $result->fetch_assoc()['paid'];
        $order = $conn->query("SELECT total_amount FROM orders WHERE id = $order_id")->fetch_assoc();
        
        if ($paid >= $order['total_amount']) {
            $conn->query("UPDATE orders SET payment_status = 'paid' WHERE id = $order_id");
        } else {
            $conn->query("UPDATE orders SET payment_status = 'partial' WHERE id = $order_id");
        }
        
        echo json_encode(['success' => true, 'message' => 'Payment recorded']);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to record payment']);
    }
}

// Get order details
elseif ($method === 'GET' && $action === 'get_order') {
    $order_id = (int)$_GET['id'];
    
    $query = "SELECT o.*, CONCAT(c.first_name, ' ', c.last_name) as customer_name, c.phone, c.email
              FROM orders o 
              LEFT JOIN customers c ON o.customer_id = c.id
              WHERE o.id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $order = $stmt->get_result()->fetch_assoc();
    
    $query = "SELECT oi.*, s.name as service_name FROM order_items oi 
              JOIN services s ON oi.service_id = s.id WHERE oi.order_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    $query = "SELECT * FROM payments WHERE order_id = ? ORDER BY payment_date DESC";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $payments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    
    echo json_encode(['success' => true, 'order' => $order, 'items' => $items, 'payments' => $payments]);
}

// Delete order
elseif ($method === 'POST' && $action === 'delete_order') {
    $data = json_decode(file_get_contents('php://input'), true);
    $order_id = (int)$data['order_id'];

    if (!$order_id) {
        echo json_encode(['success' => false, 'error' => 'Invalid order ID']);
        exit;
    }

    try {
        $conn->begin_transaction();

        // Delete order items
        $stmt = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
        $stmt->bind_param("i", $order_id);
        $stmt->execute();

        // Delete payments
        $stmt = $conn->prepare("DELETE FROM payments WHERE order_id = ?");
        $stmt->bind_param("i", $order_id);
        $stmt->execute();

        // Delete the order
        $stmt = $conn->prepare("DELETE FROM orders WHERE id = ?");
        $stmt->bind_param("i", $order_id);
        $stmt->execute();

        $conn->commit();

        echo json_encode(['success' => true, 'message' => 'Order deleted successfully']);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => 'Failed to delete order', 'db_error' => $e->getMessage()]);
    }
}

else {
    echo json_encode(['success' => false, 'error' => 'Invalid action']);
}

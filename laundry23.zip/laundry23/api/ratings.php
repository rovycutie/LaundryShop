<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

// Ensure ratings table exists
$conn->query("CREATE TABLE IF NOT EXISTS ratings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) DEFAULT NULL,
  stars TINYINT NOT NULL,
  comment TEXT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");

$action = $_GET['action'] ?? ($_POST['action'] ?? '');

function jsonOut($arr){ echo json_encode($arr); exit; }

if ($action === 'create') {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data)) { jsonOut(['success'=>false,'error'=>'Invalid JSON']); }
    $stars = (int)($data['stars'] ?? 0);
    $name = trim($data['name'] ?? '');
    $comment = trim($data['comment'] ?? '');
    if ($stars < 1 || $stars > 5) { jsonOut(['success'=>false,'error'=>'Stars must be 1-5']); }
    $stmt = $conn->prepare('INSERT INTO ratings (name, stars, comment) VALUES (?,?,?)');
    $stmt->bind_param('sis', $name, $stars, $comment);
    if ($stmt->execute()) {
        jsonOut(['success'=>true]);
    } else {
        jsonOut(['success'=>false,'error'=>'DB insert failed']);
    }
}

if ($action === 'get_stats') {
    $result = $conn->query('SELECT stars, COUNT(*) c FROM ratings GROUP BY stars');
    $counts = [1=>0,2=>0,3=>0,4=>0,5=>0];
    $total = 0; $sum = 0;
    while ($row = $result->fetch_assoc()) {
        $s = (int)$row['stars'];
        $c = (int)$row['c'];
        if (isset($counts[$s])) { $counts[$s] = $c; $total += $c; $sum += $s * $c; }
    }
    $avg = $total > 0 ? round($sum / $total, 2) : 0;
    jsonOut(['success'=>true,'average'=>$avg,'total'=>$total,'distribution'=>$counts]);
}

// Default fallback
jsonOut(['success'=>false,'error'=>'Unknown action']);
?>
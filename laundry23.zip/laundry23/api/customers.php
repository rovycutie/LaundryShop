<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? sanitize($_GET['action']) : '';

// Get all customers
if ($method === 'GET' && $action === 'get_customers') {
    $query = "SELECT * FROM customers ORDER BY created_at DESC";
    $result = $conn->query($query);
    $customers = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode(['success' => true, 'customers' => $customers]);
}

else {
    echo json_encode(['success' => false, 'error' => 'Invalid action']);
}

<?php
// Simple diagnostic script to check DB connection and services table
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';

$out = ['success' => false];
try {
    if (!isset($conn) || !$conn) {
        throw new Exception('No $conn available from includes/config.php');
    }

    $res = $conn->query("SELECT id, name, base_price, price_per_kg, is_active FROM services");
    if ($res === false) {
        $out['error'] = 'Query failed: ' . $conn->error;
        echo json_encode($out, JSON_PRETTY_PRINT);
        exit;
    }

    $rows = $res->fetch_all(MYSQLI_ASSOC);
    $out['success'] = true;
    $out['count'] = count($rows);
    $out['rows'] = $rows;
} catch (Exception $e) {
    $out['error'] = $e->getMessage();
}

echo json_encode($out, JSON_PRETTY_PRINT);

// Helpful note printed in HTML if opened in browser
if (php_sapi_name() !== 'cli') {
    echo "\n<!-- Open this URL in browser or curl to inspect JSON -->";
}

?>

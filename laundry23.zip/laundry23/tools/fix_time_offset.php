<?php
// Maintenance script: adjust orders and payments timestamps by specified hour offset.
// Usage: browse to tools/fix_time_offset.php?hours=7&dry=1 (dry run) then without dry to apply.
// Default offset guess: 7 hours (difference user reported between actual and stored time).

require_once __DIR__ . '/../includes/config.php';

// Auto-detect suggested offset if hours not provided.
// We compare PHP now (Asia/Manila) vs MIN(created_at) latest order hour to estimate skew.
$hoursParam = isset($_GET['hours']) ? (int)$_GET['hours'] : null;
$dry   = isset($_GET['dry']);

$phpNow = new DateTime('now', new DateTimeZone('Asia/Manila'));
$phpHour = (int)$phpNow->format('H');
$latest = $conn->query("SELECT created_at FROM orders ORDER BY id DESC LIMIT 1");
$latestRow = $latest && $latest->num_rows ? $latest->fetch_assoc() : null;
$latestHour = null;
if ($latestRow && !empty($latestRow['created_at'])) {
    $latestDt = DateTime::createFromFormat('Y-m-d H:i:s', $latestRow['created_at'], new DateTimeZone('Asia/Manila'));
    if ($latestDt) { $latestHour = (int)$latestDt->format('H'); }
}

// If there is a latest order and hour difference seems >2h, propose offset.
$suggested = 0;
if ($latestHour !== null) {
    $diff = $phpHour - $latestHour; // e.g. 15 - 7 = 8
    // We want a positive offset to push stored times forward to match now
    if (abs($diff) >= 2) { $suggested = $diff; }
}

$hours = ($hoursParam !== null) ? $hoursParam : ($suggested !== 0 ? $suggested : 0);
header('Content-Type: text/plain; charset=utf-8');

echo "Timezone: " . date_default_timezone_get() . "\n";

echo "PHP current time: " . $phpNow->format('Y-m-d H:i:s') . " (hour=$phpHour)\n";
echo "Latest order hour: " . ($latestHour !== null ? $latestHour : 'n/a') . "\n";
echo "Requested/Resolved offset: +{$hours} hours\n";
if ($hoursParam === null) {
    echo "(Auto-detected diff: $suggested hours)\n";
}
if ($dry) echo "DRY RUN ONLY (no changes applied)\n";

// Preview counts
$orders = $conn->query("SELECT COUNT(*) AS c FROM orders")->fetch_assoc()['c'] ?? 0;
$payments = $conn->query("SELECT COUNT(*) AS c FROM payments")->fetch_assoc()['c'] ?? 0;
$reservations = $conn->query("SELECT COUNT(*) AS c FROM reservations")->fetch_assoc()['c'] ?? 0;

echo "Records -> orders: $orders, payments: $payments, reservations: $reservations\n";

if ($hours === 0) {
    echo "Offset resolved to 0; pass ?hours=8 to force, or ?hours=8&dry=1 first.\n";
    exit;
}

function runAdjust($conn, $table, $cols, $hours, $dry) {
    foreach ($cols as $col) {
        $sql = "UPDATE $table SET $col = DATE_ADD($col, INTERVAL $hours HOUR)";
        if ($dry) {
            echo "Would run: $sql\n";
        } else {
            if ($conn->query($sql)) {
                echo "Adjusted $table.$col by +$hours hours\n";
            } else {
                echo "ERROR adjusting $table.$col: " . $conn->error . "\n";
            }
        }
    }
}

runAdjust($conn, 'orders', ['created_at','updated_at','due_date'], $hours, $dry);
runAdjust($conn, 'payments', ['payment_date','created_at'], $hours, $dry);
runAdjust($conn, 'reservations', ['created_at','updated_at','reserved_date','reserved_time'], $hours, $dry);

echo $dry ? "Dry run complete. Remove &dry=1 to apply.\n" : "Adjustment complete.\n";

<?php
// Always show landing page first, even if already logged in.
// Users can navigate to login or dashboard from links on landing.
session_start();
header('Location: public/landing.php');
exit();

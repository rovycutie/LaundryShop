// Reservations JavaScript (renders into kanban columns like walk_in_orders)
const statusFilter = document.getElementById('statusFilter');
const searchInput = document.getElementById('searchInput');
const dateFromInput = document.getElementById('dateFrom');
const dateToInput = document.getElementById('dateTo');
const serviceFilter = document.getElementById('serviceFilter');
const updateStatusModal = new bootstrap.Modal(document.getElementById('updateStatusModal'));
let currentReservationId = null;
let pendingHighlightTicket = null; // ticket number to visually highlight after reload

// Ensure a toast helper exists (reuse pattern from walk_in_orders)
if (typeof window.showToast !== 'function') {
    function showToast(message, type = 'info', timeout = 3500) {
        let container = document.getElementById('toastContainer');
        if (!container) {
            container = document.createElement('div');
            container.id = 'toastContainer';
            container.className = 'position-fixed top-0 end-0 p-3';
            container.style.zIndex = 1060;
            document.body.appendChild(container);
        }
        if (typeof window.bootstrap === 'undefined') {
            const el = document.createElement('div');
            el.textContent = message;
            el.style.background = (type === 'success' ? '#198754' : (type === 'danger' ? '#dc3545' : '#0d6efd'));
            el.style.color = '#fff';
            el.style.padding = '10px 14px';
            el.style.borderRadius = '8px';
            el.style.marginTop = '8px';
            el.style.boxShadow = '0 6px 18px rgba(0,0,0,0.12)';
            el.style.fontFamily = 'system-ui, Arial, sans-serif';
            el.style.opacity = '1';
            container.appendChild(el);
            setTimeout(() => { el.style.transition = 'opacity 300ms'; el.style.opacity = '0'; setTimeout(()=>el.remove(), 350); }, timeout);
            return;
        }
        const toastEl = document.createElement('div');
        toastEl.className = 'toast align-items-center text-bg-' + (type === 'danger' ? 'danger' : (type === 'success' ? 'success' : 'info')) + ' border-0 show';
        toastEl.setAttribute('role','alert');
        toastEl.setAttribute('aria-live','assertive');
        toastEl.setAttribute('aria-atomic','true');
        toastEl.style.minWidth = '180px';
        toastEl.innerHTML = '<div class="d-flex">\n <div class="toast-body">' + message + '</div>\n <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>\n</div>';
        container.appendChild(toastEl);
        try { const bsToast = new bootstrap.Toast(toastEl, { delay: timeout }); bsToast.show(); toastEl.addEventListener('hidden.bs.toast', () => { try { toastEl.remove(); } catch(e){} }); }
        catch(e){ setTimeout(()=>{ try { toastEl.remove(); } catch(_){} }, timeout + 400); }
    }
    window.showToast = showToast;
}
if (statusFilter) statusFilter.addEventListener('change', loadReservations);
if (searchInput) searchInput.addEventListener('input', debounce(loadReservations, 300));
if (dateFromInput) dateFromInput.addEventListener('change', loadReservations);
if (dateToInput) dateToInput.addEventListener('change', loadReservations);
if (serviceFilter) serviceFilter.addEventListener('change', loadReservations);

async function loadReservations() {
    // fetch reservations then apply client-side filters
    try {
        const response = await fetch('../api/reservations.php?action=get_reservations');
        const data = await response.json();
        console.debug('reservations data:', data);

        if (data.success) {
            // clear columns
            const pendingBody = document.getElementById('pendingBody');
            const processingBody = document.getElementById('processingBody');
            const cancelledBody = document.getElementById('cancelledBody');
            const completedBody = document.getElementById('completedBody');
            pendingBody.innerHTML = '';
            processingBody.innerHTML = '';
            cancelledBody.innerHTML = '';
            completedBody.innerHTML = '';

            if (!data.reservations || data.reservations.length === 0) {
                pendingBody.innerHTML = '<p class="text-muted">No reservations</p>';
                return;
            }
            // apply client-side filters
            let reservations = data.reservations || [];
            reservations = filterReservationsClientSide(reservations);

            let pendingCount = 0, processingCount = 0, cancelledCount = 0, completedCount = 0;

            // Helper to format reservation date/time as 12h with AM/PM without seconds
            function formatReservationDateTime(dateStr, timeStr) {
                if (!dateStr) return '';
                let combined = dateStr.trim();
                if (timeStr) combined += ' ' + timeStr.trim();
                // Expecting YYYY-MM-DD HH:MM:SS for combined
                const m = combined.match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?$/);
                if (!m) return combined; // fallback raw
                const [_, y, mo, d, hh, mm] = m;
                let hr = parseInt(hh || '0',10);
                const ampm = hr >= 12 ? 'PM' : 'AM';
                hr = hr % 12; if (hr === 0) hr = 12;
                return `${mo}/${d}/${y}${hh?`, ${hr}:${mm} ${ampm}`:''}`;
            }

            reservations.forEach(res => {
                const s = res.status;
                // displayStatus maps legacy 'confirmed' -> 'processing' for UI
                const displayStatus = (s === 'confirmed') ? 'processing' : s;
                const dateTimeText = formatReservationDateTime(res.reserved_date, res.reserved_time);

                const card = document.createElement('div');
                card.className = 'kanban-card';
                card.innerHTML = `
                    <div class="card-top">
                        <div class="order-number">${res.reservation_number}</div>
                        <div class="badge small bg-${getBadgeClass(displayStatus)}">${displayStatus.replace('_',' ')}</div>
                    </div>
                    <div class="card-body">
                        <div class="customer"><strong>${res.first_name} ${res.last_name}</strong></div>
                        <div class="meta"><small>${res.phone || ''}</small></div>
                        <div class="meta"><small>Service: ${res.service_name || ''}</small></div>
                        <div class="meta"><small>Date/Time: ${dateTimeText}</small></div>
                        <div class="meta"><small>Estimated: ${formatCurrency(res.estimated_cost || 0)}</small></div>
                    </div>
                    <div class="card-footer">
                        <a href="#" class="btn btn-sm btn-light view-btn" data-id="${res.id}">View</a>
                        <button class="btn btn-sm btn-primary update-status-btn" data-id="${res.id}">Update</button>
                    </div>
                `;

                if (displayStatus === 'pending') { pendingBody.appendChild(card); pendingCount++; }
                else if (displayStatus === 'processing') { processingBody.appendChild(card); processingCount++; }
                else if (s === 'cancelled' || displayStatus === 'cancelled') { cancelledBody.appendChild(card); cancelledCount++; }
                else if (s === 'completed') { completedBody.appendChild(card); completedCount++; }
                else { pendingBody.appendChild(card); pendingCount++; }
            });

            document.getElementById('pendingCount').textContent = pendingCount;
            document.getElementById('processingCount').textContent = processingCount;
            document.getElementById('cancelledCount').textContent = cancelledCount;
            document.getElementById('completedCount').textContent = completedCount;

            // Highlight newly created reservation card if requested
            if (pendingHighlightTicket) {
                try {
                    if (!document.getElementById('reservationHighlightStyles')) {
                        const styleEl = document.createElement('style');
                        styleEl.id = 'reservationHighlightStyles';
                        styleEl.textContent = `@keyframes flashHighlight{0%{box-shadow:0 0 0 0 rgba(255,193,7,.9);}40%{box-shadow:0 0 0 6px rgba(255,193,7,.5);}80%{box-shadow:0 0 0 0 rgba(255,193,7,0);}100%{box-shadow:0 0 0 0 rgba(255,193,7,0);}}.kanban-card.highlight-flash{animation:flashHighlight 1.4s ease-in-out 0s 1;position:relative;}
                        .kanban-card.highlight-flash::before{content:'';position:absolute;inset:0;border:2px solid #ffc107;border-radius:8px;pointer-events:none;animation:fadeBorder 1.4s ease-in-out forwards;}@keyframes fadeBorder{0%{opacity:1;}70%{opacity:.6;}100%{opacity:0;}}`;
                        document.head.appendChild(styleEl);
                    }
                    const targets = Array.from(document.querySelectorAll('.kanban-card .order-number'));
                    const match = targets.find(el => el.textContent.trim() === pendingHighlightTicket);
                    if (match) {
                        const card = match.closest('.kanban-card');
                        card.classList.add('highlight-flash');
                        setTimeout(()=>{ card.classList.remove('highlight-flash'); }, 2000);
                    }
                } catch(e){ console.warn('Highlight error', e); }
                pendingHighlightTicket = null;
            }

            // Add event listeners for update buttons
            document.querySelectorAll('.update-status-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    currentReservationId = this.getAttribute('data-id');
                    updateStatusModal.show();
                });
            });
            // View button navigates to reservation detail view
            document.querySelectorAll('.view-btn').forEach(btn => {
                btn.addEventListener('click', function(e){
                    e.preventDefault();
                    const id = this.getAttribute('data-id');
                    if (id) window.location.href = 'reservations.php?view=' + id;
                });
            });
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

const submitStatusBtn = document.getElementById('submitStatusBtn');
if (submitStatusBtn) {
    submitStatusBtn.addEventListener('click', async function() {
        const status = document.getElementById('statusSelectModal').value;

        try {
            const response = await fetch('../api/reservations.php?action=update_reservation_status', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ reservation_id: parseInt(currentReservationId), status: status })
            });

            const result = await response.json();
            if (result.success) { updateStatusModal.hide(); loadReservations(); }
            else { alert('Error: ' + result.error); }
        } catch (error) { console.error('Error:', error); }
    });
}

// helpers
function getBadgeClass(status) { const map = { pending: 'warning', processing: 'info', confirmed: 'info', completed: 'success', cancelled: 'danger' }; return map[status] || 'secondary'; }
function formatCurrency(amount) { return '₱' + (parseFloat(amount) || 0).toFixed(2); }

// debounce helper
function debounce(fn, wait) {
    let t;
    return function(...args) {
        clearTimeout(t);
        t = setTimeout(() => fn.apply(this, args), wait);
    };
}

function filterReservationsClientSide(reservations) {
    const search = searchInput ? searchInput.value.trim().toLowerCase() : '';
    const dateFrom = dateFromInput && dateFromInput.value ? new Date(dateFromInput.value) : null;
    const dateTo = dateToInput && dateToInput.value ? new Date(dateToInput.value) : null;
    if (dateTo) dateTo.setHours(23,59,59,999);
    const status = statusFilter ? statusFilter.value : '';
    const svc = serviceFilter ? serviceFilter.value : '';

    return reservations.filter(r => {
        // Treat legacy 'confirmed' as 'processing' for client-side filters
        const rStatus = (r.status === 'confirmed') ? 'processing' : r.status;
        if (status && rStatus !== status) return false;
        if (svc && parseInt(svc) && parseInt(r.service_id) !== parseInt(svc)) return false;

        if (search) {
            const name = ((r.first_name||'') + ' ' + (r.last_name||'')).toLowerCase();
            const phone = (r.phone||'').toLowerCase();
            const resnum = (r.reservation_number||'').toLowerCase();
            if (!name.includes(search) && !phone.includes(search) && !resnum.includes(search) && !(r.service_name||'').toLowerCase().includes(search)) return false;
        }

        if (dateFrom || dateTo) {
            const reserved = r.reserved_date ? new Date(r.reserved_date) : null;
            if (reserved) {
                if (dateFrom) {
                    const fromDate = new Date(dateFrom.getFullYear(), dateFrom.getMonth(), dateFrom.getDate());
                    if (reserved < fromDate) return false;
                }
                if (dateTo) {
                    if (reserved > dateTo) return false;
                }
            }
        }

        return true;
    });
}

// notifier: use global showToast if available, otherwise non-blocking fallback
function notify(message, type='info') {
    if (typeof window.showToast === 'function') {
        try { window.showToast(message, type); return; } catch(e){ console.error('showToast error', e); }
    }
    const fallback = document.createElement('div');
    fallback.textContent = message;
    fallback.style.position='fixed'; fallback.style.bottom='12px'; fallback.style.right='12px';
    fallback.style.background= (type==='success'?'#198754':(type==='danger'?'#dc3545':'#0d6efd'));
    fallback.style.color='#fff'; fallback.style.padding='8px 12px'; fallback.style.borderRadius='6px'; fallback.style.boxShadow='0 4px 12px rgba(0,0,0,.15)'; fallback.style.fontFamily='system-ui, Arial, sans-serif';
    document.body.appendChild(fallback);
    setTimeout(()=>{ fallback.style.transition='opacity 300ms'; fallback.style.opacity='0'; setTimeout(()=>fallback.remove(),320); }, 3000);
}

// Handle Update Status button on reservation detail view (if present)
const updateReservationStatusBtn = document.getElementById('updateReservationStatusBtn');
if (updateReservationStatusBtn) {
    updateReservationStatusBtn.addEventListener('click', async function(){
        const select = document.getElementById('statusSelect');
        const reservationId = select ? select.getAttribute('data-reservation-id') : null;
        const status = select ? select.value : null;
        if (!reservationId || !status) return notify('Missing reservation or status', 'danger');
        try {
            const res = await fetch('../api/reservations.php?action=update_reservation_status', {
                method: 'POST', headers: {'Content-Type':'application/json'},
                body: JSON.stringify({ reservation_id: parseInt(reservationId), status: status })
            });
            const result = await res.json();
            if (result.success) {
                notify('Reservation status updated', 'success');
                setTimeout(()=> location.href = 'reservations.php', 700);
            } else {
                notify('Error: ' + (result.error || 'Failed to update status'), 'danger');
            }
        } catch (err) { console.error(err); notify('An error occurred', 'danger'); }
    });
}

// Handle reservation payment form submission on detail view
const reservationPaymentForm = document.getElementById('reservationPaymentForm');
if (reservationPaymentForm) {
    const weightField = reservationPaymentForm.querySelector('input[name="weight_kg"]');
    const amountField = reservationPaymentForm.querySelector('input[name="amount"]');
    const estimatedTotalEl = document.getElementById('estimatedTotalValue');
    const outstandingEl = document.getElementById('reservationOutstandingAmountValue');
    const detailEstimatedEl = document.getElementById('reservationEstimatedCost');
    const serviceTotalEl = document.getElementById('serviceTotalValue');
    const pricingTotalEl = document.getElementById('pricingTotalValue');
    const pricingPerKgValueEl = document.getElementById('pricingPerKgValue');
    const pricingPerKgLabelEl = document.getElementById('pricingPerKgLabel');
    const weightLabelEl = document.getElementById('reservationWeightValue');

    const basePrice = parseFloat(reservationPaymentForm.dataset.basePrice || '0');
    const pricePerKg = parseFloat(reservationPaymentForm.dataset.pricePerKg || '0');
    const paidTotal = parseFloat(reservationPaymentForm.dataset.paidTotal || '0');
    const initialTotal = parseFloat(reservationPaymentForm.dataset.initialTotal || '0');

    function refreshPaymentPreview() {
        let weight = weightField ? parseFloat(weightField.value) : NaN;
        if (!isFinite(weight) || weight < 0) weight = 0;
        let computedTotal = basePrice + (pricePerKg * weight);
        if (!isFinite(computedTotal) || computedTotal <= 0) computedTotal = initialTotal;
        const outstanding = Math.max(0, computedTotal - paidTotal);

        const formattedTotal = formatCurrency(computedTotal);
        const formattedOutstanding = formatCurrency(outstanding);

        if (estimatedTotalEl) estimatedTotalEl.textContent = formattedTotal;
        if (detailEstimatedEl) detailEstimatedEl.textContent = formattedTotal;
        if (serviceTotalEl) serviceTotalEl.textContent = formattedTotal;
        if (pricingTotalEl) pricingTotalEl.textContent = formattedTotal;
        if (outstandingEl) outstandingEl.textContent = formattedOutstanding;
        if (weightLabelEl) weightLabelEl.textContent = weight.toFixed(2);

        if (pricingPerKgValueEl) {
            const perTotal = Math.max(0, pricePerKg * weight);
            pricingPerKgValueEl.textContent = formatCurrency(perTotal);
        }
        if (pricingPerKgLabelEl) {
            pricingPerKgLabelEl.textContent = formatCurrency(pricePerKg) + '/kg × ' + weight.toFixed(2) + 'kg';
        }

        if (amountField) {
            if (!amountField.dataset.userEdited || amountField.dataset.userEdited !== '1') {
                amountField.value = outstanding > 0 ? outstanding.toFixed(2) : '';
            }
            amountField.placeholder = outstanding > 0 ? outstanding.toFixed(2) : '';
        }
    }

    if (amountField) {
        amountField.addEventListener('input', () => {
            amountField.dataset.userEdited = '1';
        });
    }

    if (weightField) {
        weightField.addEventListener('input', refreshPaymentPreview);
        weightField.addEventListener('change', refreshPaymentPreview);
    }

    refreshPaymentPreview();

    reservationPaymentForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const submitBtn = reservationPaymentForm.querySelector('button[type="submit"]');
        const amount = parseFloat(reservationPaymentForm.querySelector('input[name="amount"]').value);
        const reservationId = parseInt(reservationPaymentForm.dataset.reservationId, 10);
        const method = reservationPaymentForm.querySelector('select[name="payment_method"]').value;
        const notes = reservationPaymentForm.querySelector('textarea[name="notes"]').value.trim();
        const weightInput = reservationPaymentForm.querySelector('input[name="weight_kg"]');
        const weightKg = weightInput && weightInput.value !== '' ? parseFloat(weightInput.value) : null;

        if (!reservationId || !amount || amount <= 0) {
            return notify('Enter a valid amount to record.', 'warning');
        }

        if (submitBtn) submitBtn.disabled = true;
        try {
            const response = await fetch('../api/reservations.php?action=record_reservation_payment', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    reservation_id: reservationId,
                    amount: amount,
                    payment_method: method,
                    notes: notes,
                    weight_kg: weightKg
                })
            });
            const result = await response.json();
            if (result.success) {
                notify('Payment recorded', 'success');
                setTimeout(() => refreshReservationPaymentInfo(reservationId), 700);
            } else {
                notify(result.error || 'Failed to record payment', 'danger');
            }
        } catch (error) {
            console.error(error);
            notify('An unexpected error occurred.', 'danger');
        } finally {
            if (submitBtn) submitBtn.disabled = false;
        }
    });
}

    function refreshReservationPaymentInfo(reservationId){
        fetch('../api/reservations.php?action=get_reservation&id=' + encodeURIComponent(reservationId))
            .then(r => r.json())
            .then(data => {
                if(!data.success || !data.reservation){
                    return;
                }
                const res = data.reservation;
                var paidSpan = document.getElementById('reservationPaidAmountValue');
                var outstandingSpan = document.getElementById('reservationOutstandingAmountValue');
                var badge = document.getElementById('reservationPaymentStatusBadge');
                if(paidSpan){ paidSpan.textContent = formatCurrency(res.total_paid || 0); }
                if(outstandingSpan){ outstandingSpan.textContent = formatCurrency(res.outstanding_amount || 0); }
                if(badge){
                    let status = 'Unpaid';
                    let cls = 'bg-danger';
                    const total = parseFloat(res.total_amount || 0);
                    const paid = parseFloat(res.total_paid || 0);
                    if(paid >= total && total > 0){ status = 'Paid'; cls = 'bg-success'; }
                    else if(paid > 0){ status = 'Partial'; cls = 'bg-warning text-dark'; }
                    badge.className = 'badge ' + cls;
                    badge.textContent = status;
                }
                if(parseFloat(res.outstanding_amount || 0) <= 0){
                    var form = document.getElementById('reservationPaymentForm');
                    if(form){ form.style.display='none'; showToast('Reservation fully paid. Payment form hidden.', 'success'); }
                }
            })
            .catch(err => console.error(err));
    }
// Real-time updates: BroadcastChannel & storage event
try {
    if ('BroadcastChannel' in window) {
        const bc = new BroadcastChannel('reservations_channel');
        bc.onmessage = (event) => {
            if (event.data && event.data.type === 'reservation_created') {
                processNewReservation(event.data.reservation_number, 'bc', event.data.ts);
            }
        };
    }
    window.addEventListener('storage', (e) => {
        if (e.key === 'reservation_created_event' && e.newValue) {
            const parts = e.newValue.split(':');
            const ts = parseInt(parts[0],10) || Date.now();
            const ticket = parts[1] || '';
            processNewReservation(ticket, 'storage', ts);
        }
    });
} catch(e) { console.warn('Realtime setup failed', e); }

// Dedup logic: keep recent ticket numbers processed in last 5 seconds
const recentReservationEvents = new Map(); // ticket -> timestamp
function processNewReservation(ticketNum, source, ts){
    const now = Date.now();
    const lastTs = recentReservationEvents.get(ticketNum);
    if (lastTs && (now - lastTs) < 2000) return; // dedup
    recentReservationEvents.set(ticketNum, now);
    for (const [k,v] of recentReservationEvents) { if (now - v > 5000) recentReservationEvents.delete(k); }
    notify('New reservation #' + ticketNum, 'info');
    pendingHighlightTicket = ticketNum;
    loadReservations();
}

// Periodic polling fallback (every 30s)
let lastAutoLoad = 0;
setInterval(() => {
    const now = Date.now();
    if (now - lastAutoLoad > 25000) {
        lastAutoLoad = now;
        loadReservations();
    }
}, 30000);

// Initial load
if (document.querySelector('.kanban-board')) loadReservations();

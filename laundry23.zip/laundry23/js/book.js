const serviceSelect = document.getElementById('serviceSelect');
const weightKg = document.getElementById('weightKg');
const reservedDate = document.getElementById('reservedDate');
// timeSlots removed (we use exactTimeInput only)
const successMessage = document.getElementById('successMessage');
const errorMessage = document.getElementById('errorMessage');
const submitBtn = document.getElementById('submitBtn');

let services = [];

// min date
reservedDate.setAttribute('min', new Date().toISOString().split('T')[0]);

loadServices();
serviceSelect.addEventListener('change', calculateEstimate);
weightKg.addEventListener('input', calculateEstimate);
// no slot loading; users choose exact time

// Intercept form submit for confirmation modal
document.getElementById('bookingForm').addEventListener('submit', function(e){
    e.preventDefault();
    console.debug('Intercepted submit, showing confirmation modal');
    showConfirmModal();
});

function formatCurrency(amount) { return '₱' + (parseFloat(amount) || 0).toFixed(2); }

function showConfirmModal() {
    // Gather form data
    const fd = new FormData(document.getElementById('bookingForm'));
    const data = Object.fromEntries(fd);
    const service = services.find(s => s.id == data.service_id);
    const estimate = parseFloat(document.getElementById('estimateTotal').textContent.replace(/[^0-9.\-]/g,'')) || 0;
    // Compose modal HTML
    let html = `<div><strong>Ticket Number:</strong> <span id="previewTicketNum">(will be generated)</span></div>`;
    html += `<div><strong>Name:</strong> ${data.first_name} ${data.last_name}</div>`;
    html += `<div><strong>Phone:</strong> ${data.phone}</div>`;
    html += `<div><strong>Email:</strong> ${data.email}</div>`;
    html += `<div><strong>Service:</strong> ${service ? service.name : ''}</div>`;
    html += `<div><strong>Weight:</strong> ${data.weight_kg} kg</div>`;
    html += `<div><strong>Date:</strong> ${data.reserved_date}</div>`;
    html += `<div><strong>Time:</strong> ${data.reserved_time}</div>`;
    html += `<div><strong>Special Requests:</strong> ${data.special_requests || '-'}</div>`;
    html += `<div><strong>Estimated Total:</strong> ${formatCurrency(estimate)}</div>`;
    document.getElementById('confirmModalBody').innerHTML = html;
    // Show modal
    new bootstrap.Modal(document.getElementById('confirmModal')).show();
    // Edit button returns to form
    document.getElementById('editBookingBtn').onclick = function(){
        bootstrap.Modal.getInstance(document.getElementById('confirmModal')).hide();
    };
    // Confirm button triggers booking
    document.getElementById('confirmBookingBtn').onclick = function(){
        submitBookingConfirmed();
    };
}

async function submitBookingConfirmed(){
    const fd = new FormData(document.getElementById('bookingForm'));
    const data = Object.fromEntries(fd);
    submitBtn.disabled = true; successMessage.style.display='none'; errorMessage.style.display='none';
    let lm = document.getElementById('loadingModal');
    let lmInstance = lm ? new bootstrap.Modal(lm) : null;
    const loadStart = Date.now();
    const minDisplay = 1000; // ms
    if (lmInstance) lmInstance.show();
    try {
        const res = await fetch('../api/reservations.php?action=create_reservation', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ first_name:data.first_name, last_name:data.last_name, email:data.email, phone:data.phone, reserved_date:data.reserved_date, reserved_time:data.reserved_time, service_id:parseInt(data.service_id), weight_kg:parseFloat(data.weight_kg), special_requests:data.special_requests })
        });
        const result = await res.json();
        if (result.success) {
            document.getElementById('bookingForm').reset(); calculateEstimate();
            bootstrap.Modal.getInstance(document.getElementById('confirmModal')).hide();
            const finish = () => {
                if (lmInstance) lmInstance.hide();
                showTicketModal(result.reservation_number, data);
            };
            const elapsed = Date.now() - loadStart;
            if (elapsed < minDisplay) { setTimeout(finish, minDisplay - elapsed); } else { finish(); }
        }
        else { showError(result.error || 'Failed to create reservation'); }
    } catch (err) { console.error(err); showError('An error occurred.'); }
    finally {
        submitBtn.disabled = false;
        const ensureHide = () => { if (lmInstance) lmInstance.hide(); };
        const elapsed = Date.now() - loadStart;
        if (elapsed < minDisplay) { setTimeout(ensureHide, minDisplay - elapsed); } else { ensureHide(); }
    }
}

function showTicketModal(ticketNum, data){
    const service = services.find(s => s.id == data.service_id);
    let html = `<div id="ticketBox" style="background:#fff;border-radius:12px;padding:24px;text-align:center;box-shadow:0 4px 24px rgba(0,0,0,0.08);max-width:350px;margin:0 auto;">
        <h3>🧺 Laundry Co.</h3>
        <h5>Ticket #: <span>${ticketNum}</span></h5>
        <hr>
        <div><strong>Name:</strong> ${data.first_name} ${data.last_name}</div>
        <div><strong>Phone:</strong> ${data.phone}</div>
        <div><strong>Email:</strong> ${data.email}</div>
        <div><strong>Service:</strong> ${service ? service.name : ''}</div>
        <div><strong>Weight:</strong> ${data.weight_kg} kg</div>
        <div><strong>Date:</strong> ${data.reserved_date}</div>
        <div><strong>Time:</strong> ${data.reserved_time}</div>
        <div><strong>Special Requests:</strong> ${data.special_requests || '-'}</div>
        <hr>
        <div><strong>Thank you for booking!</strong></div>
    </div>`;
    document.getElementById('ticketModalBody').innerHTML = html;
    new bootstrap.Modal(document.getElementById('ticketModal')).show();
    document.getElementById('savePngBtn').onclick = function(){
        html2canvas(document.getElementById('ticketBox')).then(function(canvas){
            const link = document.createElement('a');
            link.download = `ticket_${ticketNum}.png`;
            link.href = canvas.toDataURL();
            link.click();
        });
    };
    document.getElementById('printBtn').onclick = function(){
        const printContents = document.getElementById('ticketBox').outerHTML;
        const win = window.open('', '', 'width=400,height=600');
        win.document.write('<html><head><title>Print Ticket</title><link rel="stylesheet" href="../css/book.css"></head><body>' + printContents + '</body></html>');
        win.document.close();
        win.focus();
        win.print();
        win.close();
    };
    // Broadcast creation to reservations page (same-origin) using BroadcastChannel + storage fallback
    try {
        if ('BroadcastChannel' in window) {
            const bc = new BroadcastChannel('reservations_channel');
            bc.postMessage({ type: 'reservation_created', reservation_number: ticketNum, ts: Date.now() });
            setTimeout(()=>bc.close(), 500);
        } else {
            localStorage.setItem('reservation_created_event', Date.now() + ':' + ticketNum);
        }
    } catch(e) { console.warn('Broadcast failed', e); }
}

async function loadServices() {
    try {
        const res = await fetch('../api/reservations.php?action=get_services');
        const data = await res.json();
        if (data.success) {
            services = data.services;
            serviceSelect.innerHTML = '<option value="">-- Choose a Service --</option>';

            if (!services || services.length === 0) {
                showError('No services available. Please seed the `services` table.');
            }

            showDebug('get_services response: count=' + (services ? services.length : 0));
            console.log('get_services', data);

            services.forEach(s => {
                    const opt = document.createElement('option');
                    opt.value = s.id;
                    opt.textContent = `${s.name} — base ${formatCurrency(s.base_price)} + ${formatCurrency(s.price_per_kg)}/kg`;
                    opt.setAttribute('data-base-price', s.base_price);
                    opt.setAttribute('data-price-per-kg', s.price_per_kg);
                    serviceSelect.appendChild(opt);
            });
        } else {
            const err = data.error || JSON.stringify(data);
            showError('Failed loading services: ' + err);
            console.error('get_services error:', data);
        }
    } catch (err) {
        console.error(err);
        showError('Failed to load services: ' + (err.message || err));
    }
}

// When user picks an exact time, copy it into the hidden field used for submission
document.getElementById('exactTimeInput').addEventListener('change', function(){
    const t = this.value; // HH:MM
    if (!t) {
        document.getElementById('selectedTime').value = '';
        return;
    }
    document.getElementById('selectedTime').value = t;
});

function formatTime(hhmm) {
    // hhmm expected format 'HH:MM' -> return 'h:MM AM/PM'
    if (!hhmm) return '';
    const [hh, mm] = hhmm.split(':').map(Number);
    const period = hh >= 12 ? 'PM' : 'AM';
    let hour = hh % 12; if (hour === 0) hour = 12;
    return `${hour}:${String(mm).padStart(2,'0')} ${period}`;
}

function calculateEstimate(){
    const serviceId = parseInt(serviceSelect.value);
    const weight = parseFloat(weightKg.value) || 0;
    if (!serviceId || weight <= 0) { document.getElementById('estimateService').textContent='-'; document.getElementById('estimateBase').textContent=formatCurrency(0); document.getElementById('estimateWeight').textContent=formatCurrency(0); document.getElementById('estimateTotal').textContent=formatCurrency(0); return; }
    const option = serviceSelect.options[serviceSelect.selectedIndex];
    const basePrice = parseFloat(option.getAttribute('data-base-price') || 0);
    const pricePerKg = parseFloat(option.getAttribute('data-price-per-kg') || 0);
    const service = services.find(s => s.id == serviceId);
    const weightCharge = weight * pricePerKg;
    const total = basePrice + weightCharge;
    document.getElementById('estimateService').textContent = service ? service.name : option.textContent;
    document.getElementById('estimateBase').textContent = formatCurrency(basePrice);
    document.getElementById('estimateWeight').textContent = formatCurrency(weightCharge);
    document.getElementById('estimateTotal').textContent = formatCurrency(total);
}

async function submitBooking(e){
    e.preventDefault();
    const selectedTime = document.getElementById('selectedTime').value;
    if (!selectedTime) { showError('Please choose an exact time (08:00–18:00)'); return; }
    const fd = new FormData(document.getElementById('bookingForm'));
    const data = Object.fromEntries(fd);
    submitBtn.disabled = true; successMessage.style.display='none'; errorMessage.style.display='none';
    try {
        const res = await fetch('../api/reservations.php?action=create_reservation', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            // ensure reserved_time uses HH:MM format (slots are returned as H:i)
            body: JSON.stringify({ first_name:data.first_name, last_name:data.last_name, email:data.email, phone:data.phone, reserved_date:data.reserved_date, reserved_time:data.reserved_time, service_id:parseInt(data.service_id), weight_kg:parseFloat(data.weight_kg), special_requests:data.special_requests })
        });
        const result = await res.json();
        if (result.success) { document.getElementById('bookingForm').reset(); calculateEstimate(); successMessage.style.display='block'; successMessage.innerHTML = `✅ Reservation successful! #<strong>${result.reservation_number}</strong>`; setTimeout(()=>successMessage.style.display='none',5000); }
        else { showError(result.error || 'Failed to create reservation'); }
    } catch (err) { console.error(err); showError('An error occurred.'); }
    finally { submitBtn.disabled = false; }
}

function showError(msg){ errorMessage.textContent = '❌ '+msg; errorMessage.style.display='block'; setTimeout(()=>errorMessage.style.display='none',5000); }
function showDebug(msg){
    // append debug info under the form for visibility
    let dbg = document.getElementById('debugBox');
    if (!dbg) {
        dbg = document.createElement('pre');
        dbg.id = 'debugBox';
        dbg.style.background = '#fff3cd';
        dbg.style.padding = '10px';
        dbg.style.borderRadius = '6px';
        dbg.style.marginTop = '12px';
        dbg.style.whiteSpace = 'pre-wrap';
        document.querySelector('.booking-container').appendChild(dbg);
    }
    dbg.textContent = msg;
}

// Walk-In Orders JavaScript
console.debug('Loading js/walk_in_orders.js');
const newOrderBtn = document.getElementById('newOrderBtn');
const newOrderModal = new bootstrap.Modal(document.getElementById('newOrderModal'));
const newOrderForm = document.getElementById('newOrderForm');
const submitOrderBtn = document.getElementById('submitOrderBtn');
const addItemBtn = document.getElementById('addItemBtn');
const statusFilter = document.getElementById('statusFilter');
const ordersContainer = document.getElementById('ordersContainer');
const searchInput = document.getElementById('searchInput');
const dateFromInput = document.getElementById('dateFrom');
const dateToInput = document.getElementById('dateTo');
const serviceFilter = document.getElementById('serviceFilter');

// Load services on page load and initialize existing items
let allServices = [];
loadServicesData().then(() => {
    initializeExistingItems();
});

// Toast helper: create and show Bootstrap toasts
function showToast(message, type = 'info', timeout = 4000) {
    console.debug('showToast called:', { message, type, timeout });

    // Ensure there's a visible fallback if Bootstrap or CSS isn't available
    let container = document.getElementById('toastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastContainer';
        container.className = 'position-fixed top-0 end-0 p-3';
        container.style.zIndex = 1060;
        document.body.appendChild(container);
    }

    // If bootstrap isn't present, just show a simple DOM popup
    if (typeof window.bootstrap === 'undefined') {
        console.warn('Bootstrap not found; using DOM fallback for toast');
        const el = document.createElement('div');
        el.textContent = message;
        el.style.background = (type === 'success' ? '#198754' : (type === 'danger' ? '#dc3545' : '#0d6efd'));
        el.style.color = '#fff';
        el.style.padding = '10px 14px';
        el.style.borderRadius = '8px';
        el.style.marginTop = '8px';
        el.style.boxShadow = '0 6px 18px rgba(0,0,0,0.12)';
        el.style.fontFamily = 'system-ui, Arial, sans-serif';
        el.style.opacity = '1';
        container.appendChild(el);
        setTimeout(() => { el.style.transition = 'opacity 300ms'; el.style.opacity = '0'; setTimeout(()=>el.remove(), 350); }, timeout);
        return;
    }

    const toastId = 'toast-' + Date.now();
    const toastEl = document.createElement('div');
    toastEl.id = toastId;
    toastEl.className = 'toast align-items-center text-bg-' + (type === 'error' ? 'danger' : (type === 'danger' ? 'danger' : (type === 'success' ? 'success' : 'info'))) + ' border-0 show';
    toastEl.setAttribute('role', 'alert');
    toastEl.setAttribute('aria-live', 'assertive');
    toastEl.setAttribute('aria-atomic', 'true');
    toastEl.style.minWidth = '180px';
    toastEl.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${message}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>`;

    container.appendChild(toastEl);
    try {
        const bsToast = new bootstrap.Toast(toastEl, { delay: timeout });
        bsToast.show();
        // remove from DOM after hidden
        toastEl.addEventListener('hidden.bs.toast', () => { try { toastEl.remove(); } catch(e){} });
    } catch (e) {
        console.error('bootstrap.Toast error, falling back to DOM message', e);
        // fallback: leave DOM element for timeout then remove
        setTimeout(() => { try { toastEl.remove(); } catch(e){} }, timeout + 400);
    }
}
// expose globally for other scripts
window.showToast = showToast;

async function loadServicesData() {
    try {
        const response = await fetch('../api/reservations.php?action=get_services');
        const data = await response.json();
        if (data.success) {
            allServices = data.services;
        }
    } catch (error) {
        console.error('Error loading services:', error);
    }
}

// Initialize any existing .order-item blocks rendered by server
function initializeExistingItems() {
    const items = document.querySelectorAll('.order-item');
    items.forEach(item => {
        const serviceSelect = item.querySelector('.service-select');
        const unitPrice = item.querySelector('.unit-price');
        const quantity = item.querySelector('.quantity');
        const removeBtn = item.querySelector('.remove-item');

        // Populate select only if it has no options (or only the placeholder)
        if (serviceSelect && serviceSelect.options.length <= 1) {
            allServices.forEach(service => {
                const option = document.createElement('option');
                option.value = service.id;
                option.textContent = `${service.name} - ₱${parseFloat(service.base_price).toFixed(2)}`;
                option.setAttribute('data-price', service.base_price);
                serviceSelect.appendChild(option);
            });
        }

        if (serviceSelect) {
            // If a service is already selected, set unit price
            if (serviceSelect.value) {
                const price = serviceSelect.options[serviceSelect.selectedIndex].getAttribute('data-price');
                unitPrice.value = price || 0;
            }
            // Attach change listener
            serviceSelect.addEventListener('change', function() {
                const price = this.options[this.selectedIndex].getAttribute('data-price');
                unitPrice.value = price || 0;
                calculateTotal();
            });
        }

        if (quantity) {
            quantity.addEventListener('change', calculateTotal);
            quantity.addEventListener('input', calculateTotal);
        }

        if (removeBtn) {
            removeBtn.addEventListener('click', function() {
                item.remove();
                calculateTotal();
            });
        }
    });
    // Recalculate after initialization
    calculateTotal();
}

// Event Listeners
if (newOrderBtn) {
    newOrderBtn.addEventListener('click', () => newOrderModal.show());
}

if (addItemBtn) {
    addItemBtn.addEventListener('click', addOrderItem);
}

if (submitOrderBtn) {
    submitOrderBtn.addEventListener('click', submitOrder);
}

if (statusFilter) {
    statusFilter.addEventListener('change', loadOrders);
}
if (searchInput) searchInput.addEventListener('input', debounce(loadOrders, 300));
if (dateFromInput) dateFromInput.addEventListener('change', loadOrders);
if (dateToInput) dateToInput.addEventListener('change', loadOrders);
if (serviceFilter) serviceFilter.addEventListener('change', loadOrders);

// Add listeners to customer information fields for summary update
if (newOrderForm) {
    ['first_name', 'last_name', 'phone', 'email'].forEach(fieldName => {
        const field = newOrderForm.querySelector(`input[name="${fieldName}"]`);
        if (field) {
            field.addEventListener('input', updateOrderSummary);
        }
    });
}

// Add order item
function addOrderItem() {
    const container = document.getElementById('itemsContainer');
    
    const newItem = document.createElement('div');
    newItem.className = 'order-item mb-3';
    newItem.innerHTML = `
        <div class="row">
            <div class="col-md-6">
                <label class="form-label">Service</label>
                <select class="form-select service-select" name="service_id" required>
                    <option value="">Select Service</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Quantity</label>
                <input type="number" class="form-control quantity" name="quantity" value="1" min="1" required>
            </div>
            <div class="col-md-3">
                <label class="form-label">Unit Price</label>
                <input type="number" class="form-control unit-price" name="unit_price" step="0.01" readonly>
            </div>
        </div>
        <button type="button" class="btn btn-sm btn-danger mt-2 remove-item">Remove</button>
    `;
    
    container.appendChild(newItem);
    
    // Populate service select
    const serviceSelect = newItem.querySelector('.service-select');
    allServices.forEach(service => {
        const option = document.createElement('option');
        option.value = service.id;
        option.textContent = `${service.name} - ₱${parseFloat(service.base_price).toFixed(2)}`;
        option.setAttribute('data-price', service.base_price);
        serviceSelect.appendChild(option);
    });
    
    // Add event listeners to new item
    const quantity = newItem.querySelector('.quantity');
    const unitPrice = newItem.querySelector('.unit-price');
    const removeBtn = newItem.querySelector('.remove-item');
    
    serviceSelect.addEventListener('change', function() {
        const price = this.options[this.selectedIndex].getAttribute('data-price');
        unitPrice.value = price || 0;
        calculateTotal();
    });
    
    quantity.addEventListener('change', calculateTotal);
    removeBtn.addEventListener('click', function() {
        newItem.remove();
        calculateTotal();
    });
}

// Calculate total
function calculateTotal() {
    let total = 0;
    const items = document.querySelectorAll('.order-item');
    
    items.forEach(item => {
        const quantity = parseFloat(item.querySelector('.quantity').value) || 0;
        const price = parseFloat(item.querySelector('.unit-price').value) || 0;
        total += quantity * price;
    });
    
    document.getElementById('totalAmount').textContent = '₱' + total.toFixed(2);
    
    // Update summary preview
    updateOrderSummary();
}

// Update order summary preview
function updateOrderSummary() {
    const firstName = document.querySelector('input[name="first_name"]')?.value || '';
    const lastName = document.querySelector('input[name="last_name"]')?.value || '';
    const phone = document.querySelector('input[name="phone"]')?.value || '';
    const summaryCard = document.getElementById('orderSummary');
    if (!summaryCard) return;

    // Build pricing rows like Reservations' breakdown
    const rowsContainer = document.getElementById('summaryPricingRows');
    const rowsFrag = document.createDocumentFragment();
    let computedTotal = 0;
    const items = document.querySelectorAll('.order-item');
    let validItemCount = 0;

    items.forEach(item => {
        const serviceSelect = item.querySelector('.service-select');
        const quantityEl = item.querySelector('.quantity');
        const unitPriceEl = item.querySelector('.unit-price');
        if (!serviceSelect || !quantityEl || !unitPriceEl) return;
        if (!serviceSelect.value) return;
        const qty = parseFloat(quantityEl.value) || 0;
        const unit = parseFloat(unitPriceEl.value) || 0;
        if (qty <= 0 || unit < 0) return;
        validItemCount++;
        const subtotal = qty * unit;
        computedTotal += subtotal;
        // Derive a clean service name (strip trailing price if present in option text)
        let svcName = '';
        try {
            const opt = serviceSelect.options[serviceSelect.selectedIndex];
            const txt = (opt && opt.textContent) ? opt.textContent.trim() : '';
            // e.g. "Wash & Fold - ₱100.00" -> "Wash & Fold"
            svcName = txt.replace(/\s*-\s*₱.*$/, '');
        } catch (_) {}
        if (!svcName) svcName = 'Service';

        const row = document.createElement('div');
        row.className = 'd-flex justify-content-between small';
        const left = document.createElement('span');
        left.textContent = `${svcName} — ${formatCurrency(unit)} × ${qty}${isFinite(qty) ? '' : ''}`;
        const right = document.createElement('strong');
        right.textContent = formatCurrency(subtotal);
        row.appendChild(left);
        row.appendChild(right);
        rowsFrag.appendChild(row);
    });

    if (rowsContainer) {
        rowsContainer.innerHTML = '';
        rowsContainer.appendChild(rowsFrag);
    }

    // Update summary text blocks
    const hasData = (firstName || lastName || phone || validItemCount > 0);
    if (hasData) {
        summaryCard.style.display = 'block';
        const customerEl = document.getElementById('summaryCustomer');
        const phoneEl = document.getElementById('summaryPhone');
        const itemsEl = document.getElementById('summaryItems');
        const pricingTotalEl = document.getElementById('summaryPricingTotal');
        const totalTextEl = document.getElementById('summaryTotal');
        if (customerEl) customerEl.textContent = (firstName + ' ' + lastName).trim() || '-';
        if (phoneEl) phoneEl.textContent = phone || '-';
        if (itemsEl) itemsEl.textContent = String(validItemCount);
        if (pricingTotalEl) pricingTotalEl.textContent = formatCurrency(computedTotal);
        if (totalTextEl) totalTextEl.textContent = formatCurrency(computedTotal);
    } else {
        summaryCard.style.display = 'none';
    }
}

// debounce helper
function debounce(fn, wait) {
    let t;
    return function(...args) {
        clearTimeout(t);
        t = setTimeout(() => fn.apply(this, args), wait);
    };
}

// Client-side filters for orders
function filterOrdersClientSide(orders) {
    const search = searchInput ? searchInput.value.trim().toLowerCase() : '';
    const dateFrom = dateFromInput && dateFromInput.value ? new Date(dateFromInput.value) : null;
    const dateTo = dateToInput && dateToInput.value ? new Date(dateToInput.value) : null;
    if (dateTo) dateTo.setHours(23,59,59,999);
    const status = statusFilter ? statusFilter.value : '';

    return orders.filter(order => {
        if (status && order.status !== status) return false;

        if (search) {
            const customer = (order.customer_name || '').toLowerCase();
            const ordnum = (order.order_number || '').toLowerCase();
            if (!customer.includes(search) && !ordnum.includes(search)) return false;
        }

        if (dateFrom || dateTo) {
            const due = order.due_date ? new Date(order.due_date) : null;
            if (due) {
                if (dateFrom) {
                    const fromDate = new Date(dateFrom.getFullYear(), dateFrom.getMonth(), dateFrom.getDate());
                    if (due < fromDate) return false;
                }
                if (dateTo) {
                    if (due > dateTo) return false;
                }
            }
        }

        return true;
    });
}

// Submit order
async function submitOrder() {
    const formData = new FormData(newOrderForm);
    const items = [];
    let totalAmount = 0;
    
    document.querySelectorAll('.order-item').forEach(item => {
        const service_id = item.querySelector('.service-select').value;
        const quantity = parseFloat(item.querySelector('.quantity').value);
        const unit_price = parseFloat(item.querySelector('.unit-price').value);
        
        if (service_id && quantity) {
            items.push({
                service_id: parseInt(service_id),
                quantity: quantity,
                unit_price: unit_price
            });
            totalAmount += quantity * unit_price;
        }
    });
    
    if (items.length === 0) {
        showToast('Please add at least one item', 'danger');
        return;
    }
    
    const data = {
        first_name: formData.get('first_name'),
        last_name: formData.get('last_name'),
        phone: formData.get('phone'),
        email: formData.get('email'),
        notes: formData.get('notes'),
        items: items,
        total_amount: totalAmount,
        due_hours: 24
    };
    
    try {
        const response = await fetch('../api/orders.php?action=create_order', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        if (result.success) {
            console.debug('submitOrder: success result:', result);
            try { showToast('Order created successfully: ' + result.order_number, 'success'); } catch (e) { console.error('showToast error', e); }
            newOrderForm.reset();
            newOrderModal.hide();
            // small delay so the toast is visible before refreshing the board
            setTimeout(() => loadOrders(), 600);
        } else {
            console.debug('submitOrder: error result:', result);
            try { showToast('Error: ' + (result.error || 'Failed to create order'), 'danger'); } catch (e) { console.error('showToast error', e); }
        }
    } catch (error) {
        console.error('Error:', error);
        showToast('Failed to create order', 'danger');
    }
}

// Helper to format server 'YYYY-MM-DD HH:MM:SS' as 12h local without seconds
function formatDueDate(raw) {
    if (!raw) return '';
    const m = raw.match(/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})$/);
    if (!m) {
        // Fallback: try Date parsing then format
        const dtry = new Date(raw);
        if (!isNaN(dtry.getTime())) {
            let hr = dtry.getHours();
            const min = String(dtry.getMinutes()).padStart(2,'0');
            const ampm = hr >= 12 ? 'PM' : 'AM';
            hr = hr % 12; if (hr === 0) hr = 12;
            return `${dtry.getMonth()+1}/${dtry.getDate()}/${dtry.getFullYear()}, ${hr}:${min} ${ampm}`;
        }
        return raw;
    }
    const [_, y, mo, d, hh, mm] = m;
    let hr = parseInt(hh,10);
    const ampm = hr >= 12 ? 'PM' : 'AM';
    hr = hr % 12; if (hr === 0) hr = 12;
    return `${mo}/${d}/${y}, ${hr}:${mm} ${ampm}`;
}

// Load orders
async function loadOrders() {
    // fetch orders (apply filters client-side)
    try {
        const response = await fetch('../api/orders.php?action=get_orders');
        const data = await response.json();
        
        if (data.success) {
            // clear columns
            const pendingBody = document.getElementById('pendingBody');
            const processingBody = document.getElementById('processingBody');
            const completedBody = document.getElementById('completedBody');
            const cancelledBody = document.getElementById('cancelledBody');
            pendingBody.innerHTML = '';
            processingBody.innerHTML = '';
            completedBody.innerHTML = '';
            if (cancelledBody) cancelledBody.innerHTML = '';

                if (!data.orders || data.orders.length === 0) {
                    pendingBody.innerHTML = '<p class="text-muted">No orders</p>';
                    console.debug('orders data: empty set');
                    return;
                }

                let pendingCount = 0, processingCount = 0, completedCount = 0, cancelledCount = 0;

                // apply client-side filters
                let orders = data.orders || [];
                orders = filterOrdersClientSide(orders);

                orders.forEach(order => {
                    const status = order.status;
                    const dueText = formatDueDate(order.due_date);

                    const card = document.createElement('div');
                    card.className = 'kanban-card';
                    card.innerHTML = `
                        <div class="card-top">
                            <div class="order-number">#${order.order_number}</div>
                            <div class="badge small bg-${getBadgeClass(status)}">${status.replace('_',' ')}</div>
                        </div>
                        <div class="card-body">
                            <div class="customer"><strong>${order.customer_name || 'Walk-in Customer'}</strong></div>
                            ${order.phone ? `<div class="meta"><small>${order.phone}</small></div>` : ''}
                            <div class="meta"><small><strong>Service:</strong> <span id="serviceName-${order.id}">-</span></small></div>
                            <div class="meta"><small><strong>Date/Time:</strong> ${dueText}</small></div>
                            <div class="meta"><small><strong>Estimated:</strong> ${formatCurrency(order.total_amount)}</small></div>
                        </div>
                        <div class="card-footer d-flex justify-content-between align-items-center">
                            <a href="walk_in_orders.php?edit=${order.id}" class="btn btn-sm btn-light view-btn">View</a>
                            <a href="walk_in_orders.php?edit=${order.id}" class="btn btn-sm btn-primary">Update</a>
                        </div>
                    `;

                    if (status === 'pending') {
                        pendingBody.appendChild(card);
                        pendingCount++;
                    } else if (status === 'processing') {
                        processingBody.appendChild(card);
                        processingCount++;
                    } else if (status === 'completed' || status === 'ready_for_pickup') {
                        completedBody.appendChild(card);
                        completedCount++;
                    } else if (status === 'cancelled') {
                        if (cancelledBody) cancelledBody.appendChild(card);
                        cancelledCount++;
                    } else {
                        // unrecognized statuses default to pending
                        pendingBody.appendChild(card);
                        pendingCount++;
                    }
                    
                    // Load extra details (first service name, item count if needed)
                    loadOrderCardDetails(order.id);
                });

                document.getElementById('pendingCount').textContent = pendingCount;
                document.getElementById('processingCount').textContent = processingCount;
                document.getElementById('completedCount').textContent = completedCount;
                if (document.getElementById('cancelledCount')) {
                    document.getElementById('cancelledCount').textContent = cancelledCount;
                }
            }
    } catch (error) {
        console.error('Error:', error);
    }
}

    // helper: get bootstrap-like badge class
    function getBadgeClass(status) {
        const map = { pending: 'warning', processing: 'info', completed: 'success', cancelled: 'danger' };
        return map[status] || 'secondary';
    }

    function formatCurrency(amount) {
        return '₱' + (parseFloat(amount) || 0).toFixed(2);
    }

// Load extra order details for the card (first service name, and legacy item count if present)
async function loadOrderCardDetails(orderId) {
    try {
        const response = await fetch(`../api/orders.php?action=get_order&id=${orderId}`);
        const data = await response.json();
        if (data.success) {
            // service name: use the first item if available
            const svcEl = document.getElementById(`serviceName-${orderId}`);
            if (svcEl) {
                let svcName = '-';
                if (data.items && data.items.length > 0) {
                    // service_name field is provided by API
                    svcName = data.items[0].service_name || data.items[0].name || '-';
                }
                svcEl.textContent = svcName;
            }
            // Backward compatibility: if there is an Items: label, update it
            const itemCountEl = document.getElementById(`itemCount-${orderId}`);
            if (itemCountEl && data.items) {
                itemCountEl.innerHTML = `<strong>Items:</strong> ${data.items.length}`;
            }
        }
    } catch (error) {
        console.error('Error loading order details:', error);
    }
}

// Load order item count (legacy - kept for compatibility, no longer used by new cards)
async function loadOrderItemCount(orderId) {
    try {
        const response = await fetch(`../api/orders.php?action=get_order&id=${orderId}`);
        const data = await response.json();
        if (data.success && data.items) {
            const itemCountEl = document.getElementById(`itemCount-${orderId}`);
            if (itemCountEl) {
                itemCountEl.innerHTML = `<strong>Items:</strong> ${data.items.length}`;
            }
        }
    } catch (error) {
        console.error('Error loading item count:', error);
    }
}

// Update order status
if (document.getElementById('updateStatusBtn')) {
    document.getElementById('updateStatusBtn').addEventListener('click', async function() {
        const orderId = document.getElementById('statusSelect').getAttribute('data-order-id');
        const status = document.getElementById('statusSelect').value;
        
        try {
            const response = await fetch('../api/orders.php?action=update_order_status', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    order_id: parseInt(orderId),
                    status: status
                })
            });
            
            const result = await response.json();
            if (result.success) {
                console.debug('update_order_status: success', result);
                try { showToast('Order status updated', 'success'); } catch (e) { console.error('showToast error', e); }
                setTimeout(() => location.reload(), 700);
            } else {
                console.debug('update_order_status: error', result);
                try { showToast('Error: ' + (result.error || 'Failed to update status'), 'danger'); } catch (e) { console.error('showToast error', e); }
            }
        } catch (error) {
            console.error('Error:', error);
        }
    });
}

// Record payment
if (document.getElementById('paymentForm')) {
    document.getElementById('paymentForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        const orderId = this.getAttribute('data-order-id');
        const amount = document.querySelector('input[name="amount"]').value;
        const paymentMethod = document.querySelector('select[name="payment_method"]').value;
        
        try {
            const response = await fetch('../api/orders.php?action=record_payment', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    order_id: parseInt(orderId),
                    amount: parseFloat(amount),
                    payment_method: paymentMethod
                })
            });
            
            const result = await response.json();
            if (result.success) {
                console.debug('record_payment: success', result);
                try { showToast('Payment recorded', 'success'); } catch (e) { console.error('showToast error', e); }
                // Refresh payment UI without full reload
                refreshPaymentInfo(parseInt(orderId));
            } else {
                console.debug('record_payment: error', result);
                try { showToast('Error: ' + (result.error || 'Failed to record payment'), 'danger'); } catch (e) { console.error('showToast error', e); }
            }
        } catch (error) {
            console.error('Error:', error);
        }
    });
}

// Refresh payment info for a specific order (edit view)
async function refreshPaymentInfo(orderId){
    try {
        const resp = await fetch(`../api/orders.php?action=get_order&id=${orderId}`);
        const data = await resp.json();
        if(!data.success || !data.order) return;
        const order = data.order;
        const payments = data.payments || [];
        let paid = 0; payments.forEach(p=> paid += parseFloat(p.amount));
        const outstanding = Math.max(0, parseFloat(order.total_amount) - paid);
        // Update DOM
        const paidEl = document.getElementById('paidAmountValue');
        const outEl = document.getElementById('outstandingAmountValue');
        const badge = document.getElementById('paymentStatusBadge');
        const form = document.getElementById('paymentForm');
        if(paidEl) paidEl.textContent = '₱' + paid.toFixed(2);
        if(outEl) outEl.textContent = '₱' + outstanding.toFixed(2);
        if(badge){
            // Determine new status from order.payment_status if present, else infer
            let status = order.payment_status || (outstanding <= 0 ? 'paid' : (paid > 0 ? 'partial' : 'unpaid'));
            const clsMap = { paid:'success', partial:'info', unpaid:'warning' };
            badge.className = 'badge bg-' + (clsMap[status] || 'secondary');
            badge.textContent = status.charAt(0).toUpperCase() + status.slice(1);
        }
        // Hide form if fully paid
        if(form && (outstanding <= 0)){
            form.style.display = 'none';
            showToast('Order fully paid. Payment form hidden.', 'info');
        } else if(form){
            form.style.display = '';
        }
    } catch(err){ console.error('refreshPaymentInfo error', err); }
}

// Inject modal logic for updating order status from kanban board
let currentOrderId = null;
let updateOrderStatusModal;
try { updateOrderStatusModal = new bootstrap.Modal(document.getElementById('updateOrderStatusModal')); } catch(e) { console.warn('Modal init failed', e); }

function attachKanbanUpdateButtons(){
    document.querySelectorAll('.kanban-card .btn.btn-sm.btn-primary').forEach(btn => {
        // card Update button (second button) -> open modal instead of navigation
        btn.addEventListener('click', function(ev){
            // prevent default navigation
            ev.preventDefault();
            const href = this.getAttribute('href');
            // extract id from query string ?edit=ID
            let id = null;
            try { const m = href && href.match(/edit=(\d+)/); if(m){ id = parseInt(m[1],10); } } catch(_){ }
            if(!id){ console.warn('No order id found for modal update'); return; }
            currentOrderId = id;
            // set select current value if we can fetch quickly from DOM badge
            const badge = this.closest('.kanban-card')?.querySelector('.badge');
            const select = document.getElementById('orderStatusSelectModal');
            if(badge && select){
                const statusText = badge.textContent.trim().toLowerCase().replace(/\s+/g,'_');
                if(Array.from(select.options).some(o=>o.value===statusText)){
                    select.value = statusText;
                }
            }
            if(updateOrderStatusModal){ updateOrderStatusModal.show(); }
        }, { once: true }); // ensure we override default once
    });
}

// After loading orders, attach handlers
const originalLoadOrders = loadOrders;
loadOrders = async function(){
    await originalLoadOrders();
    attachKanbanUpdateButtons();
};

// Handle submit in modal
const submitOrderStatusBtn = document.getElementById('submitOrderStatusBtn');
if(submitOrderStatusBtn){
    submitOrderStatusBtn.addEventListener('click', async function(){
        const select = document.getElementById('orderStatusSelectModal');
        if(!currentOrderId || !select){ return showToast('Missing order or status', 'danger'); }
        const status = select.value;
        try {
            const response = await fetch('../api/orders.php?action=update_order_status', {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ order_id: currentOrderId, status: status })
            });
            const result = await response.json();
            if(result.success){
                showToast('Order status updated', 'success');
                if(updateOrderStatusModal) updateOrderStatusModal.hide();
                setTimeout(()=> loadOrders(), 600);
            } else {
                showToast('Error: ' + (result.error || 'Failed to update status'), 'danger');
            }
        } catch(err){ console.error(err); showToast('Request failed', 'danger'); }
    });
}

// Load orders on page load
if (document.querySelector('.kanban-board')) {
    loadOrders();
}

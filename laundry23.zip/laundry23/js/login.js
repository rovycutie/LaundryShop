document.getElementById('loginForm').addEventListener('submit', function(e){
    e.preventDefault();
    window.location.href = 'pages/dashboard.html';
});

// Sidebar toggle script (mobile/tablet)
(function(){
  function isMobile(){ return window.matchMedia('(max-width: 992px)').matches; }
  function applyInitial(){
    if(isMobile()){ if(!document.body.classList.contains('sidebar-collapsed') && !document.body.classList.contains('sidebar-open')){ document.body.classList.add('sidebar-collapsed'); } }
    else { document.body.classList.remove('sidebar-collapsed','sidebar-open'); }
  }
  function toggleSidebar(){
    if(!isMobile()) return; // ignore toggle on desktop
    if(document.body.classList.contains('sidebar-open')){
      document.body.classList.remove('sidebar-open');
      document.body.classList.add('sidebar-collapsed');
    } else {
      document.body.classList.add('sidebar-open');
      document.body.classList.remove('sidebar-collapsed');
    }
    console.log('[sidebar] state:', document.body.className);
  }
  function bind(){
    var triggers = document.querySelectorAll('[data-sidebar-toggle]');
    triggers.forEach(function(el){
      el.addEventListener('click', function(e){ e.preventDefault(); toggleSidebar(); });
    });
    // Close on backdrop click
    var backdrop = document.querySelector('.sidebar-backdrop');
    if(backdrop){ backdrop.addEventListener('click', function(e){ e.preventDefault(); if(document.body.classList.contains('sidebar-open')) toggleSidebar(); }); }
    // Close on ESC
    document.addEventListener('keyup', function(e){ if(e.key==='Escape' && document.body.classList.contains('sidebar-open')) toggleSidebar(); });
  }
  document.addEventListener('DOMContentLoaded', function(){ applyInitial(); bind(); });
  window.addEventListener('resize', function(){ applyInitial(); });
})();
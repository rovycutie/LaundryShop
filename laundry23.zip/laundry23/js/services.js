// Services management JS
const servicesBody = document.getElementById('servicesBody');
const serviceModal = new bootstrap.Modal(document.getElementById('serviceModal'));
const serviceForm = document.getElementById('serviceForm');
const newServiceBtn = document.getElementById('newServiceBtn');
const saveServiceBtn = document.getElementById('saveServiceBtn');

async function loadServicesAdmin() {
    try {
        // request inactive too so admin can manage them
        const res = await fetch('../api/reservations.php?action=get_services&includeInactive=1');
        const data = await res.json();
        if (data.success) {
            renderServices(data.services || []);
        } else {
            console.error('get_services error:', data.error || data);
        }
    } catch (e) {
        console.error('Failed to load services', e);
    }
}

function escapeHtml(s) {
    if (!s) return '';
    const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    return String(s).replace(/[&<>"']/g, m => map[m]);
}

function renderServices(list) {
    if (!servicesBody) return;

    servicesBody.innerHTML = list.map(s => {
        const active = s.is_active === true ||
                       s.is_active === 1 ||
                       s.is_active === '1' ||
                       s.is_active === 'true';
        return `
            <tr>
                <td>${escapeHtml(s.name)}</td>
                <td>${escapeHtml(s.description || '')}</td>
                <td>₱${parseFloat(s.base_price || 0).toFixed(2)}</td>
                <td>₱${parseFloat(s.price_per_kg || 0).toFixed(2)}</td>
                <td>${s.turnaround_hours || ''}</td>
                <td>
                    <div class="form-check form-switch m-0">
                        <input class="form-check-input service-active-toggle" type="checkbox" data-id="${s.id}" ${active ? 'checked' : ''}>
                    </div>
                </td>
                <td>
                    <button class="btn btn-sm btn-primary edit-service" data-id="${s.id}">Edit</button>
                </td>
            </tr>
        `;
    }).join('');

    // edit buttons
    servicesBody.querySelectorAll('.edit-service').forEach(btn =>
        btn.addEventListener('click', onEditService)
    );
    // availability toggles
    servicesBody.querySelectorAll('.service-active-toggle').forEach(cb =>
        cb.addEventListener('change', onToggleAvailability)
    );
}

async function onToggleAvailability(e) {
    const id = e.currentTarget.getAttribute('data-id');
    const isActive = e.currentTarget.checked;
    try {
        const res = await fetch('../api/reservations.php?action=toggle_service_availability', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: parseInt(id, 10), is_active: isActive })
        });
        const data = await res.json();
        if (!data.success) {
            console.error('toggle_service_availability error:', data.error || data);
            // revert checkbox if failed
            e.currentTarget.checked = !isActive;
            if (typeof window.showToast === 'function') window.showToast('Failed to update availability', 'danger');
        } else {
            if (typeof window.showToast === 'function') window.showToast('Service availability updated', 'success');
            // optional: reload to reflect any filtering
            loadServicesAdmin();
        }
    } catch (err) {
        console.error('toggle availability fetch error', err);
        e.currentTarget.checked = !isActive;
        if (typeof window.showToast === 'function') window.showToast('Network error', 'danger');
    }
}

function onEditService(e) {
    const id = e.currentTarget.getAttribute('data-id');
    // include inactive so editing a disabled service works
    fetch('../api/reservations.php?action=get_services&includeInactive=1')
        .then(r => r.json())
        .then(data => {
            if (!data.success || !data.services) return;
            const s = data.services.find(x => String(x.id) === String(id));
            if (!s) return;

            document.getElementById('serviceId').value = s.id;
            document.getElementById('serviceName').value = s.name;
            document.getElementById('serviceDescription').value = s.description || '';
            document.getElementById('serviceBase').value = s.base_price;
            document.getElementById('servicePerKg').value = s.price_per_kg;
            document.getElementById('serviceTurnaround').value = s.turnaround_hours || 24;
            document.getElementById('serviceActive').checked =
                s.is_active === true || s.is_active === 1 || s.is_active === '1' || s.is_active === 'true';
            // image preview hook
            if (typeof window.setServiceImage === 'function') {
                window.setServiceImage(s.image || '');
            }
            serviceModal.show();
        })
        .catch(err => console.error(err));
}

newServiceBtn.addEventListener('click', () => {
    serviceForm.reset();
    document.getElementById('serviceId').value = '';
    document.getElementById('serviceActive').checked = true;
    const delFlag = document.getElementById('deleteImageFlag');
    if (delFlag) delFlag.value = '0';
    if (typeof window.setServiceImage === 'function') window.setServiceImage('');
    serviceModal.show();
});

saveServiceBtn.addEventListener('click', async () => {
    const id = document.getElementById('serviceId').value.trim();
    const fd = new FormData();
    if (id) fd.append('id', id);
    fd.append('name', document.getElementById('serviceName').value.trim());
    fd.append('description', document.getElementById('serviceDescription').value.trim());
    fd.append('base_price', document.getElementById('serviceBase').value);
    fd.append('price_per_kg', document.getElementById('servicePerKg').value);
    fd.append('turnaround_hours', document.getElementById('serviceTurnaround').value);
    fd.append('is_active', document.getElementById('serviceActive').checked ? '1' : '0');
    const delFlag = document.getElementById('deleteImageFlag');
    if (delFlag) fd.append('delete_image', delFlag.value);
    const imgInput = document.getElementById('serviceImage');
    if (imgInput && imgInput.files && imgInput.files[0]) {
        fd.append('image', imgInput.files[0]);
    }
    try {
        const res = await fetch('../api/reservations.php?action=save_service', { method: 'POST', body: fd });
        const text = await res.text();
        let data;
        try { data = JSON.parse(text); } catch(parseErr) {
            console.error('Bad JSON response', text);
            alert('Upload failed: invalid server response');
            return;
        }
        console.log('save_service response:', data);
        if (data.success) {
            serviceModal.hide();
            loadServicesAdmin();
            if (typeof window.showToast === 'function') window.showToast('Service saved', 'success');
        } else {
            alert('Error: ' + (data.error || 'Failed'));
        }
    } catch (err) {
        console.error('save_service network error', err);
        alert('Unexpected network error saving service');
    }
});

// expose for inline scripts
window.renderServices = renderServices;
window.loadServicesAdmin = loadServicesAdmin;
window.escapeHtml = escapeHtml;

// initial load
loadServicesAdmin();

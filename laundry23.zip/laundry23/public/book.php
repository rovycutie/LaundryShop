<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/functions.php';

$settings = [
    'site_name' => 'Laundry Co.',
    'logo' => '',
    'sidebar_color' => '#667eea'
];

$settingsFile = __DIR__ . '/../includes/settings.php';
if (file_exists($settingsFile)) {
    $loaded = include $settingsFile;
    if (is_array($loaded)) {
        $settings = array_merge($settings, $loaded);
    }
}

// Theme color (fallback to primary blue if not set)
$themeColor = isset($settings['sidebar_color']) && $settings['sidebar_color'] ? $settings['sidebar_color'] : '#667eea';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Your Laundry - <?php echo htmlspecialchars($settings['site_name']); ?></title>
    <?php
    // Favicon/logo path normalization for public/ context: keep '../uploads/' prefix if present
    $logoSetting = trim($settings['logo'] ?? '');
    $logoWeb = $logoSetting;
    if ($logoWeb !== '') {
        if (preg_match('#^uploads/#',$logoWeb)) { // add ../ because we are in /public
            $logoWeb = '../' . $logoWeb;
        }
        // If it already starts with ../uploads keep it
    }
    // Resolve absolute path for existence
    $absLogo = ($logoWeb !== '') ? realpath(__DIR__ . '/../' . ltrim(str_replace(['../','./'],'', $logoWeb), '/')) : false;
    if (!$absLogo || !is_file($absLogo)) {
        // Auto-detect newest logo_* file in uploads
        $uploadsDir = realpath(__DIR__ . '/../uploads');
        if ($uploadsDir) {
            $cands = glob($uploadsDir . '/logo_*.*');
            if ($cands) { usort($cands, fn($a,$b)=>filemtime($b)<=>filemtime($a)); $absLogo = $cands[0]; $logoWeb = '../uploads/' . basename($absLogo); }
        }
    }
    $faviconPath = ($absLogo && is_file($absLogo)) ? $logoWeb : '../uploads/wash_and_fold.jpg';
    if ($absLogo && is_file($absLogo)) { $mtime=@filemtime($absLogo); if($mtime){ $faviconPath .= (strpos($faviconPath,'?')===false?'?v=':'&v=').$mtime; } }
    ?>
    <!-- debug: faviconPath=<?php echo htmlspecialchars($faviconPath); ?> logoSetting=<?php echo htmlspecialchars($logoSetting); ?> -->
    <link rel="icon" type="image/png" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link rel="apple-touch-icon" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        :root {
            --primary: <?php echo htmlspecialchars($themeColor); ?>;
            --secondary: <?php echo htmlspecialchars($themeColor); ?>;
        }

        body {
            background: <?php echo htmlspecialchars($themeColor); ?>;
            min-height: 100vh;
            padding: 20px;
        }

        .booking-container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 40px;
        }
        #backBtn.btn-back {
            background: var(--primary);
            color: #fff;
            border: none;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 6px 14px;
            border-radius: 6px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transition: background .25s, transform .25s;
        }
        #backBtn.btn-back:hover { background: rgba(255,255,255,0.12); filter: brightness(1.08); }
        #backBtn.btn-back:active { transform: translateY(1px); }

        .header {
            text-align: center;
            margin-bottom: 40px;
        }

        .brand-logo {
            width: 110px;
            height: 110px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid rgba(102, 126, 234, 0.2);
            background: #fff;
            display: block;
            margin: 0 auto 15px auto;
        }

        .brand-icon {
            font-size: 64px;
            margin-bottom: 10px;
        }

        .ticket-brand-logo {
            width: 72px;
            height: 72px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid rgba(102, 126, 234, 0.2);
            background: #fff;
            margin: 0 auto 12px auto;
            display: block;
        }

        .ticket-brand-icon {
            font-size: 48px;
            margin-bottom: 8px;
        }

        .header h1 {
            font-size: 32px;
            color: var(--primary);
            margin-bottom: 10px;
        }

        .header p {
            color: #666;
            font-size: 16px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            font-weight: 600;
            color: #333;
            margin-bottom: 8px;
            display: block;
            font-size: 14px;
        }

        .form-control, .form-select {
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            padding: 12px 15px;
            font-size: 14px;
            transition: all 0.3s;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }

        .section-title {
            font-size: 16px;
            font-weight: bold;
            color: #333;
            margin-top: 30px;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
        }

        .time-slots {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(80px, 1fr));
            gap: 8px;
        }

        .time-slot {
            padding: 8px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            background: white;
            font-size: 12px;
        }

        .time-slot:hover {
            border-color: var(--primary);
            background: #f0f5ff;
        }

        .time-slot.selected {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .time-slot.disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .btn-submit {
            background: var(--primary);
            border: none;
            color: white;
            padding: 14px 30px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 8px;
            width: 100%;
            margin-top: 20px;
            transition: all 0.3s;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
            color: white;
        }

        .btn-submit:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .success-message {
            display: none;
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #c3e6cb;
        }

        .error-message {
            display: none;
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #f5c6cb;
        }

        .loading {
            display: none;
        }

        @media (max-width: 768px) {
            .booking-container {
                padding: 24px;
            }

            .time-slots {
                grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            }
        }

        @media (max-width: 576px) {
            .booking-container {
                padding: 20px;
            }

            .header h1 {
                font-size: 24px;
            }

            .time-slots {
                grid-template-columns: repeat(auto-fit, minmax(70px, 1fr));
            }
        }
    </style>
</head>
<body data-site-name="<?php echo htmlspecialchars($settings['site_name']); ?>" data-site-logo="<?php echo htmlspecialchars($settings['logo']); ?>">
    <div class="booking-container">
        <div class="d-flex justify-content-start mb-2">
            <button type="button" class="btn btn-sm btn-back" id="backBtn"><i class="bi bi-arrow-left"></i><span>Back</span></button>
        </div>
        <div class="header">
            <?php if (!empty($settings['logo'])): ?>
                <img src="<?php echo htmlspecialchars($settings['logo']); ?>" alt="<?php echo htmlspecialchars($settings['site_name']); ?> logo" class="brand-logo">
            <?php else: ?>
                <div class="brand-icon">🧺</div>
            <?php endif; ?>
            <h1><?php echo htmlspecialchars($settings['site_name']); ?></h1>
            <p>Book Your Laundry Service</p>
        </div>

        <div class="success-message" id="successMessage">
            <i class="bi bi-check-circle"></i> Reservation successful! Check your email for confirmation.
        </div>

        <div class="error-message" id="errorMessage"></div>

        <form id="bookingForm">
            <!-- Personal Information -->
            <div class="section-title">Personal Information</div>

            <div class="form-group">
                <label class="form-label">First Name *</label>
                <input type="text" class="form-control" name="first_name" required>
            </div>

            <div class="form-group">
                <label class="form-label">Last Name *</label>
                <input type="text" class="form-control" name="last_name" required>
            </div>

            <div class="form-group">
                <label class="form-label">Phone Number *</label>
                <input type="text" class="form-control" name="phone" placeholder="Enter digits only" inputmode="numeric" pattern="[0-9]*" required>
            </div>

            <div class="form-group">
                <label class="form-label">Email Address (optional)</label>
                <input type="email" class="form-control" name="email">
            </div>

            <!-- Service Selection -->
            <div class="section-title">Service Details</div>

            <div class="form-group">
                <label class="form-label">Select Service *</label>
                <select class="form-select" name="service_id" id="serviceSelect" required>
                    <option value="">-- Choose a Service --</option>
                </select>
            </div>

            <!-- Date & Time Selection -->
            <div class="section-title">Schedule</div>

            <div class="form-group">
                <label class="form-label">Preferred Date *</label>
                <input type="date" class="form-control" name="reserved_date" id="reservedDate" required>
            </div>

            <div class="form-group">
                <label class="form-label">Preferred Time *</label>
                <div class="time-slots" id="timeSlots">
                    <p class="text-muted">Select a date first</p>
                </div>
                <div class="mt-2">
                    <button type="button" id="toggleExactTime" class="btn btn-sm btn-outline-secondary">Or choose exact time</button>
                    <input type="time" id="exactTimeInput" class="form-control mt-2" style="display:none; max-width:200px;" step="900" min="08:00" max="18:00">
                </div>
                <input type="hidden" name="reserved_time" id="selectedTime" required>
                <div id="timeHelp" class="form-text text-muted" style="display:none;"></div>
            </div>

            <!-- Special Requests -->
            <div class="form-group">
                <label class="form-label">Special Requests</label>
                <textarea class="form-control" name="special_requests" rows="3" placeholder="Any special instructions or preferences?"></textarea>
            </div>

            <button type="submit" class="btn-submit" id="submitBtn">Book Now</button>
        </form>

        <div class="loading mt-3" id="loadingSpinner">
            <div class="text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2">Processing your reservation...</p>
            </div>
        </div>
    </div>
    
        <!-- Confirmation Modal -->
        <div class="modal fade" id="confirmModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header"><h5 class="modal-title">Confirm Booking</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                    <div class="modal-body" id="confirmModalBody"></div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" id="editBookingBtn">Edit</button>
                        <button type="button" class="btn btn-primary" id="confirmBookingBtn">Confirm</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Ticket Modal -->
        <div class="modal fade" id="ticketModal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header"><h5 class="modal-title">Your Ticket</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                    <div class="modal-body" id="ticketModalBody"></div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-success" id="savePngBtn">Save as PNG</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Loading Modal (shown while creating reservation) -->
        <div class="modal" id="loadingModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content" style="border:none; background:transparent; box-shadow:none;">
                    <div class="text-center p-4 bg-white rounded-3 shadow">
                        <div class="spinner-border text-primary mb-3" role="status"><span class="visually-hidden">Loading...</span></div>
                        <p class="mb-0 fw-semibold">Creating your reservation...</p>
                        <small class="text-muted">Please wait</small>
                    </div>
                </div>
            </div>
        </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const siteSettings = {
            site_name: <?php echo json_encode($settings['site_name'] ?? ''); ?>,
            logo: <?php echo json_encode($settings['logo'] ?? ''); ?>
        };

        const form = document.getElementById('bookingForm');
        const serviceSelect = document.getElementById('serviceSelect');
        const reservedDate = document.getElementById('reservedDate');
        const timeSlots = document.getElementById('timeSlots');
        const successMessage = document.getElementById('successMessage');
        const errorMessage = document.getElementById('errorMessage');
        const submitBtn = document.getElementById('submitBtn');
        const loadingSpinner = document.getElementById('loadingSpinner');
        const phoneInput = document.querySelector('input[name="phone"]');

        let services = [];
        let availableSlots = [];
        let selectedTime = null;

        if (phoneInput) {
            phoneInput.addEventListener('input', function() {
                this.value = this.value.replace(/[^0-9]/g, '');
            });
        }

        // Set minimum date to today
        const today = new Date().toISOString().split('T')[0];
        reservedDate.setAttribute('min', today);

        // Load services on page load
        loadServices();

        // Event listeners
        reservedDate.addEventListener('change', loadTimeSlots);
        // intercept submit to show confirmation modal first
        form.addEventListener('submit', function(e){ e.preventDefault(); showConfirmModal(); });

        async function loadServices() {
            try {
                const response = await fetch('../api/reservations.php?action=get_services');
                const data = await response.json();

                if (data.success) {
                    services = data.services;
                    serviceSelect.innerHTML = '<option value="">-- Choose a Service --</option>';

                    if (!services || services.length === 0) {
                        showError('No services available. Please seed the `services` table.');
                    }

                    services.forEach(service => {
                        const option = document.createElement('option');
                        option.value = service.id;
                        option.textContent = `${service.name} — base ₱${parseFloat(service.base_price).toFixed(2)} + ₱${parseFloat(service.price_per_kg).toFixed(2)}/kg`;
                        option.setAttribute('data-base-price', service.base_price);
                        option.setAttribute('data-price-per-kg', service.price_per_kg);
                        serviceSelect.appendChild(option);
                    });
                } else {
                    const err = data.error || JSON.stringify(data);
                    showError('Failed loading services: ' + err);
                    console.error('get_services error:', data);
                }
            } catch (error) {
                console.error('Error loading services:', error);
                showError('Failed to load services: ' + error.message);
            }
        }

        async function loadTimeSlots() {
            const date = reservedDate.value;
            
            if (!date) {
                timeSlots.innerHTML = '<p class="text-muted">Select a date first</p>';
                return;
            }

            try {
                const response = await fetch(`../api/reservations.php?action=get_time_slots&date=${date}`);
                const data = await response.json();

                if (data.success) {
                    timeSlots.innerHTML = '';
                    availableSlots = data.slots || [];

                    if (availableSlots.length === 0) {
                        timeSlots.innerHTML = '<p class="text-muted">No available slots for this date</p>';
                        return;
                    }

                    availableSlots.forEach(slot => {
                        const btn = document.createElement('button');
                        btn.type = 'button';
                        btn.className = 'time-slot';
                        btn.setAttribute('data-value', slot);
                        btn.textContent = formatTime(slot);
                        btn.addEventListener('click', function(e) {
                            e.preventDefault();
                            // clear exact time input
                            document.getElementById('exactTimeInput').value = '';
                            document.querySelectorAll('.time-slot').forEach(b => b.classList.remove('selected'));
                            this.classList.add('selected');
                            document.getElementById('selectedTime').value = this.getAttribute('data-value');
                        });
                        timeSlots.appendChild(btn);
                    });
                }
            } catch (error) {
                console.error('Error loading time slots:', error);
            }
        }

        function formatTime(hhmm) {
            if (!hhmm) return '';
            const parts = hhmm.split(':');
            const hh = parseInt(parts[0], 10);
            const mm = parseInt(parts[1], 10);
            const period = hh >= 12 ? 'PM' : 'AM';
            let hour = hh % 12; if (hour === 0) hour = 12;
            return `${hour}:${String(mm).padStart(2,'0')} ${period}`;
        }

        // Exact time toggle and validation (PHP page)
        document.getElementById('toggleExactTime').addEventListener('click', function(){
            const input = document.getElementById('exactTimeInput');
            if (input.style.display === 'none') { input.style.display = 'block'; input.focus(); }
            else { input.style.display = 'none'; input.value = ''; }
        });

        document.getElementById('exactTimeInput').addEventListener('change', function(){
            const t = this.value;
            if (!t) return;
            if (availableSlots.length > 0 && availableSlots.indexOf(t) === -1) {
                showError('Selected time is not available. Please choose one of the available slots.');
                this.classList.add('is-invalid');
                document.getElementById('selectedTime').value = '';
            } else {
                this.classList.remove('is-invalid');
                document.querySelectorAll('.time-slot').forEach(b => b.classList.remove('selected'));
                document.getElementById('selectedTime').value = t;
            }
        });

        async function submitBooking(e) {
            // kept for backward compatibility but not used; submissions go through confirm flow
            return;
        }

        function escapeHtml(str = '') {
            const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
            return String(str).replace(/[&<>"']/g, ch => map[ch] || ch);
        }

        // Show confirmation modal
        function showConfirmModal(){
            const selectedTimeValue = document.getElementById('selectedTime').value;
            if (!selectedTimeValue) { showError('Please select a time slot'); return; }
            const formData = new FormData(form);
            const data = Object.fromEntries(formData);
            const service = services.find(s => s.id == data.service_id);
            let html = `<div><strong>Ticket Number:</strong> <span id="previewTicketNum">(will be generated)</span></div>`;
            html += `<div><strong>Name:</strong> ${data.first_name} ${data.last_name}</div>`;
            html += `<div><strong>Phone:</strong> ${data.phone}</div>`;
            html += `<div><strong>Email:</strong> ${data.email}</div>`;
            html += `<div><strong>Service:</strong> ${service ? service.name : ''}</div>`;
            html += `<div><strong>Date:</strong> ${data.reserved_date}</div>`;
            html += `<div><strong>Time:</strong> ${formatTime(data.reserved_time)}</div>`;
            html += `<div><strong>Special Requests:</strong> ${data.special_requests || '-'}</div>`;
            document.getElementById('confirmModalBody').innerHTML = html;
            const cm = new bootstrap.Modal(document.getElementById('confirmModal'));
            cm.show();
            document.getElementById('editBookingBtn').onclick = function(){ cm.hide(); };
            document.getElementById('confirmBookingBtn').onclick = function(){ cm.hide(); submitBookingConfirmed(); };
        }

        async function submitBookingConfirmed(){
            const formData = new FormData(form);
            const data = Object.fromEntries(formData);

            submitBtn.disabled = true;
            let lm = document.getElementById('loadingModal');
            let lmInstance = lm ? new bootstrap.Modal(lm) : null;
            const loadStart = Date.now();
            const minDisplay = 1000; // ms
            if (lmInstance) { lmInstance.show(); } else { loadingSpinner.style.display = 'block'; }
            successMessage.style.display = 'none';
            errorMessage.style.display = 'none';

            try {
                const response = await fetch('../api/reservations.php?action=create_reservation', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        first_name: data.first_name,
                        last_name: data.last_name,
                        email: data.email,
                        phone: data.phone,
                        reserved_date: data.reserved_date,
                        reserved_time: data.reserved_time,
                        service_id: parseInt(data.service_id),
                        weight_kg: 0,
                        special_requests: data.special_requests
                    })
                });

                const result = await response.json();

                if (result.success) {
                    form.reset();
                    const finish = () => {
                        if (lmInstance) lmInstance.hide(); else loadingSpinner.style.display = 'none';
                        successMessage.style.display = 'block';
                        successMessage.innerHTML = `<i class=\"bi bi-check-circle\"></i> Reservation successful! Your reservation number is: <strong>${result.reservation_number}</strong>`;
                        showTicketModal(result.reservation_number, data);
                        setTimeout(()=>{ successMessage.style.display = 'none'; }, 5000);
                    };
                    const elapsed = Date.now() - loadStart;
                    if (elapsed < minDisplay) { setTimeout(finish, minDisplay - elapsed); } else { finish(); }
                } else {
                    showError(result.error || 'Failed to create reservation');
                    const finishErr = () => { if (lmInstance) lmInstance.hide(); else loadingSpinner.style.display = 'none'; };
                    const elapsed = Date.now() - loadStart;
                    if (elapsed < minDisplay) { setTimeout(finishErr, minDisplay - elapsed); } else { finishErr(); }
                }
            } catch (error) {
                console.error('Error:', error);
                showError('An error occurred. Please try again.');
                const finishCatch = () => { if (lmInstance) lmInstance.hide(); else loadingSpinner.style.display = 'none'; };
                const elapsed = Date.now() - loadStart;
                if (elapsed < minDisplay) { setTimeout(finishCatch, minDisplay - elapsed); } else { finishCatch(); }
            } finally {
                submitBtn.disabled = false;
                // already scheduled hiding above; fallback only if still visible past minDisplay+200ms
                setTimeout(()=>{
                    if (lmInstance) {
                        const modalEl = document.getElementById('loadingModal');
                        if (modalEl && modalEl.classList.contains('show')) { lmInstance.hide(); }
                    } else if (loadingSpinner.style.display === 'block') {
                        loadingSpinner.style.display = 'none';
                    }
                }, minDisplay + 200);
            }
        }

        function showTicketModal(ticketNum, data){
            const service = services.find(s => s.id == data.service_id);
            const brandName = (siteSettings?.site_name || 'Laundry Co.').trim() || 'Laundry Co.';
            const brandLogo = (siteSettings?.logo || '').trim();
            const brandVisual = brandLogo
                ? `<img src="${escapeHtml(brandLogo)}" alt="${escapeHtml(brandName)} logo" class="ticket-brand-logo">`
                : '<div class="ticket-brand-icon">🧺</div>';

            let html = `<div id="ticketBox" style="background:#fff;border-radius:12px;padding:24px;text-align:center;box-shadow:0 4px 24px rgba(0,0,0,0.08);max-width:350px;margin:0 auto;">
                ${brandVisual}
                <h3>${escapeHtml(brandName)}</h3>
                <h5>Ticket #: <span>${ticketNum}</span></h5>
                <hr>
                <div><strong>Name:</strong> ${data.first_name} ${data.last_name}</div>
                <div><strong>Phone:</strong> ${data.phone}</div>
                <div><strong>Email:</strong> ${data.email}</div>
                <div><strong>Service:</strong> ${service ? service.name : ''}</div>
                <div><strong>Date:</strong> ${data.reserved_date}</div>
                <div><strong>Time:</strong> ${formatTime(data.reserved_time)}</div>
                <div><strong>Special Requests:</strong> ${data.special_requests || '-'}</div>
                <hr>
                <div><strong>Thank you for booking!</strong></div>
            </div>`;
            document.getElementById('ticketModalBody').innerHTML = html;
            const tm = new bootstrap.Modal(document.getElementById('ticketModal'));
            tm.show();
            document.getElementById('savePngBtn').onclick = function(){
                if (typeof html2canvas === 'undefined') { alert('PNG export not available'); return; }
                html2canvas(document.getElementById('ticketBox')).then(function(canvas){
                    const link = document.createElement('a');
                    link.download = `ticket_${ticketNum}.png`;
                    link.href = canvas.toDataURL();
                    link.click();
                });
            };
            // Broadcast to any open reservations page (same-origin) without forcing navigation
            try {
                if ('BroadcastChannel' in window) {
                    const bc = new BroadcastChannel('reservations_channel');
                    bc.postMessage({ type: 'reservation_created', reservation_number: ticketNum, ts: Date.now() });
                    setTimeout(()=>bc.close(), 500);
                } else {
                    // Fallback only if BC not available
                    localStorage.setItem('reservation_created_event', Date.now() + ':' + ticketNum);
                }
            } catch(e) { console.warn('Broadcast failed', e); }
        }

        function showError(message) {
            errorMessage.textContent = '❌ ' + message;
            errorMessage.style.display = 'block';
            
            setTimeout(() => {
                errorMessage.style.display = 'none';
            }, 5000);
        }

        function showDebug(msg) {
            let dbg = document.getElementById('debugBox');
            if (!dbg) {
                dbg = document.createElement('pre');
                dbg.id = 'debugBox';
                dbg.style.background = '#fff3cd';
                dbg.style.padding = '10px';
                dbg.style.borderRadius = '6px';
                dbg.style.marginTop = '12px';
                dbg.style.whiteSpace = 'pre-wrap';
                document.querySelector('.booking-container').appendChild(dbg);
            }
            dbg.textContent = msg;
        }
        // Back button logic: go to landing if no history from it
        const backBtn = document.getElementById('backBtn');
        backBtn && backBtn.addEventListener('click', () => {
            if (document.referrer && /landing\.php/i.test(document.referrer)) {
                history.back();
            } else {
                window.location.href = 'landing.php';
            }
        });
    </script>
    <!-- html2canvas: load from official CDN so PNG export works -->
    <script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
</body>
</html>

<?php
// Dynamic path handling so this file can live in /public or be moved to project root (as index.php on hosting)
$isInPublic = basename(__DIR__) === 'public';
if ($isInPublic) {
  $baseDir = dirname(__DIR__); // one level up
  require_once $baseDir . '/includes/config.php';
  require_once $baseDir . '/includes/functions.php';
  $settings = include $baseDir . '/includes/settings.php';
  $pathPrefix = '../';
} else {
  require_once __DIR__ . '/includes/config.php';
  require_once __DIR__ . '/includes/functions.php';
  $settings = include __DIR__ . '/includes/settings.php';
  $pathPrefix = 'uploads/' === 'uploads/' ? '' : ''; // keep for parity; effectively ''
  $pathPrefix = ''; // in root no prefix needed
}
// Helper to normalize any settings asset path (logo/hero etc.) to a web-visible relative src
function normalizeAssetPath($raw, $pathPrefix, $isInPublic) {
  $raw = trim($raw ?? '');
  if ($raw === '') return '';
  // Strip leading ./
  $raw = preg_replace('#^\.\/#','',$raw);
  // Remove leading ../ if followed by uploads/
  $raw = preg_replace('#^\.\./(uploads/.*)$#','$1',$raw);
  // If it already starts with uploads/ prepend prefix when inside public
  if (strpos($raw,'uploads/')===0) {
    return $pathPrefix . $raw; // e.g. ../uploads/file.png from public, uploads/file.png from root
  }
  // If user stored full path or something else, just return as-is
  return $raw;
}
// Smart logo resolver: returns [displayPath, exists]
function resolveLogo($settings, $pathPrefix, $isInPublic) {
  $raw = $settings['logo'] ?? '';
  $normalized = normalizeAssetPath($raw, $pathPrefix, $isInPublic);
  $abs = $normalized ? realpath(($isInPublic ? dirname(__DIR__) : __DIR__) . '/' . ltrim(str_replace(['../','./'],'', $normalized), '/')) : false;
  $exists = $abs && is_file($abs);
  if ($exists) {
    $mtime = @filemtime($abs);
    if ($mtime) { $normalized .= (strpos($normalized,'?')===false?'?v=':'&v=') . $mtime; }
    return [$normalized, true];
  }
  // Auto-detect newest logo_* file if configured path missing
  $uploadsDir = ($isInPublic ? dirname(__DIR__) : __DIR__) . '/uploads';
  if (is_dir($uploadsDir)) {
    $candidates = glob($uploadsDir . '/logo_*.*');
    if ($candidates) {
      usort($candidates, function($a,$b){ return filemtime($b) <=> filemtime($a); });
      $chosenAbs = $candidates[0];
      $rel = basename($chosenAbs); // logo_xxx.ext
      $webPath = $pathPrefix . 'uploads/' . $rel;
      $mtime = @filemtime($chosenAbs);
      if ($mtime) { $webPath .= (strpos($webPath,'?')===false?'?v=':'&v=') . $mtime; }
      return [$webPath, true];
    }
  }
  return [$normalized, false];
}
if (!is_array($settings)) {
  $settings = [
    'site_name' => 'Laundry Co.',
    'tagline' => 'Fast • Clean • Affordable'
  ];
}
$siteName = $settings['site_name'] ?? 'Laundry Co.';
$tagline = $settings['tagline'] ?? 'Fast • Clean • Affordable';
$navColor = $settings['sidebar_color'] ?? '#2563eb';
// Added dynamic contact/address/email
$contactNumber = $settings['contact_number'] ?? '+63 912 345 6789';
$address = $settings['address'] ?? 'Your Street, City';
$email = $settings['email'] ?? ('support@' . strtolower(preg_replace('/\s+/', '', $siteName)) . '.local');
// Placeholder image configurable via settings (for hero & service cards)
$placeholderImageRaw = isset($settings['placeholder_image']) && trim($settings['placeholder_image']) !== ''
  ? trim($settings['placeholder_image'])
  : $pathPrefix . 'uploads/placeholder.svg';
// Normalize relative path if settings gave 'uploads/...'
if (strpos($placeholderImageRaw, 'uploads/') === 0) { $placeholderImageRaw = $pathPrefix . $placeholderImageRaw; }
$absPlaceholder = realpath(($isInPublic ? dirname(__DIR__) : __DIR__) . '/' . ltrim(str_replace(['../','./'],'', $placeholderImageRaw), '/'));
if ($absPlaceholder === false || !is_file($absPlaceholder)) {
  $placeholderImageRaw = $pathPrefix . 'uploads/placeholder.svg';
  $absPlaceholder = realpath(($isInPublic ? dirname(__DIR__) : __DIR__) . '/uploads/placeholder.svg');
}
$placeholderImage = $placeholderImageRaw;
// Helper to lighten a hex color by mixing with white
function lightenColor($hex, $percent = 0.85) {
  $hex = ltrim($hex, '#');
  if (strlen($hex) === 3) {
    $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
  }
  if (!preg_match('/^[0-9a-fA-F]{6}$/', $hex)) { return '#f5f5f5'; }
  $r = hexdec(substr($hex,0,2));
  $g = hexdec(substr($hex,2,2));
  $b = hexdec(substr($hex,4,2));
  $r = (int) round($r + (255 - $r) * $percent);
  $g = (int) round($g + (255 - $g) * $percent);
  $b = (int) round($b + (255 - $b) * $percent);
  return sprintf('#%02x%02x%02x', $r, $g, $b);
}
$brandLight = lightenColor($navColor, 0.90); // very light
$brandSoft = lightenColor($navColor, 0.75);  // soft text tint
// Determine contrast (white text if dark background)
function isDarkColor($hex) {
  $hex = ltrim($hex, '#');
  if (strlen($hex) === 3) { $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2]; }
  if (!preg_match('/^[0-9a-fA-F]{6}$/',$hex)) return false; // treat invalid as light
  $r = hexdec(substr($hex,0,2));
  $g = hexdec(substr($hex,2,2));
  $b = hexdec(substr($hex,4,2));
  // Perceived brightness
  $brightness = ($r * 299 + $g * 587 + $b * 114) / 1000; // 0-255 scale
  return $brightness < 128; // threshold
}
$contrastText = isDarkColor($navColor) ? '#ffffff' : '#000000';
$contrastSoft = isDarkColor($navColor) ? lightenColor('#ffffff',0.15) : $brandSoft;
$logoRaw = isset($settings['logo']) ? trim($settings['logo']) : '';
if ($logoRaw !== '') { $logoRaw = normalizeAssetPath($logoRaw, $pathPrefix, $isInPublic); }
$settings['logo'] = $logoRaw;
$services = getServices($conn); // active services
$serviceCards = array_slice($services, 0, 3); // show first 3
$serviceImageOverrides = [
  'commercial cleaning' => $pathPrefix . 'uploads/wash_and_fold.jpg',
  'delicate wash' => $pathPrefix . 'uploads/dry_cleaning.jpg',
  'express service' => $pathPrefix . 'uploads/express_service.jpg',
];
$heroRaw = isset($settings['hero_image']) && trim($settings['hero_image']) !== '' ? trim($settings['hero_image']) : $pathPrefix . 'uploads/hero_laundry.png';
if (strpos($heroRaw,'uploads/')===0) { $heroRaw = $pathPrefix . $heroRaw; }
$absHero = realpath(($isInPublic ? dirname(__DIR__) : __DIR__) . '/' . ltrim(str_replace(['../','./'],'', $heroRaw), '/'));
// Fallback to placeholder if hero image file missing
$heroImage = ($absHero && is_file($absHero)) ? $heroRaw : $placeholderImage;
$isHeroPlaceholder = !($absHero && is_file($absHero));
// Gradient placeholder variants for services (for uniqueness)
$placeholderGradients = [
  ['#f3f4f6','#e5e7eb'],
  ['#e0f2fe','#bae6fd'],
  ['#fef3c7','#fde68a'],
  ['#fce7f3','#fbcfe8'],
  ['#ede9fe','#ddd6fe']
];
$year = date('Y');
$pricingImageOverrides = [
  'starter' => $pathPrefix . 'uploads/starter.jpg',
  'popular' => $pathPrefix . 'uploads/express_service.jpg',
  'premium' => $pathPrefix . 'uploads/dry_cleaning.jpg'
];
// Social links (normalize to full URL if missing scheme)
$instagramRaw = trim($settings['instagram_url'] ?? '');
$facebookRaw  = trim($settings['facebook_url'] ?? '');
$tiktokRaw    = trim($settings['tiktok_url'] ?? '');
function normalizeLink($u){
  if ($u==='') return '';
  if (!preg_match('#^https?://#i',$u)) { $u = 'https://'.$u; }
  return $u;
}
$instagram = normalizeLink($instagramRaw);
$facebook  = normalizeLink($facebookRaw);
$tiktok    = normalizeLink($tiktokRaw);
// Precompute favicon (use logo if available else fallback to placeholder)
list($preLogoDisplay,$preLogoOk) = resolveLogo($settings,$pathPrefix,$isInPublic);
$faviconPath = $preLogoOk ? $preLogoDisplay : ($pathPrefix . 'uploads/wash_and_fold.jpg');
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title><?php echo htmlspecialchars($siteName); ?> — Fresh Made Easy</title>
    <meta name="description" content="<?php echo htmlspecialchars($siteName); ?> fast, fresh, flawless laundry and dry cleaning services." />
    <!-- Dynamic favicon from settings logo -->
    <link rel="icon" type="image/png" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link rel="apple-touch-icon" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
      tailwind.config = {
        theme: { extend: { colors: { brand: { DEFAULT: '<?php echo htmlspecialchars($navColor); ?>', dark: '<?php echo htmlspecialchars($navColor); ?>' } } } }
      }
    </script>
    <style>
      :root {
        --brand-color: <?php echo htmlspecialchars($navColor); ?>;
        --brand-light: <?php echo htmlspecialchars($brandLight); ?>;
        --brand-soft: <?php echo htmlspecialchars($brandSoft); ?>;
      }
      .brand-color { color: var(--brand-color); }
      .brand-bg { background-color: var(--brand-color); }
      .brand-border { border-color: var(--brand-color); }
      .brand-light-bg { background-color: var(--brand-light); }
      .brand-soft-text { color: var(--brand-soft); }
      .brand-btn { background-color: var(--brand-color); color:#fff; }
      .brand-btn:hover { filter:brightness(0.92); }
      .brand-outline-btn { border:1px solid var(--brand-color); color: var(--brand-color); }
      .brand-outline-btn:hover { background: var(--brand-light); }
      /* Animation helpers */
      @keyframes popIn {0%{opacity:0;transform:scale(.95);}60%{opacity:1;transform:scale(1.02);}100%{opacity:1;transform:scale(1);}}
      .animate-pop {animation: popIn .8s cubic-bezier(.16,.84,.44,1) forwards;}
      .reveal {opacity:0;transform:translateY(24px);transition:opacity .6s ease,transform .6s ease;}
      .in-view {opacity:1!important;transform:translateY(0)!important;}
      .stagger-container .reveal {transition-delay: var(--stagger,0ms);}
      @media (prefers-reduced-motion: reduce){.animate-pop,.reveal{animation:none;opacity:1;transform:none;transition:none;}}
      /* Card hover (pricing + services) */
      .interactive-card {position:relative;transition:.35s cubic-bezier(.16,.84,.44,1);border:1px solid var(--brand-light);background:#fff;}
      .interactive-card:hover {border-color: var(--brand-color);box-shadow:0 12px 30px -8px rgba(0,0,0,.18);transform:translateY(-4px);}
      .interactive-card:hover .card-accent {background:linear-gradient(to bottom,#fff,var(--brand-light));}
      .card-accent {background:#f9fafb;transition:.35s;}
      /* Hero buttons interactive hover */
      .interactive-btn {position:relative;transition:.35s cubic-bezier(.16,.84,.44,1);will-change:transform,box-shadow,background-color,color;}
    <?php if (isDarkColor($navColor)): ?>
      /* Dark theme brand color: use light background on hover for visibility */
      .interactive-btn.brand-btn:hover {transform:translateY(-4px);box-shadow:0 12px 28px -8px rgba(0,0,0,.45);background-color: var(--brand-light);color: var(--brand-color);}/* lift + swap to light */
    <?php else: ?>
      .interactive-btn.brand-btn:hover {transform:translateY(-4px);box-shadow:0 12px 28px -8px rgba(0,0,0,.35);background-color: var(--brand-color);filter:brightness(1.15);}/* lift + brighten */
    <?php endif; ?>
      .interactive-btn.brand-outline-btn:hover {transform:translateY(-4px);box-shadow:0 12px 28px -8px rgba(0,0,0,.25);background: var(--brand-light);color: var(--brand-color);}/* fill light bg */
      .interactive-btn:active {transform:translateY(-2px);}
      .interactive-btn:focus {outline:2px solid var(--brand-color); outline-offset:2px;}
    </style>
  </head>
  <body class="antialiased text-gray-800 bg-white">
    <!-- NAVBAR -->
    <header class="fixed w-full z-40">
      <nav class="backdrop-blur shadow-sm" style="background-color: <?php echo htmlspecialchars($navColor); ?>; color: <?php echo htmlspecialchars($contrastText); ?>;">
        <div class="max-w-6xl mx-auto px-4 md:px-6 lg:px-8">
          <div class="flex items-center justify-between h-16">
            <a href="#" class="flex items-center gap-3">
              <?php list($logoDisplay,$logoOk) = resolveLogo($settings,$pathPrefix,$isInPublic); ?>
              <!-- debug: logoDisplay=<?php echo htmlspecialchars($logoDisplay); ?> logoOk=<?php echo $logoOk ? '1':'0'; ?> rawSetting=<?php echo htmlspecialchars($settings['logo'] ?? ''); ?> -->
              <?php if ($logoOk && $logoDisplay !== ''): ?>
                <img src="<?php echo htmlspecialchars($logoDisplay); ?>" alt="<?php echo htmlspecialchars($siteName); ?> logo" class="w-10 h-10 rounded-lg object-cover bg-white/10 border border-white/30" />
              <?php else: ?>
                <?php $initials = trim($siteName) !== '' ? strtoupper(mb_substr($siteName,0,1)) : 'LC'; ?>
                <div class="w-10 h-10 rounded-lg bg-white/20 flex items-center justify-center text-white font-bold"><?php echo $initials; ?></div>
              <?php endif; ?>
              <span class="text-xl font-semibold" style="color: <?php echo htmlspecialchars($contrastText); ?>; "><?php echo htmlspecialchars($siteName); ?></span>
            </a>
            <div class="hidden md:flex items-center gap-8 text-sm font-medium">
              <a href="#services" class="hover:opacity-80" style="color: <?php echo htmlspecialchars($contrastText); ?>;">Services</a>
              <a href="#how" class="hover:opacity-80" style="color: <?php echo htmlspecialchars($contrastText); ?>;">How it works</a>
              <a href="#contact" class="hover:opacity-80" style="color: <?php echo htmlspecialchars($contrastText); ?>;">Contact</a>
              <a href="book.php" class="ml-2 bg-white text-brand px-4 py-2 rounded-lg font-semibold hover:bg-blue-50 transition">Book Now</a>
            </div>
            <div class="md:hidden">
              <button id="mobileBtn" class="p-2 rounded-md text-white focus:outline-none" aria-label="Toggle menu">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8h16M4 16h16" />
                </svg>
              </button>
            </div>
          </div>
        </div>
        <div id="mobileMenu" class="md:hidden hidden px-4 pb-4" style="color: <?php echo htmlspecialchars($contrastText); ?>;">
          <div class="flex flex-col gap-3 text-sm font-medium">
            <a href="#services" class="block py-2" style="color: <?php echo htmlspecialchars($contrastText); ?>;">Services</a>
            <a href="#how" class="block py-2" style="color: <?php echo htmlspecialchars($contrastText); ?>;">How it works</a>
            <a href="#contact" class="block py-2" style="color: <?php echo htmlspecialchars($contrastText); ?>;">Contact</a>
            <a href="book.php" class="block mt-2 bg-white text-brand px-4 py-2 rounded-lg text-center font-semibold">Book Now</a>
          </div>
        </div>
      </nav>
    </header>
    <main class="pt-20">
      <!-- HERO -->
      <section class="relative overflow-hidden">
        <div class="max-w-6xl mx-auto px-4 md:px-6 lg:px-8 py-16 md:py-24">
          <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div class="z-10">
              <h1 class="text-3xl md:text-5xl font-extrabold brand-color leading-tight mb-4 animate-pop">Laundry made effortless — fast, fresh, flawless.</h1>
              <p class="text-gray-700 mb-6 max-w-xl">Reserve your drop-off, choose a service, and we'll handle the rest. Same-day express, eco-friendly options, and affordable plans.</p>
              <div class="flex gap-3 flex-wrap">
                <a href="book.php" class="inline-block brand-btn interactive-btn px-6 py-3 rounded-lg font-semibold shadow transition">Reserve Now</a>
                <a href="#services" class="inline-block brand-outline-btn interactive-btn px-5 py-3 rounded-lg font-medium transition">Our Services</a>
                <button type="button" id="openRatingModal" class="inline-block brand-outline-btn interactive-btn px-5 py-3 rounded-lg font-medium transition">Rate Us</button>
              </div>
              <div class="mt-8 flex gap-6 items-center" id="ratingBadge" hidden>
                <div class="flex items-center gap-3">
                  <div class="w-10 h-10 rounded-full brand-light-bg flex items-center justify-center brand-color font-semibold" id="avgStars">0⭐</div>
                  <div class="text-sm text-gray-600" id="avgText">Be the first to rate us</div>
                </div>
              </div>
            </div>
            <div>
              <div class="w-full rounded-2xl bg-gray-100 border border-dashed border-gray-300 h-64 md:h-80 overflow-hidden relative <?php echo $isHeroPlaceholder ? 'placeholder-target cursor-pointer' : ''; ?>" <?php if($isHeroPlaceholder): ?>data-type="hero" data-label="Hero Placeholder" data-desc="<?php echo htmlspecialchars($tagline); ?>"<?php endif; ?>>
                <img src="<?php echo htmlspecialchars($heroImage); ?>" alt="Laundry service" class="absolute inset-0 w-full h-full object-cover" onerror="this.style.display='none'; this.parentNode.innerHTML='<div class=\'w-full h-full flex items-center justify-center text-gray-400\'>placeholder</div>'" />
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- RATINGS MODAL -->
      <div id="ratingModal" class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 hidden">
        <div class="bg-white w-full max-w-md rounded-2xl shadow-xl p-6 relative">
          <button type="button" id="closeRatingModal" class="absolute top-3 right-3 text-gray-400 hover:text-gray-600" aria-label="Close">✕</button>
          <div class="text-center mb-5">
            <h2 class="text-xl font-bold brand-color">Rate <?php echo htmlspecialchars($siteName); ?></h2>
            <p class="text-gray-600 text-sm" id="ratingsSummary">Loading ratings...</p>
          </div>
          <form id="ratingForm" class="space-y-4">
            <div>
              <label class="block text-sm font-medium mb-2">Your Name (optional)</label>
              <input type="text" name="name" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand" placeholder="Jane Doe" />
            </div>
            <div>
              <label class="block text-sm font-medium mb-2">Rating</label>
              <div class="flex gap-2" id="starPicker"><!-- stars injected --></div>
              <input type="hidden" name="stars" id="starsValue" value="0" />
            </div>
            <div>
              <label class="block text-sm font-medium mb-2">Comment (optional)</label>
              <textarea name="comment" rows="3" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-brand" placeholder="Share your experience..."></textarea>
            </div>
            <button type="submit" class="brand-btn px-6 py-3 rounded-lg font-semibold shadow w-full">Submit Rating</button>
            <div class="text-sm mt-2" id="ratingMessage"></div>
          </form>
        </div>
      </div>
      <!-- SERVICES -->
      <section id="services" class="bg-white py-14">
        <div class="max-w-6xl mx-auto px-4 md:px-6 lg:px-8">
          <div class="text-center mb-10">
            <h2 class="text-3xl md:text-4xl font-bold brand-color">Our Services</h2>
            <p class="text-gray-600 mt-2 max-w-2xl mx-auto">Everything from wash & fold to premium dry cleaning — choose what fits your vibe.</p>
          </div>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-6 stagger-container">
            <?php if ($serviceCards): ?>
              <?php foreach ($serviceCards as $i => $svc): ?>
                <div class="interactive-card rounded-2xl p-6 reveal" style="--stagger: <?php echo $i * 80; ?>ms">
                  <?php
                    $grad = $placeholderGradients[$i % count($placeholderGradients)];
                    $serviceImagePath = isset($svc['image']) ? trim($svc['image']) : '';
                    if ($serviceImagePath !== '' && strpos($serviceImagePath, 'uploads/') === 0) { $serviceImagePath = $pathPrefix . $serviceImagePath; }
                    $absService = $serviceImagePath ? realpath(($isInPublic ? dirname(__DIR__) : __DIR__) . '/' . ltrim(str_replace(['../','./'],'', $serviceImagePath), '/')) : false;
                    $exists = $absService && is_file($absService);
                    // Auto-detect image if not explicitly set: try slug-based filename in uploads
                    if (!$exists) {
                      // Override mapping first
                      $nameKey = strtolower(trim($svc['name']));
                      if (isset($serviceImageOverrides[$nameKey])) {
                        $overrideCandidate = $serviceImageOverrides[$nameKey];
                        $absOverride = realpath(($isInPublic ? dirname(__DIR__) : __DIR__) . '/' . ltrim(str_replace(['../','./'],'', $overrideCandidate), '/'));
                        if ($absOverride && is_file($absOverride)) {
                          $serviceImagePath = $overrideCandidate; $exists = true;
                        }
                      }
                    }
                    if (!$exists) {
                      $slug = strtolower(preg_replace('/[^a-z0-9]+/','_', $svc['name']));
                      $candidates = [
                        $pathPrefix . "uploads/{$slug}.jpg",
                        $pathPrefix . "uploads/{$slug}.jpeg",
                        $pathPrefix . "uploads/{$slug}.png",
                        $pathPrefix . "uploads/{$slug}.webp",
                        $pathPrefix . 'uploads/wash_and_fold.jpg',
                        $pathPrefix . 'uploads/dry_cleaning.jpg'
                      ];
                      foreach ($candidates as $cand) {
                        $absCand = realpath(($isInPublic ? dirname(__DIR__) : __DIR__) . '/' . ltrim(str_replace(['../','./'],'', $cand), '/'));
                        if ($absCand && is_file($absCand)) { $serviceImagePath = $cand; $exists = true; break; }
                      }
                    }
                  ?>
                  <div class="card-accent w-full h-40 rounded-xl mb-4 overflow-hidden relative border border-gray-200" style="background: linear-gradient(135deg, <?php echo $grad[0]; ?>, <?php echo $grad[1]; ?>);">
                    <?php if ($exists): ?>
                      <img src="<?php echo htmlspecialchars($serviceImagePath); ?>" alt="<?php echo htmlspecialchars($svc['name']); ?>" class="absolute inset-0 w-full h-full object-cover" />
                    <?php else: ?>
                      <div class="absolute inset-0 flex items-center justify-center placeholder-target cursor-pointer" data-type="service" data-label="<?php echo htmlspecialchars($svc['name']); ?>" data-desc="<?php echo htmlspecialchars($svc['description'] ?: 'Quality laundry care.'); ?>">
                        <span class="text-sm font-medium text-gray-500"><?php echo htmlspecialchars(mb_substr($svc['name'],0,1)); ?></span>
                      </div>
                    <?php endif; ?>
                  </div>
                  <h3 class="font-semibold text-lg brand-color mb-2"><?php echo htmlspecialchars($svc['name']); ?></h3>
                  <p class="text-gray-600 text-sm"><?php echo htmlspecialchars($svc['description'] ?: 'Quality laundry care.'); ?></p>
                </div>
              <?php endforeach; ?>
            <?php else: ?>
              <div class="col-span-1 md:col-span-3 text-center text-sm text-gray-500">No services available yet. Add some in the dashboard.</div>
            <?php endif; ?>
          </div>
        </div>
      </section>
      <!-- HOW IT WORKS -->
      <section id="how" class="py-14 text-white" style="background-color: <?php echo htmlspecialchars($navColor); ?>;">
        <div class="max-w-4xl mx-auto px-4 md:px-6 text-center">
          <h2 class="text-3xl font-bold mb-6" style="color:#fff;">How it works</h2>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-6 stagger-container">
            <div class="bg-white p-6 rounded-2xl shadow-sm reveal" style="--stagger:0ms">
              <div class="w-14 h-14 rounded-full brand-light-bg brand-color flex items-center justify-center font-bold mb-4">1</div>
              <h4 class="font-semibold mb-2">Book a slot</h4>
              <p class="text-gray-600 text-sm">Reserve a drop-off time via the booking page.</p>
            </div>
            <div class="bg-white p-6 rounded-2xl shadow-sm reveal" style="--stagger:80ms">
              <div class="w-14 h-14 rounded-full brand-light-bg brand-color flex items-center justify-center font-bold mb-4">2</div>
              <h4 class="font-semibold mb-2">Drop your clothes</h4>
              <p class="text-gray-600 text-sm">Bring items to our shop.</p>
            </div>
            <div class="bg-white p-6 rounded-2xl shadow-sm reveal" style="--stagger:160ms">
              <div class="w-14 h-14 rounded-full brand-light-bg brand-color flex items-center justify-center font-bold mb-4">3</div>
              <h4 class="font-semibold mb-2">Pick up fresh clothes</h4>
              <p class="text-gray-600 text-sm">Grab your cleaned, neatly folded items at the scheduled time.</p>
            </div>
          </div>
        </div>
      </section>
      <!-- PRICING (static placeholders) -->
      <section class="py-14 bg-white">
        <div class="max-w-6xl mx-auto px-4 md:px-6 lg:px-8">
          <div class="text-center mb-10">
            <h2 class="text-3xl md:text-4xl font-bold brand-color">Plans & Pricing</h2>
            <p class="text-gray-600 mt-2 max-w-2xl mx-auto">Simple pricing so you always know what to expect.</p>
          </div>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-6 stagger-container">
            <div class="interactive-card p-6 rounded-2xl reveal" style="--stagger:0ms">
              <?php
                $starterImg = $pricingImageOverrides['starter'];
                $absStarter = realpath(($isInPublic ? dirname(__DIR__) : __DIR__) . '/' . ltrim(str_replace(['../','./'],'', $starterImg), '/'));
                $starterExists = $absStarter && is_file($absStarter);
              ?>
              <div class="w-full h-36 rounded-xl bg-gray-100 border border-gray-300 overflow-hidden mb-4 relative <?php echo !$starterExists?'placeholder-target cursor-pointer':''; ?>" data-type="pricing" data-label="Starter" data-desc="Wash & fold — budget-friendly">
                <?php if ($starterExists): ?>
                  <img src="<?php echo htmlspecialchars($starterImg); ?>" alt="Starter plan" class="absolute inset-0 w-full h-full object-cover" loading="lazy" />
                <?php else: ?>
                  <span class="text-gray-400 flex items-center justify-center w-full h-full">Placeholder</span>
                <?php endif; ?>
              </div>
              <h3 class="font-semibold text-lg brand-color">Starter</h3>
              <p class="text-gray-600 text-sm mb-3">Wash & fold — budget-friendly</p>
              <div class="text-lg font-bold brand-color">₱99 / kg</div>
            </div>
            <div class="interactive-card p-6 rounded-2xl reveal" style="--stagger:80ms">
              <?php
                $popularImg = $pathPrefix . 'uploads/popular.jpg';
                $absPopular = realpath(($isInPublic ? dirname(__DIR__) : __DIR__) . '/uploads/popular.jpg');
                $popularExists = $absPopular && is_file($absPopular);
              ?>
              <div class="w-full h-36 rounded-xl bg-gray-50 flex items-center justify-center mb-4 overflow-hidden relative <?php echo !$popularExists?'placeholder-target cursor-pointer':''; ?>" data-type="pricing" data-label="Popular" data-desc="Dry clean + special handling">
                <?php if ($popularExists): ?>
                  <img src="<?php echo htmlspecialchars($popularImg); ?>" alt="Popular plan" class="absolute inset-0 w-full h-full object-cover" loading="lazy" />
                <?php else: ?>
                  <span class="text-gray-400">Placeholder</span>
                <?php endif; ?>
              </div>
              <h3 class="font-semibold text-lg brand-color">Popular</h3>
              <p class="text-gray-600 text-sm mb-3">Dry clean + special handling</p>
              <div class="text-lg font-bold brand-color">₱199 / item</div>
            </div>
            <div class="interactive-card p-6 rounded-2xl reveal" style="--stagger:160ms">
              <?php
                $premiumImg = $pathPrefix . 'uploads/premium.jpg';
                $absPremium = realpath(($isInPublic ? dirname(__DIR__) : __DIR__) . '/uploads/premium.jpg');
                $premiumExists = $absPremium && is_file($absPremium);
              ?>
              <div class="w-full h-36 rounded-xl bg-gray-100 border border-gray-300 flex items-center justify-center mb-4 overflow-hidden relative <?php echo !$premiumExists?'placeholder-target cursor-pointer':''; ?>" data-type="pricing" data-label="Premium" data-desc="Express + premium detergents">
                <?php if ($premiumExists): ?>
                  <img src="<?php echo htmlspecialchars($premiumImg); ?>" alt="Premium plan" class="absolute inset-0 w-full h-full object-cover" loading="lazy" />
                <?php else: ?>
                  <span class="text-gray-400">Placeholder</span>
                <?php endif; ?>
              </div>
              <h3 class="font-semibold text-lg brand-color">Premium</h3>
              <p class="text-gray-600 text-sm mb-3">Express + premium detergents</p>
              <div class="text-lg font-bold brand-color">₱349 / service</div>
            </div>
          </div>
        </div>
      </section>
      <!-- CTA (dynamic color) -->
      <section class="py-16 text-white reveal" style="background-color: <?php echo htmlspecialchars($navColor); ?>;">
        <div class="max-w-4xl mx-auto px-4 md:px-6 text-center">
          <h2 class="text-3xl md:text-4xl font-bold mb-4">Ready to book a drop-off?</h2>
          <p class="text-blue-100 mb-6">Fast slots. Secure handling. Fresh clothes.</p>
          <a href="book.php" class="inline-block bg-white text-brand px-8 py-3 rounded-xl font-semibold hover:bg-blue-50 transition">Book a Reservation</a>
        </div>
      </section>
      <!-- FOOTER (dynamic color) -->
      <footer id="contact" class="text-white py-10" style="background-color: <?php echo htmlspecialchars($navColor); ?>;">
        <div class="max-w-6xl mx-auto px-4 md:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <div class="text-xl font-semibold mb-2"><?php echo htmlspecialchars($siteName); ?></div>
            <p class="text-sm text-blue-100"><?php echo htmlspecialchars($tagline); ?></p>
            <div class="mt-4 text-sm text-blue-100">© <?php echo $year; ?> <?php echo htmlspecialchars($siteName); ?></div>
          </div>
          <div class="text-sm">
            <div class="font-semibold mb-2">Contact</div>
            <div class="text-blue-100"><?php echo htmlspecialchars($email); ?></div>
            <div class="text-blue-100"><?php echo htmlspecialchars($contactNumber); ?></div>
            <div class="text-blue-100 mt-2">Address: <?php echo htmlspecialchars($address); ?></div>
          </div>
          <div>
            <div class="font-semibold mb-2">Follow</div>
            <div class="flex gap-3 mt-2">
              <?php if ($instagram !== ''): ?>
                <a href="<?php echo htmlspecialchars($instagram); ?>" target="_blank" rel="noopener" aria-label="Instagram" class="w-9 h-9 rounded-md bg-white/10 flex items-center justify-center text-xs hover:bg-white/20 transition">IG</a>
              <?php endif; ?>
              <?php if ($facebook !== ''): ?>
                <a href="<?php echo htmlspecialchars($facebook); ?>" target="_blank" rel="noopener" aria-label="Facebook" class="w-9 h-9 rounded-md bg-white/10 flex items-center justify-center text-xs hover:bg-white/20 transition">FB</a>
              <?php endif; ?>
              <?php if ($tiktok !== ''): ?>
                <a href="<?php echo htmlspecialchars($tiktok); ?>" target="_blank" rel="noopener" aria-label="TikTok" class="w-9 h-9 rounded-md bg-white/10 flex items-center justify-center text-xs hover:bg-white/20 transition">T</a>
              <?php endif; ?>
              <?php if ($instagram==='' && $facebook==='' && $tiktok===''): ?>
                <div class="text-xs text-blue-100">No social links configured.</div>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <div class="max-w-6xl mx-auto px-4 md:px-6 lg:px-8 mt-8 text-xs text-blue-100 text-center">By using this website you agree to our terms & privacy.</div>
      </footer>
    </main>
    <!-- Placeholder Modal -->
    <div id="placeholderModal" class="fixed inset-0 bg-black/50 backdrop-blur-sm hidden items-center justify-center z-50">
      <div class="bg-white w-full max-w-md rounded-2xl shadow-xl p-6 relative">
        <button type="button" id="closePlaceholderModal" class="absolute top-3 right-3 text-gray-400 hover:text-gray-600" aria-label="Close">✕</button>
        <div class="text-center mb-4">
          <h2 id="placeholderModalTitle" class="text-xl font-bold brand-color">Placeholder</h2>
          <p id="placeholderModalDesc" class="text-sm text-gray-600">This area will display a custom image soon.</p>
        </div>
        <div class="rounded-lg border border-dashed border-gray-300 bg-gray-50 h-40 flex items-center justify-center mb-4">
          <span id="placeholderModalSymbol" class="text-4xl text-gray-400">📦</span>
        </div>
        <div class="text-xs text-gray-500">Upload or configure an image in settings/service management to replace this placeholder.</div>
      </div>
    </div>
    <script>
      const btn = document.getElementById('mobileBtn');
      const menu = document.getElementById('mobileMenu');
      btn && btn.addEventListener('click', () => { menu.classList.toggle('hidden'); });

      // Ratings logic
      const ratingBadge = document.getElementById('ratingBadge');
      const avgStars = document.getElementById('avgStars');
      const avgText = document.getElementById('avgText');
      const ratingsSummary = document.getElementById('ratingsSummary');
      const starPicker = document.getElementById('starPicker');
      const starsValue = document.getElementById('starsValue');
      const ratingForm = document.getElementById('ratingForm');
      const ratingMessage = document.getElementById('ratingMessage');
      const ratingModal = document.getElementById('ratingModal');
      const openRatingModal = document.getElementById('openRatingModal');
      const closeRatingModal = document.getElementById('closeRatingModal');
      openRatingModal && openRatingModal.addEventListener('click', ()=> { ratingModal.classList.remove('hidden'); });
      closeRatingModal && closeRatingModal.addEventListener('click', ()=> { ratingModal.classList.add('hidden'); });
      ratingModal && ratingModal.addEventListener('click', (e)=> { if(e.target === ratingModal){ ratingModal.classList.add('hidden'); } });

      function renderStars(selected=0){
        starPicker.innerHTML='';
        for(let i=1;i<=5;i++){
          const b=document.createElement('button');
          b.type='button';
          b.className='w-10 h-10 rounded-md flex items-center justify-center text-xl transition ' + (i<=selected? 'brand-color bg-brand-light/40':'bg-white text-gray-400 border border-gray-200');
          b.innerHTML='★';
          b.setAttribute('data-star',i);
          b.addEventListener('click',()=>{ starsValue.value=i; renderStars(i); });
          starPicker.appendChild(b);
        }
      }
      renderStars(0);

      async function loadRatingStats(){
        try{
          const r = await fetch('../api/ratings.php?action=get_stats');
          const data = await r.json();
          if(!data.success){ ratingsSummary.textContent='Unable to load ratings.'; return; }
          const avg = data.average;
          const total = data.total;
          if(total>0){
            ratingBadge.hidden=false;
            avgStars.textContent=avg.toFixed(1)+'⭐';
            avgText.textContent=avg.toFixed(1)+' average rating • '+total+' review'+(total>1?'s':'');
            ratingsSummary.textContent='Average '+avg.toFixed(1)+' from '+total+' rating'+(total>1?'s':'');
          } else {
            ratingsSummary.textContent='No ratings yet. Be the first!';
          }
        }catch(e){ ratingsSummary.textContent='Error loading ratings.'; }
      }
      loadRatingStats();

      ratingForm.addEventListener('submit', async (e)=>{
        e.preventDefault();
        ratingMessage.textContent='';
        const stars = parseInt(starsValue.value,10);
        if(stars<1){ ratingMessage.textContent='Please select a star rating.'; ratingMessage.className='text-red-600'; return; }
        const formData = new FormData(ratingForm);
        const payload = Object.fromEntries(formData.entries());
        try{
          const resp = await fetch('../api/ratings.php?action=create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
          const result = await resp.json();
          if(result.success){
            ratingMessage.textContent='Thank you! Your rating was recorded.';
            ratingMessage.className='text-green-600';
            ratingForm.reset(); starsValue.value=0; renderStars(0); loadRatingStats();
            setTimeout(()=>{ ratingModal.classList.add('hidden'); },1200);
          } else {
            ratingMessage.textContent=result.error||'Submission failed.';
            ratingMessage.className='text-red-600';
          }
        }catch(err){
          ratingMessage.textContent='Network error.';
          ratingMessage.className='text-red-600';
        }
      });

      // Intersection Observer to trigger reveal animations
      // Repeatable reveal + pop animations
      const revealEls = document.querySelectorAll('.reveal');
      const popEls = document.querySelectorAll('.animate-pop');
      const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      function retriggerPop(el){
        if(prefersReduced) return;
        el.classList.remove('animate-pop');
        void el.offsetWidth; // force reflow
        el.classList.add('animate-pop');
      }
      const io = new IntersectionObserver((entries)=>{
        entries.forEach(entry=>{
          const el = entry.target;
          if(entry.isIntersecting){
            el.classList.add('in-view');
            if(el.classList.contains('animate-pop')){ retriggerPop(el); }
          } else {
            // remove so it can animate again when re-entering
            el.classList.remove('in-view');
            if(el.classList.contains('animate-pop')){ el.classList.remove('animate-pop'); }
          }
        });
      },{threshold:0.2});
      revealEls.forEach(el=> io.observe(el));
      popEls.forEach(el=> io.observe(el));

      // Placeholder click popup logic
      const placeholderModal = document.getElementById('placeholderModal');
      const closePlaceholderModal = document.getElementById('closePlaceholderModal');
      const modalTitle = document.getElementById('placeholderModalTitle');
      const modalDesc = document.getElementById('placeholderModalDesc');
      const modalSymbol = document.getElementById('placeholderModalSymbol');
      function openPlaceholder(label,type,customDesc){
        modalTitle.textContent = label || 'Placeholder';
        let desc = customDesc && customDesc.trim() !== '' ? customDesc : '';
        if(desc === ''){
          switch(type){
            case 'hero': desc = 'Hero section image placeholder. Configure a hero image in settings.'; modalSymbol.textContent='🖼️'; break;
            case 'service': desc = 'Service image placeholder. Upload an image for this service.'; modalSymbol.textContent='🧺'; break;
            case 'pricing': desc = 'Pricing plan image placeholder. Replace with a plan illustration soon.'; modalSymbol.textContent='💲'; break;
            default: desc = 'This area will display a custom image soon.'; modalSymbol.textContent='📦';
          }
        } else {
          switch(type){
            case 'hero': modalSymbol.textContent='🖼️'; break;
            case 'service': modalSymbol.textContent='🧺'; break;
            case 'pricing': modalSymbol.textContent='💲'; break;
            default: modalSymbol.textContent='📦';
          }
        }
        modalDesc.textContent = desc;
        placeholderModal.classList.remove('hidden');
        placeholderModal.classList.add('flex');
      }
      document.querySelectorAll('.placeholder-target').forEach(el => {
        el.addEventListener('click', () => {
          openPlaceholder(el.getAttribute('data-label'), el.getAttribute('data-type'), el.getAttribute('data-desc'));
        });
      });
      closePlaceholderModal && closePlaceholderModal.addEventListener('click', ()=>{
        placeholderModal.classList.add('hidden');
        placeholderModal.classList.remove('flex');
      });
      placeholderModal && placeholderModal.addEventListener('click', (e)=>{ if(e.target === placeholderModal){ placeholderModal.classList.add('hidden'); placeholderModal.classList.remove('flex'); } });
    </script>
  </body>
</html>
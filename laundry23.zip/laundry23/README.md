# 🧺 Laundry Co. POS System

A complete Point of Sale (POS) and Reservation Management System for laundry businesses built with PHP, JavaScript, HTML, CSS, and MySQL.

## Features

- **Walk-In Orders Management**: Create, track, and manage walk-in customer orders
- **Online Reservations**: Customers can book services online with available time slots
- **Payment Tracking**: Record payments with multiple methods (Cash, Card, Online)
- **Customer Management**: Track customer information and history
- **Order Status Tracking**: Pending → Processing → Completed → Ready for Pickup
- **Dashboard**: Real-time statistics and recent orders overview
- **Responsive Design**: Mobile-friendly interface
- **Service Management**: Multiple laundry services with customizable pricing

## System Requirements

- **Web Server**: Apache (XAMPP)
- **PHP**: 7.4 or higher
- **Database**: MySQL 5.7 or higher
- **Browser**: Modern browser (Chrome, Firefox, Edge, Safari)

## Installation Guide

### Step 1: Prepare the Database

1. Open **phpMyAdmin** (usually at `http://localhost/phpmyadmin`)
2. Create a new database or use the SQL file:
   - Click "New" or "Create database"
   - Enter database name: `laundry_pos`
   - Click Create
3. Select the database and click "Import"
4. Choose the `database.sql` file from the laundry folder
5. Click "Go" to execute the SQL

### Step 2: Verify Database Connection

1. Open `includes/config.php`
2. Check database credentials match your XAMPP setup:
   - **DB_HOST**: localhost (default)
   - **DB_USER**: root (default for XAMPP)
   - **DB_PASSWORD**: (empty by default)
   - **DB_NAME**: laundry_pos

### Step 3: Start XAMPP Services

1. Open XAMPP Control Panel
2. Start **Apache** and **MySQL** services
3. Both should show "Running" status

### Step 4: Access the System

#### POS Dashboard (Staff/Admin)
- **URL**: `http://localhost/laundry2/login.php`
- **Default Credentials**:
  - Username: `admin`
  - Password: `admin123` (hash: $2y$10$YrDMxR8kAR/3bOE3c8Zp6OJ7Y3x9c4L5g1H6iP9j0K1m2N3o4Q5r6)

#### Customer Booking Page (Public)
- **URL**: `http://localhost/laundry2/public/book.php`
- No login required - customers can book directly

## Project Structure

```
laundry2/
├── api/
│   ├── orders.php          # Order management API
│   ├── reservations.php    # Reservation management API
│   └── customers.php       # Customer data API
├── css/
│   └── style.css           # Main stylesheet
├── js/
│   ├── walk_in_orders.js   # Order form logic
│   └── reservations.js     # Reservation management logic
├── pages/
│   ├── dashboard.php       # Main dashboard
│   ├── walk_in_orders.php  # Orders page
│   ├── reservations.php    # Reservations page
│   ├── customers.php       # Customers page
│   └── settings.php        # Settings (for admin)
├── public/
│   └── book.php            # Customer booking page
├── includes/
│   ├── config.php          # Database configuration
│   ├── auth.php            # Authentication logic
│   ├── functions.php       # Helper functions
│   └── logout.php          # Logout handler
├── uploads/                # For future file uploads
├── database.sql            # Database schema
└── login.php               # Login page
```

## Database Tables

- **users**: Staff and admin accounts
- **services**: Laundry services with pricing
- **customers**: Customer information
- **orders**: Walk-in orders
- **order_items**: Items in each order
- **payments**: Payment records
- **reservations**: Online reservations

## How to Use

### For POS Staff

1. **Login** with admin credentials
2. **Create Walk-In Order**:
   - Click "New Order" button
   - Enter customer information
   - Select services and quantities
   - System calculates total automatically
   - Click "Create Order"
3. **Manage Orders**:
   - View all orders from dashboard
   - Click order to view details
   - Update order status (Pending → Processing → Completed)
   - Record payments
4. **Check Reservations**:
   - View all online reservations
   - Update reservation status
   - See customer details and special requests

### For Customers

1. Go to **`http://localhost/laundry2/public/book.php`**
2. **Fill in Information**:
   - Personal details (name, phone, email)
   - Select service
   - Enter weight in kg
3. **Select Date & Time**:
   - Choose preferred date
   - Available time slots appear automatically
   - System blocks booked times
4. **Add Special Requests** (optional)
5. **Review Estimate**: See total cost calculation
6. **Submit**: Click "Book Now"
7. **Confirmation**: Receive reservation number

## Key Features Explained

### Order Management
- Walk-in orders tracked from creation to pickup
- Multiple services per order
- Automatic calculation of totals
- Payment history and outstanding balance tracking

### Reservations
- Customers book online with available time slots
- System prevents overbooking with slot management
- 30-minute intervals for bookings
- Estimated cost calculation based on weight

### Dashboard
- Today's orders count
- Pending orders overview
- Daily revenue tracking
- Total customer count
- Recent orders display
- **Responsive layout for desktop, tablet, and mobile** (Bootstrap 5 + shared `app-shell` classes in `css/style.css`)

### Payment Tracking
- Record multiple payments per order
- Multiple payment methods supported
- Automatic payment status updates
- Payment history per order

## Customization Guide

### Add New Service

1. Login as admin
2. Go to Settings (future page - for now use phpMyAdmin)
3. In `services` table, insert new row:
   - name: "Dry Cleaning"
   - base_price: 10.00
   - price_per_kg: 0.50
   - turnaround_hours: 48

### Modify Pricing

Update in `includes/functions.php`:
```php
// Change service pricing
$service['base_price'] = 15.00;  // Base charge
$service['price_per_kg'] = 3.00; // Per kilogram
```

### Change Available Time Slots

In `api/reservations.php`, modify this section:
```php
$start = strtotime('08:00');  // Start time
$end = strtotime('18:00');    // End time
$interval = 30 * 60;          // 30-minute intervals
```

## Troubleshooting

### "Database connection failed"
- Check MySQL is running in XAMPP
- Verify database name and credentials in `config.php`
- Make sure `laundry_pos` database exists

### Orders not loading
- Check browser console (F12) for JavaScript errors
- Verify API endpoints are accessible
- Confirm database tables have data

### Time slots not showing
- Date must be today or later
- Check database for existing reservations
- Verify time slots haven't all been booked

### Login fails
- Use correct credentials: `admin` / `admin123`
- Check sessions are enabled in PHP
- Clear browser cookies if issues persist

## API Endpoints

### Orders API
- `POST /api/orders.php?action=create_order` - Create new order
- `GET /api/orders.php?action=get_orders` - Get all orders
- `POST /api/orders.php?action=update_order_status` - Update order status
- `POST /api/orders.php?action=record_payment` - Record payment
- `GET /api/orders.php?action=get_order&id=1` - Get order details

### Reservations API
- `POST /api/reservations.php?action=create_reservation` - Create reservation
- `GET /api/reservations.php?action=get_reservations` - Get all reservations
- `POST /api/reservations.php?action=update_reservation_status` - Update status
- `GET /api/reservations.php?action=get_time_slots&date=2025-01-15` - Get available slots
- `GET /api/reservations.php?action=get_services` - Get all services

## Security Notes

- **Default password should be changed immediately** in production
- Use HTTPS in production environment
- Implement proper input validation (already included)
- Add rate limiting for public booking page
- Regular database backups recommended
- Set proper file permissions on upload directory

## Future Enhancements

- Multi-user support with role-based access
- Email notifications for reservations
- SMS notifications
- Advanced analytics and reporting
- Inventory management for supplies
- Loyalty program implementation
- Integration with payment gateways
- Receipt printing functionality

## Technical Stack

- **Frontend**: HTML5, CSS3, Bootstrap 5, JavaScript
- **Backend**: PHP 7.4+
- **Database**: MySQL 5.7+
- **Server**: Apache (XAMPP)
- **API**: RESTful JSON APIs
- **Icons**: Bootstrap Icons
- **Layout helpers**: Reusable responsive classes (`app-shell`, `app-container`, `booking-layout`, etc.) in `css/style.css`

## Support

For issues or questions:
1. Check the Troubleshooting section
2. Verify all requirements are met
3. Check browser console for errors (F12)
4. Review PHP error logs in XAMPP

## License

This project is provided as-is for educational and commercial use.

---

**Last Updated**: November 2025
**Version**: 1.0
**Author**: Development Team

<?php
// Example variables (replace with actual order data)
$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : 'ORD-20251126115420-5827';
$customer_name = 'andrei wrwer';
$customer_phone = '08769745693';
$customer_email = 'andrei@gmail.com';
$order_date = '2025-11-27 13:50';
$order_status = 'Pending';
$order_due = '2025-11-27 11:54:20';
$items = [
    ['name' => 'Delicate Wash', 'qty' => 3, 'unit' => 'Kg', 'price' => 36.00],
];
$total = 36.00;
$paid = 0.00;
$outstanding = $total - $paid;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Receipt - Selftest Format</title>
    <style>
        body {
            font-family: 'Courier New', Courier, monospace;
            font-size: 15px;
            margin: 0;
            padding: 0;
            background: #fff;
        }
        .receipt {
            width: 320px;
            margin: 0 auto;
            padding: 10px 0 0 0;
        }
        .header-arrows {
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            letter-spacing: 2px;
        }
        .header-title {
            text-align: center;
            font-size: 32px;
            font-weight: bold;
            margin: 0;
            letter-spacing: 2px;
        }
        .qr {
            display: flex;
            justify-content: center;
            margin: 10px 0 10px 0;
        }
        .section {
            margin-bottom: 8px;
        }
        .divider {
            border-top: 2px dashed #000;
            margin: 10px 0;
        }
        .barcode-label {
            font-size: 15px;
            margin-bottom: 2px;
        }
        .barcode-img {
            width: 100%;
            height: 60px;
            background: repeating-linear-gradient(90deg, #000 0 2px, #fff 2px 8px);
        }
        .barcode-types {
            font-size: 13px;
            margin-top: 8px;
            margin-bottom: 8px;
        }
        .chars {
            font-size: 12px;
            letter-spacing: 2px;
            margin-top: 8px;
        }
        .footer {
            margin-top: 10px;
            text-align: center;
            font-size: 18px;
            font-weight: bold;
        }
        .info-table {
            width: 100%;
            font-size: 15px;
            border-collapse: collapse;
        }
        .info-table td {
            padding: 0;
        }
        .order-table {
            width: 100%;
            font-size: 15px;
            border-collapse: collapse;
        }
        .order-table th, .order-table td {
            padding: 0;
        }
        .order-table th {
            text-align: left;
        }
        .order-table td {
            text-align: right;
        }
        .order-table td:first-child {
            text-align: left;
        }
    </style>
</head>
<body onload="window.print()">
    <div class="receipt">
        <div class="header-arrows">&gt;&gt;&gt; Please keep this receipt. &lt;&lt;&lt;</div>
        <div class="header-title">&gt;&gt;Laundry&lt;&lt;</div>
        <div class="qr">
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=<?php echo urlencode($order_id); ?>" alt="QR Code" width="100" height="100">
        </div>
        <div class="section">
            <table class="info-table">
                <tr><td>Order ID:</td><td><?php echo $order_id; ?></td></tr>
                <tr><td>Date:</td><td><?php echo $order_date; ?></td></tr>
                <tr><td>Status:</td><td><?php echo $order_status; ?></td></tr>
                <tr><td>Due:</td><td><?php echo $order_due; ?></td></tr>
                <tr><td>Customer:</td><td><?php echo htmlspecialchars($customer_name); ?></td></tr>
                <tr><td>Phone:</td><td><?php echo htmlspecialchars($customer_phone); ?></td></tr>
                <tr><td>Email:</td><td><?php echo htmlspecialchars($customer_email); ?></td></tr>
            </table>
        </div>
        <div class="divider"></div>
        <div class="section">
            <table class="order-table">
                <tr><th>Item</th><th>Kg</th><th>Amt</th></tr>
                <?php foreach ($items as $item): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td><?php echo $item['qty']; ?></td>
                    <td>&#8369;<?php echo number_format($item['price'], 2); ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <div class="divider"></div>
        <table class="order-table">
            <tr><td>Total</td><td></td><td>&#8369;<?php echo number_format($total, 2); ?></td></tr>
            <tr><td>Paid</td><td></td><td>&#8369;<?php echo number_format($paid, 2); ?></td></tr>
            <tr><td>Outstanding</td><td></td><td>&#8369;<?php echo number_format($outstanding, 2); ?></td></tr>
        </table>
        <div class="divider"></div>
        <div class="barcode-label">[Barcode Samples]<br>CODE 39:</div>
        <div class="barcode-img"></div>
        <div class="barcode-types">
            Barcode Type<br>
            CODE UPC-A&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CODE UPC-E<br>
            CODE EAN(JAN)13&nbsp;&nbsp;&nbsp;&nbsp;CODE EAN(JAN)8<br>
            CODE 39&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CODEBAR<br>
            CODE ITF&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;CODE CODE93<br>
            CODE 128&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;QR CODE<br>
        </div>
        <div class="divider"></div>
        <div class="chars">
            !"#$%&'()*+,-./0123456789:;&lt;=&gt;?@
            ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_
            `abcdefghijklmnopqrstuvwxyz{|}~
        </div>
        <div class="footer">Completed</div>
    </div>
</body>
</html>

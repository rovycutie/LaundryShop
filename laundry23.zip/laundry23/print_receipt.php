<?php
// Example dynamic data (replace with your actual variables)
$reservation_id = 'RES-20251126115018-7386';
$date = '2025-11-27 14:10';
$status = 'Pending';
$reserved = '2025-11-27 11:00:00';
$customer = 'andrei cote';
$phone = '08769745693';
$email = 'andrei@gmail.com';
$service = 'Express Service';
$weight = '0.00 kg';
$cost = '₱10.00';
$notes = 'g';
$total = '₱10.00';
$paid = '₱0.00';
$outstanding = '₱10.00';
// ESC/POS plain text for QZ Tray
$escpos_receipt = "Dr. HYGIENE\nReservation Receipt\n-----------------------------\nReservation #: $reservation_id\nDate: $date\nStatus: $status\nReserved: $reserved\nCustomer: $customer\nPhone: $phone\nEmail: $email\n-----------------------------\nService: $service\nWeight: $weight\nEst. Cost: $cost\n-----------------------------\nNotes: $notes\n-----------------------------\nTotal: $total\nPaid: $paid\nOutstanding: $outstanding\n-----------------------------\nThank you!\nNo refunds after 24 hours.\nPlease keep this receipt.\n";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reservation Receipt</title>
    <style>
        @font-face {
            font-family: 'PxPlus IBM VGA8';
            src: url('https://int10h.org/oldschool-pc-fonts/download/pxplus_ibm_vga8.ttf') format('truetype');
        }
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            background: #fefcf7 url('https://www.transparenttextures.com/patterns/paper-fibers.png');
        }
        body, .receipt, * {
            font-family: 'PxPlus IBM VGA8', monospace !important;
            color: #000;
            letter-spacing: 0.03em;
            font-size: 14px;
            box-sizing: border-box;
        }
        .receipt {
            width: 320px;
            margin: 30px auto 0 auto;
            padding: 10px 0 0 0;
            background: #fefcf7;
            border: 1px solid #eee;
            box-shadow: 0 0 8px #eee;
        }
        .header-title {
            text-align: center;
            font-size: 22px;
            font-weight: bold;
            margin: 0;
            letter-spacing: 0.08em;
        }
        .subtitle {
            text-align: center;
            font-size: 16px;
            margin-bottom: 10px;
        }
        .divider {
            border-top: 2px dashed #000;
            margin: 10px 0;
        }
        .info-table {
            width: 100%;
            font-size: 14px;
            border-collapse: collapse;
        }
        .info-table td {
            padding: 0;
        }
        .order-table {
            width: 100%;
            font-size: 14px;
            border-collapse: collapse;
        }
        .order-table th, .order-table td {
            padding: 0;
        }
        .order-table th {
            text-align: left;
        }
        .order-table td {
            text-align: right;
        }
        .order-table td:first-child {
            text-align: left;
        }
        .footer {
            margin-top: 10px;
            text-align: center;
            font-size: 16px;
            font-weight: bold;
        }
        .print-btn {
            display: block;
            margin: 20px auto 0 auto;
            padding: 8px 24px;
            font-size: 16px;
            font-family: inherit;
            background: #eee;
            border: 1px solid #ccc;
            border-radius: 4px;
            cursor: pointer;
        }
        @media print {
            .print-btn { display: none; }
            html, body { background: #fefcf7 !important; }
            .receipt { box-shadow: none; border: none; }
        }
    </style>
    <script src="https://qz.io/js/qz-tray.js"></script>
    <script>
        function printQZ() {
            var data = document.getElementById('escpos-data').value;
            qz.websocket.connect().then(function() {
                return qz.printers.find();
            }).then(function(printers) {
                // Use default printer or specify your printer name
                var config = qz.configs.create(printers[0]);
                var printData = [{ type: 'raw', format: 'plain', data: data }];
                return qz.print(config, printData);
            }).then(function() {
                alert('Receipt sent to printer!');
                qz.websocket.disconnect();
            }).catch(function(e) {
                alert('Printing failed: ' + e);
            });
        }
    </script>
    <script>
    function printReceiptWithQZ() {
        if (!window.qz) {
            alert('QZ Tray is not loaded.');
            return;
        }
        qz.websocket.connect().then(function() {
            // Example: Print the receipt content
            var data = [{ type: 'raw', format: 'plain', data: document.body.innerText }];
            return qz.print(config, data);
        }).catch(function(e) {
            alert('Could not connect to QZ Tray: ' + e);
        });
    }
    // Example config for default printer
    var config = qz.configs.create(null); // null = default printer
    </script>
</head>
<body>
    <div class="receipt">
        <div class="header-title">Dr. HYGIENE</div>
        <div class="subtitle">Reservation Receipt</div>
        <div class="divider"></div>
        <table class="info-table">
            <tr><td>Reservation #:</td><td><?php echo $reservation_id; ?></td></tr>
            <tr><td>Date:</td><td><?php echo $date; ?></td></tr>
            <tr><td>Status:</td><td><?php echo $status; ?></td></tr>
            <tr><td>Reserved:</td><td><?php echo $reserved; ?></td></tr>
            <tr><td>Customer:</td><td><?php echo $customer; ?></td></tr>
            <tr><td>Phone:</td><td><?php echo $phone; ?></td></tr>
            <tr><td>Email:</td><td><?php echo $email; ?></td></tr>
        </table>
        <div class="divider"></div>
        <table class="order-table">
            <tr><th>Service</th><th>Service</th></tr>
            <tr><td>Weight</td><td><?php echo $weight; ?></td></tr>
            <tr><td>Est. Cost</td><td><?php echo $cost; ?></td></tr>
        </table>
        <div class="divider"></div>
        <table class="order-table">
            <tr><td>Notes:</td><td><?php echo $notes; ?></td></tr>
        </table>
        <div class="divider"></div>
        <table class="order-table">
            <tr><td>Total</td><td><?php echo $total; ?></td></tr>
            <tr><td>Paid</td><td><?php echo $paid; ?></td></tr>
            <tr><td>Outstanding</td><td><?php echo $outstanding; ?></td></tr>
        </table>
        <div class="divider"></div>
        <div class="footer">
            Thank you!<br>
            No refunds after 24 hours.<br>
            Please keep this receipt.
        </div>
    </div>
    <textarea id="escpos-data" style="display:none;"><?php echo $escpos_receipt; ?></textarea>
    <button class="print-btn" onclick="printQZ()">Print Receipt (Thermal)</button>
</body>
</html>

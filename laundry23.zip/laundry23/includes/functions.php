<?php
require_once __DIR__ . '/config.php';

// Generate unique order number
function generateOrderNumber() {
    return 'ORD-' . date('YmdHis') . '-' . rand(1000, 9999);
}

// Generate unique reservation number
function generateReservationNumber() {
    return 'RES-' . date('YmdHis') . '-' . rand(1000, 9999);
}

// Format currency
function formatCurrency($amount) {
    return '₱' . number_format($amount, 2);
}

// Get order status badge color
function getStatusBadge($status) {
    $colors = [
        'pending' => 'warning',
            'processing' => 'info',
            'completed' => 'success',
            'ready_for_pickup' => 'success',
            'cancelled' => 'danger',
            'confirmed' => 'info'
    ];
    return $colors[$status] ?? 'secondary';
}

// Calculate due date
function calculateDueDate($hours = 24) {
    $tz = new DateTimeZone('Asia/Manila');
    $dt = new DateTime('now', $tz);
    $dt->add(new DateInterval('PT' . (int)$hours . 'H'));
    return $dt->format('Y-m-d H:i:s');
}

// Sanitize input
function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Get services (active by default, optionally include inactive)
function getServices($conn, $includeInactive = false) {
    if ($includeInactive) {
        $query = "SELECT * FROM services ORDER BY name";
    } else {
        $query = "SELECT * FROM services WHERE is_active = 1 ORDER BY name";
    }
    $result = $conn->query($query);
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Get customer by phone
function getCustomerByPhone($conn, $phone) {
    $query = "SELECT * FROM customers WHERE phone = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $phone);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

// Create or update customer
function saveCustomer($conn, $first_name, $last_name, $email, $phone, $address = '', $city = '') {
    $customer = getCustomerByPhone($conn, $phone);
    
    if ($customer) {
        $query = "UPDATE customers SET first_name = ?, last_name = ?, email = ?, address = ?, city = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssssi", $first_name, $last_name, $email, $address, $city, $customer['id']);
        $stmt->execute();
        return $customer['id'];
    } else {
        $query = "INSERT INTO customers (first_name, last_name, email, phone, address, city) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssssss", $first_name, $last_name, $email, $phone, $address, $city);
        $stmt->execute();
        return $conn->insert_id;
    }
}

// Get dashboard statistics
function getDashboardStats($conn) {
    $today = date('Y-m-d');

    // Ensure reservation payments table exists so revenue queries do not fail
    if (function_exists('ensureReservationPaymentsTable')) {
        ensureReservationPaymentsTable($conn);
    }

    $stats = [
        'today_orders' => 0,
        'pending_orders' => 0,
        'daily_revenue' => 0,
        'week_revenue' => 0,
        'month_revenue' => 0,
        'year_revenue' => 0,
        'total_customers' => 0,
        'walk_in_total' => 0,
        'reservation_total' => 0,
        'walk_in_percent' => 0,
        'reservation_percent' => 0
    ];

    // Today's orders (walk-in orders + reservations)
    $result = $conn->query("SELECT COUNT(*) as count FROM orders WHERE DATE(created_at) = '{$today}'");
    $stats['today_orders'] = (int)($result->fetch_assoc()['count'] ?? 0);
    $result = $conn->query("SELECT COUNT(*) as count FROM reservations WHERE DATE(created_at) = '{$today}'");
    $stats['today_orders'] += (int)($result->fetch_assoc()['count'] ?? 0);

    // Pending work (walk-in orders pending/processing + reservations pending/confirmed)
    $result = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status IN ('pending','processing')");
    $stats['pending_orders'] = (int)($result->fetch_assoc()['count'] ?? 0);
    $result = $conn->query("SELECT COUNT(*) as count FROM reservations WHERE status IN ('pending','confirmed')");
    $stats['pending_orders'] += (int)($result->fetch_assoc()['count'] ?? 0);

    // Revenue based strictly on recorded payments, not order status/totals
    // Daily
    $result = $conn->query("SELECT COALESCE(SUM(amount),0) AS total FROM payments WHERE DATE(payment_date)=CURDATE()");
    $stats['daily_revenue'] = (float)($result->fetch_assoc()['total'] ?? 0);
    $result = $conn->query("SELECT COALESCE(SUM(amount),0) AS total FROM reservation_payments WHERE DATE(payment_date)=CURDATE()");
    $stats['daily_revenue'] += (float)($result->fetch_assoc()['total'] ?? 0);

    // Week (ISO week)
    $result = $conn->query("SELECT COALESCE(SUM(amount),0) AS total FROM payments WHERE YEARWEEK(payment_date,1)=YEARWEEK(CURDATE(),1)");
    $stats['week_revenue'] = (float)($result->fetch_assoc()['total'] ?? 0);
    $result = $conn->query("SELECT COALESCE(SUM(amount),0) AS total FROM reservation_payments WHERE YEARWEEK(payment_date,1)=YEARWEEK(CURDATE(),1)");
    $stats['week_revenue'] += (float)($result->fetch_assoc()['total'] ?? 0);

    // Month
    $result = $conn->query("SELECT COALESCE(SUM(amount),0) AS total FROM payments WHERE YEAR(payment_date)=YEAR(CURDATE()) AND MONTH(payment_date)=MONTH(CURDATE())");
    $stats['month_revenue'] = (float)($result->fetch_assoc()['total'] ?? 0);
    $result = $conn->query("SELECT COALESCE(SUM(amount),0) AS total FROM reservation_payments WHERE YEAR(payment_date)=YEAR(CURDATE()) AND MONTH(payment_date)=MONTH(CURDATE())");
    $stats['month_revenue'] += (float)($result->fetch_assoc()['total'] ?? 0);

    // Year
    $result = $conn->query("SELECT COALESCE(SUM(amount),0) AS total FROM payments WHERE YEAR(payment_date)=YEAR(CURDATE())");
    $stats['year_revenue'] = (float)($result->fetch_assoc()['total'] ?? 0);
    $result = $conn->query("SELECT COALESCE(SUM(amount),0) AS total FROM reservation_payments WHERE YEAR(payment_date)=YEAR(CURDATE())");
    $stats['year_revenue'] += (float)($result->fetch_assoc()['total'] ?? 0);

    // Total unique customers (from customers table or standalone reservations)
    $result = $conn->query("SELECT COUNT(*) as count FROM (
                                SELECT DISTINCT phone FROM customers WHERE phone IS NOT NULL AND phone <> ''
                                UNION
                                SELECT DISTINCT phone FROM reservations WHERE phone IS NOT NULL AND phone <> '' AND status = 'completed'
                            ) AS unique_customers");
    $stats['total_customers'] = (int)($result->fetch_assoc()['count'] ?? 0);

    $result = $conn->query("SELECT COUNT(*) as count FROM orders");
    $stats['walk_in_total'] = (int)($result->fetch_assoc()['count'] ?? 0);

    $result = $conn->query("SELECT COUNT(*) as count FROM reservations");
    $stats['reservation_total'] = (int)($result->fetch_assoc()['count'] ?? 0);

    $totalOrders = $stats['walk_in_total'] + $stats['reservation_total'];
    if ($totalOrders > 0) {
        $stats['walk_in_percent'] = round(($stats['walk_in_total'] / $totalOrders) * 100, 1);
        $stats['reservation_percent'] = round(($stats['reservation_total'] / $totalOrders) * 100, 1);
    }

    return $stats;
}

// Ensure reservation payments table exists for tracking reservation-specific payments
function ensureReservationPaymentsTable($conn) {
    $conn->query("CREATE TABLE IF NOT EXISTS reservation_payments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        reservation_id INT NOT NULL,
        amount DECIMAL(12,2) NOT NULL,
        payment_method ENUM('cash','card','online') DEFAULT 'cash',
        payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        notes TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_reservation_payments_reservation FOREIGN KEY (reservation_id) REFERENCES reservations(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
}

function getOrderTimeframeStats($conn) {
    $stats = [
        'today' => 0,
        'week' => 0,
        'month' => 0,
        'year' => 0,
        'total' => 0,
        'today_percent' => 0,
        'week_percent' => 0,
        'month_percent' => 0,
        'year_percent' => 0
    ];

    $result = $conn->query("SELECT COUNT(*) AS count FROM orders");
    $stats['total'] = (int)($result->fetch_assoc()['count'] ?? 0);
    $result = $conn->query("SELECT COUNT(*) AS count FROM reservations");
    $stats['total'] += (int)($result->fetch_assoc()['count'] ?? 0);

    $todayStart = date('Y-m-d 00:00:00');
    $todayEnd = date('Y-m-d 23:59:59');
    $weekStart = date('Y-m-d 00:00:00', strtotime('monday this week'));
    $weekEnd = date('Y-m-d 23:59:59', strtotime('sunday this week'));
    $monthStart = date('Y-m-01 00:00:00');
    $monthEnd = date('Y-m-t 23:59:59');
    $yearStart = date('Y-01-01 00:00:00');
    $yearEnd = date('Y-12-31 23:59:59');

    $periods = [
        'today' => [$todayStart, $todayEnd],
        'week' => [$weekStart, $weekEnd],
        'month' => [$monthStart, $monthEnd],
        'year' => [$yearStart, $yearEnd]
    ];

    foreach ($periods as $key => [$start, $end]) {
        $orderResult = $conn->query("SELECT COUNT(*) AS count FROM orders WHERE created_at BETWEEN '$start' AND '$end'");
        $reservationResult = $conn->query("SELECT COUNT(*) AS count FROM reservations WHERE created_at BETWEEN '$start' AND '$end'");
        $count = (int)($orderResult->fetch_assoc()['count'] ?? 0) + (int)($reservationResult->fetch_assoc()['count'] ?? 0);
        $stats[$key] = $count;
    }

    $original = $stats;
    $exclusive = [
        'today' => $original['today'],
        'week' => max(0, $original['week'] - $original['today']),
        'month' => max(0, $original['month'] - $original['week']),
        'year' => max(0, $original['year'] - $original['month'])
    ];

    $exclusiveTotal = array_sum($exclusive);
    foreach ($exclusive as $key => $value) {
        $stats[$key] = $value;
    }
    $stats['exclusive_total'] = $exclusiveTotal;

    if ($exclusiveTotal > 0) {
        $stats['today_percent'] = round(($exclusive['today'] / $exclusiveTotal) * 100, 1);
        $stats['week_percent'] = round(($exclusive['week'] / $exclusiveTotal) * 100, 1);
        $stats['month_percent'] = round(($exclusive['month'] / $exclusiveTotal) * 100, 1);
        $stats['year_percent'] = round(($exclusive['year'] / $exclusiveTotal) * 100, 1);
    }

    return $stats;
}

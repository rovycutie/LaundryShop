<?php return array (
  'site_name' => 'Laundry Shop',
  'logo' => '../uploads/logo_1763967787.png',
  'sidebar_color' => '#000000',
  'instagram_url' => '',
  'facebook_url' => '',
  'tiktok_url' => '',
  'contact_number' => '890862713326',
  'address' => '#1 CBMU, Upper Kalaklan, Olongapo City, Zamabales',
  'email' => 'andrei@gmail.com',
  'placeholder_image' => '',
  'hero_image' => 'uploads/1pic.jpg',
  'printer_name' => 'XP-58',
);
<?php
// Save receipt .bin file to print folder for automation
$input = json_decode(file_get_contents('php://input'), true);
if (!isset($input['filename']) || !isset($input['data'])) {
    http_response_code(400);
    echo 'Missing filename or data';
    exit;
}
$printFolder = __DIR__ . '/print/';
if (!is_dir($printFolder)) {
    mkdir($printFolder, 0777, true);
}
$filePath = $printFolder . basename($input['filename']);
// Decode base64 data
$binData = base64_decode($input['data']);
if (file_put_contents($filePath, $binData) !== false) {
    $skipServerPrint = !empty($input['no_server_print']);
    if ($skipServerPrint) {
        echo 'Saved (mobile)';
        exit;
    }
    // Automatically print using PrFile32.exe
    $exePath = $printFolder . 'PrFile32.exe';
    if (file_exists($exePath)) {
        // /p prints the file, /q for quiet mode
        $cmd = '"' . $exePath . '" /p "' . $filePath . '"';
        // Use shell_exec for silent execution
        shell_exec($cmd);
        echo 'Saved and sent to printer';
    } else {
        echo 'Saved, but PrFile32.exe not found';
    }
} else {
    http_response_code(500);
    echo 'Failed to save';
}

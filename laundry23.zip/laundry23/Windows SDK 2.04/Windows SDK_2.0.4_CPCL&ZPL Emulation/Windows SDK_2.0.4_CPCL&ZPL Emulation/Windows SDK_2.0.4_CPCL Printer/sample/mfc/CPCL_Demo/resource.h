﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 CPCLDemo.rc 使用
//
#define IDD_CPCL_DEMO_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON1                     1000
#define IDC_PRINTER_STATUS              1000
#define IDC_RADIO_USB                   1001
#define IDC_RADIO_COM                   1002
#define IDC_RADIO_NET                   1003
#define IDC_BUTTON_TEXT                 1004
#define IDC_COMBO_COM_PORT_NAME         1005
#define IDC_COMBO_BAUDRATE              1006
#define IDC_EDIT_NET                    1007
#define IDC_BUTTON_OPEN                 1008
#define IDC_BUTTON_CLOSE                1009
#define IDC_EDIT_MSG                    1010
#define IDC_BUTTON_BARCODE              1011
#define IDC_BUTTON_QRCODE               1012
#define IDC_BUTTON_TEXTUNDERLINE        1013
#define IDC_BUTTON_BOX                  1014
#define IDC_BUTTON_LINE                 1015
#define IDC_BUTTON_BITMAP               1016
#define IDC_BUTTON_PDF417               1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

$settings = include '../includes/settings.php';
if (!is_array($settings)) {
    $settings = [
        'site_name' => 'Laundry Co.',
        'logo' => '',
        'sidebar_color' => '#667eea',
    ];
}

$orderTimeframes = getOrderTimeframeStats($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo 'Order History - ' . htmlspecialchars($settings['site_name'] ?? 'Laundry Co.'); ?></title>
    <?php
    $logoRaw = $settings['logo'] ?? '';
    $detect = preg_replace('#^\.\./(uploads/.*)$#','$1',$logoRaw);
    $absLogo = $detect ? realpath(__DIR__ . '/../' . ltrim(str_replace(['../','./'],'', $detect), '/')) : false;
    if (!$absLogo || !is_file($absLogo)) {
        $dir = realpath(__DIR__ . '/../uploads');
        if ($dir) { $cand = glob($dir.'/logo_*.*'); if($cand){ usort($cand, fn($a,$b)=>filemtime($b)<=>filemtime($a)); $absLogo=$cand[0]; $logoRaw='../uploads/'.basename($absLogo); } }
    }
    $faviconPath = ($absLogo && is_file($absLogo)) ? $logoRaw : '../uploads/wash_and_fold.jpg';
    if ($absLogo && is_file($absLogo)) { $mt=@filemtime($absLogo); if($mt){ $faviconPath .= (strpos($faviconPath,'?')===false?'?v=':'&v=').$mt; } }
    ?>
    <link rel="icon" type="image/png" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link rel="apple-touch-icon" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        .sidebar {
            background-color: <?php echo $settings['sidebar_color']; ?> !important;
        }

        body > .d-flex > nav.sidebar {
            background-color: <?php echo $settings['sidebar_color']; ?> !important;
            background-image: none !important;
        }

        .view-btn {
            border: 1px solid #667eea;
            background-color: #fff;
            color: #667eea;
            font-weight: 500;
            padding: 4px 12px;
            border-radius: 6px;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            font-size: 13px;
        }

        .view-btn:hover {
            background-color: #667eea;
            color: #fff;
            border-color: #667eea;
        }

        .order-history-table thead th {
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            color: #6c757d;
            border-bottom: 2px solid #f1f1f1;
        }

        .order-history-table tbody td {
            vertical-align: middle;
            font-size: 0.9rem;
        }

        .order-history-table .meta-text {
            font-size: 0.8rem;
            color: #6c757d;
        }

        .order-history-table .badge {
            font-weight: 500;
            letter-spacing: 0.02em;
        }

        .detail-grid p {
            margin-bottom: 0.35rem;
        }

        .detail-grid strong {
            color: #495057;
        }

        .order-metrics-row .mini-stat-card {
            border: 1px solid #f0f0f5;
            border-radius: 16px;
            padding: 16px;
            background: #fff;
            box-shadow: 0 6px 18px rgba(15, 23, 42, 0.05);
            height: 100%;
        }

        .order-metrics-row small.label {
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #6c757d;
        }
    </style>
</head>
<body class="app-shell sidebar-collapsed">
    <div class="d-flex">
        <!-- Sidebar -->
        <nav class="sidebar">
            <button type="button" class="sidebar-close-btn" data-sidebar-toggle aria-label="Close navigation">
                &times;
            </button>

            <div class="sidebar-header text-center">
                <?php if (!empty($settings['logo'])): ?>
                    <img src="<?php echo $settings['logo']; ?>" alt="Logo" class="img-thumbnail rounded-circle mx-auto d-block" style="width: 120px; height: 120px; object-fit: cover;">
                <?php endif; ?>
                <h5 class="mt-2 mb-0" style="font-weight: bold; text-align: center; width: 100%;"><?php echo htmlspecialchars($settings['site_name']); ?></h5>
            </div>
            <ul class="nav flex-column">
                <li class="nav-item"><a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="walk_in_orders.php"><i class="bi bi-bag-check"></i> Walk-In Orders</a></li>
                <li class="nav-item"><a class="nav-link" href="reservations.php"><i class="bi bi-calendar-check"></i> Reservations</a></li>
                <li class="nav-item"><a class="nav-link" href="services.php"><i class="bi bi-list-ul"></i> Services</a></li>
                <li class="nav-item"><a class="nav-link active" href="customers.php"><i class="bi bi-clock-history"></i> Order History</a></li>
                <?php if ($auth->isAdmin()): ?>
                <li class="nav-item"><a class="nav-link" href="settings.php"><i class="bi bi-gear"></i> Settings</a></li>
                <?php endif; ?>
            </ul>
            <div class="sidebar-footer">
                <a href="../includes/logout.php" class="btn btn-sm btn-danger w-100">Logout</a>
            </div>
        </nav>

        <div class="sidebar-backdrop" data-sidebar-toggle></div>

        <!-- Main Content -->
        <main class="main-content app-main">
            <div class="topbar">
                <button class="sidebar-toggle-btn" type="button" data-sidebar-toggle aria-label="Toggle navigation">
                    <span></span>
                </button>
                <h2 class="topbar-title">
                    <span>Order History</span>
                </h2>
            </div>
                     <br>
            <header class="page-header"><h1>Order History</h1></header>

            <div class="card mb-3">
                <div class="card-body">
                    <!-- Filters -->
                    <div class="row g-2 mb-3">
                        <div class="col-md-3"><input id="searchInput" class="form-control" placeholder="Search name..."></div>
                        <div class="col-md-2"><input id="dateFrom" type="date" class="form-control"></div>
                        <div class="col-md-2"><input id="dateTo" type="date" class="form-control"></div>
                        <div class="col-md-2">
                            <select id="statusFilter" class="form-select">
                                <option value="">All Status</option>
                                <option value="pending">Pending</option>
                                <option value="processing">Processing</option>
                                <option value="completed">Completed</option>
                                <option value="cancelled">Cancelled</option>
                            </select>
                        </div>
                        <div class="col-md-3 text-end">
                            <button id="resetFilters" class="btn btn-sm btn-secondary">Reset Filters</button>
                        </div>
                    </div>

                    <!-- Orders Table -->
                    <div class="table-responsive">
                        <table class="table table-hover order-history-table" id="ordersTable">
                            <thead>
                                <tr>
                                    <th>Reference</th>
                                    <th>Customer</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th>Payment</th>
                                    <th class="text-end">Total</th>
                                    <th>Type</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="ordersTableBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Order Details Modal -->
    <div class="modal fade" id="orderModal" tabindex="-1" aria-labelledby="orderModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="orderModalLabel">Order Details</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body" id="orderModalBody"></div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    let ordersCache = [];
    let currentOrderId = null;

    // Escape HTML
    function escapeHtml(s){ 
        if(!s) return ''; 
        return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#39;"}[m])); 
    }

    function formatCurrencyPhp(amount){
        return '₱' + (parseFloat(amount) || 0).toFixed(2);
    }

    function getStatusBadge(status){
        const map = {
            pending: 'warning',
            processing: 'info',
            confirmed: 'info',
            completed: 'success',
            cancelled: 'danger',
            ready_for_pickup: 'primary'
        };
        const cls = map[status] || 'secondary';
        const label = (status || 'n/a').replace(/_/g,' ');
        return `<span class="badge bg-${cls}">${escapeHtml(label)}</span>`;
    }

    function getPaymentBadgeHtml(status){
        switch(status){
            case 'paid':
                return '<span class="badge bg-success">Paid</span>';
            case 'partial':
                return '<span class="badge bg-info text-dark">Partial</span>';
            default:
                return '<span class="badge bg-warning text-dark">Unpaid</span>';
        }
    }

    // Fetch orders from API
    async function loadOrders() {
        try {
            const status = document.getElementById('statusFilter').value || '';
            const resp = await fetch('../api/orders.php?action=get_orders' + (status ? '&status=' + status : ''));
            const data = await resp.json();
            if(data.success && data.orders){
                // Fetch reservations as well
                const resResp = await fetch('../api/reservations.php?action=get_reservations' + (status ? '&status=' + status : ''));
                const resData = await resResp.json();
                
                let combined = [];
                
                // Add orders with type marker
                if(data.orders) {
                    data.orders.forEach(o => {
                        combined.push({...o, type: 'order', created_at: o.created_at || o.due_date});
                    });
                }
                
                // Add reservations with type marker
                if(resData.success && resData.reservations) {
                    resData.reservations.forEach(r => {
                        const estimated = parseFloat(r.estimated_cost) || 0;
                        const paidAmount = parseFloat(r.paid_amount || 0);
                        const outstanding = typeof r.outstanding_amount !== 'undefined'
                            ? parseFloat(r.outstanding_amount)
                            : Math.max(0, estimated - paidAmount);
                        const paymentStatus = r.payment_status || (outstanding <= 0 && estimated > 0
                            ? 'paid'
                            : (paidAmount > 0 ? 'partial' : 'unpaid'));
                        combined.push({
                            ...r, 
                            type: 'reservation',
                            customer_name: (r.first_name + ' ' + r.last_name).trim(),
                            total_amount: r.estimated_cost,
                            created_at: r.reserved_date + ' ' + r.reserved_time,
                            payment_status: paymentStatus,
                            paid_amount: paidAmount,
                            outstanding_amount: outstanding
                        });
                    });
                }
                
                // Sort by date descending
                combined.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
                
                ordersCache = combined;
                renderOrders(ordersCache);
            }
        } catch(err){ console.error('Failed to load orders', err); }
    }

    // Render orders table
    function renderOrders(list){
        const tbody = document.getElementById('ordersTableBody');
        if(!tbody) return;
        tbody.innerHTML = list.map(o=>{
            const created = new Date(o.created_at);
            const date = created.toLocaleDateString();
            const time = created.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
            const name = o.customer_name || 'Walk-in';
            const total = formatCurrencyPhp(o.total_amount);
            const paymentBadge = getPaymentBadgeHtml(o.payment_status || 'unpaid');
            const typeBadge = o.type === 'reservation'
                ? '<span class="badge bg-info">Reservation</span>'
                : '<span class="badge bg-primary">Walk-In</span>';
            const id = o.type === 'reservation' ? 'res-' + o.id : 'ord-' + o.id;
            const reference = o.type === 'reservation'
                ? (o.reservation_number || `RES-${o.id}`)
                : (o.order_number || `ORD-${o.id}`);
            const status = getStatusBadge(o.status || 'pending');
            const phone = o.phone ? `<div class="meta-text">${escapeHtml(o.phone)}</div>` : '';
            return `<tr>
                <td>
                    <div class="fw-semibold">${escapeHtml(reference)}</div>
                    <div class="meta-text">${time}</div>
                </td>
                <td>
                    <div class="fw-semibold">${escapeHtml(name)}</div>
                    ${phone}
                </td>
                <td>${date}</td>
                <td>${status}</td>
                <td>${paymentBadge}</td>
                <td class="text-end">${total}</td>
                <td>${typeBadge}</td>
                <td><button class="btn btn-sm view-btn" onclick="showOrderDetails('${id}')"><i class="bi bi-eye"></i> View</button></td>
            </tr>`;
        }).join('');
    }

    // Apply filters
    function applyFilters(){
        const q = (document.getElementById('searchInput').value||'').toLowerCase().trim();
        const from = document.getElementById('dateFrom').value;
        const to = document.getElementById('dateTo').value;
        let list = ordersCache.slice();
        if(q) list = list.filter(o=>(o.customer_name||'').toLowerCase().includes(q));
        if(from){ const f=new Date(from); list=list.filter(o=>new Date(o.created_at)>=f); }
        if(to){ const t=new Date(to); t.setDate(t.getDate()+1); list=list.filter(o=>new Date(o.created_at)<t); }
        renderOrders(list);
    }

    // Show order details modal
    async function showOrderDetails(idStr){
        const [type, id] = idStr.split('-');
        if(type === 'res'){
            showReservationDetails(parseInt(id));
        } else {
            showOrderDetailsInternal(parseInt(id));
        }
    }

    // Show reservation details
    async function showReservationDetails(resId){
        currentOrderId = 'res-' + resId;
        try {
            const resp = await fetch(`../api/reservations.php?action=get_reservations`);
            const data = await resp.json();
            if(!data.success) return;
            
            const reservation = data.reservations.find(r => parseInt(r.id, 10) === resId);
            if(!reservation) return;
            
            const date = new Date(reservation.reserved_date);
            const dateStr = date.toLocaleDateString();
            const paidAmount = parseFloat(reservation.paid_amount || 0);
            const outstanding = typeof reservation.outstanding_amount !== 'undefined'
                ? parseFloat(reservation.outstanding_amount)
                : Math.max(0, (parseFloat(reservation.estimated_cost)||0) - paidAmount);
            const paymentBadge = getPaymentBadgeHtml(reservation.payment_status || 'unpaid');
            
            let html = `<div class="detail-grid">
                        <p><strong>Type:</strong> <span class="badge bg-info">Reservation</span></p>
                        <p><strong>Ticket #:</strong> ${escapeHtml(reservation.reservation_number)}</p>
                        <p><strong>Customer:</strong> ${escapeHtml(reservation.first_name + ' ' + reservation.last_name)}</p>
                        <p><strong>Phone:</strong> ${escapeHtml(reservation.phone)}</p>
                        <p><strong>Email:</strong> ${escapeHtml(reservation.email)}</p>
                        <p><strong>Date:</strong> ${dateStr}</p>
                        <p><strong>Time:</strong> ${escapeHtml(reservation.reserved_time)}</p>
                        <p><strong>Service:</strong> ${escapeHtml(reservation.service_name)}</p>
                        <p><strong>Weight:</strong> ${reservation.weight_kg} kg</p>
                        <p><strong>Estimated Cost:</strong> ₱${parseFloat(reservation.estimated_cost).toFixed(2)}</p>
                        <p><strong>Status:</strong> <span class="badge bg-${reservation.status==='completed'?'success':(reservation.status==='processing'||reservation.status==='confirmed')?'info':reservation.status==='pending'?'warning':'secondary'}">${escapeHtml(reservation.status)}</span></p>
                        </div>`;

            html += `<hr>
                    <div class="detail-grid">
                        <p><strong>Payment Status:</strong> ${paymentBadge}</p>
                        <p><strong>Paid:</strong> ${formatCurrencyPhp(paidAmount)}</p>
                        <p><strong>Outstanding:</strong> ${formatCurrencyPhp(outstanding)}</p>
                    </div>`;

            if (reservation.special_requests) {
                html += `<hr><p class="mb-0"><strong>Special Requests:</strong> ${escapeHtml(reservation.special_requests)}</p>`;
            }
            // Action buttons: print & manage
            html += `<hr><div class="d-flex flex-wrap gap-2 mb-2">
                <a href="receipt.php?type=reservation&id=${resId}&print=1" target="_blank" class="btn btn-sm btn-outline-secondary"><i class="bi bi-printer"></i> Print Receipt</a>
                <a href="reservations.php?view=${resId}" class="btn btn-sm btn-primary"><i class="bi bi-pencil"></i> Manage</a>
            </div>`;
            
            document.getElementById('orderModalBody').innerHTML = html;
            new bootstrap.Modal(document.getElementById('orderModal')).show();
        } catch(err){ console.error(err); }
    }

    // Show order details internal
    async function showOrderDetailsInternal(orderId){
        currentOrderId = 'ord-' + orderId;
        try {
            const resp = await fetch(`../api/orders.php?action=get_order&id=${orderId}`);
            const data = await resp.json();
            if(!data.success || !data.order) return;

            const order = data.order;
            const created = new Date(order.created_at);
            const date = created.toLocaleDateString();
            const time = created.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});

            const paidAmount = data.payments ? data.payments.reduce((a,p)=>a+parseFloat(p.amount),0) : 0;
            const outstanding = parseFloat(order.total_amount)-paidAmount;

            const itemsHtml = data.items && data.items.length
                ? `<h6>Items</h6>
                   <table class="table table-sm">
                       <thead>
                           <tr>
                               <th>Service</th>
                               <th>Qty</th>
                               <th class="text-end">Price</th>
                               <th class="text-end">Subtotal</th>
                           </tr>
                       </thead>
                       <tbody>
                           ${data.items.map(i=>`
                               <tr>
                                   <td>${escapeHtml(i.name)}</td>
                                   <td>${i.quantity}</td>
                                   <td class="text-end">₱${parseFloat(i.unit_price).toFixed(2)}</td>
                                   <td class="text-end">₱${(i.quantity*parseFloat(i.unit_price)).toFixed(2)}</td>
                               </tr>
                           `).join('')}
                       </tbody>
                   </table>` : '';

            const paymentsHtml = data.payments && data.payments.length
                ? `<h6>Payments</h6>` + data.payments.map(p=>`<p><small>${new Date(p.payment_date).toLocaleString()} - ₱${parseFloat(p.amount).toFixed(2)} (${escapeHtml(p.payment_method)})</small></p>`).join('')
                : '';

            let html = `<div class="detail-grid">
                        <p><strong>Type:</strong> <span class="badge bg-primary">Walk-in</span></p>
                        <p><strong>Order #:</strong> ${escapeHtml(order.order_number)}</p>
                        <p><strong>Customer:</strong> ${escapeHtml(order.customer_name||'Walk-in')}</p>
                        <p><strong>Date:</strong> ${date}</p>
                        <p><strong>Time:</strong> ${time}</p>
                        <p><strong>Status:</strong> <span class="badge bg-${order.status==='completed'?'success':order.status==='pending'?'warning':'secondary'}">${escapeHtml(order.status)}</span></p>
                        </div>
                        <hr>`;

            if(itemsHtml) html += itemsHtml + `<p><strong>Total:</strong> ₱${parseFloat(order.total_amount).toFixed(2)}</p><hr>`;
            if(paymentsHtml) html += `<p><strong>Paid:</strong> ₱${paidAmount.toFixed(2)}</p>
                                       <p><strong>Outstanding:</strong> ₱${outstanding.toFixed(2)}</p>` + paymentsHtml;

            // Action buttons: print & manage
            html += `<hr><div class="d-flex flex-wrap gap-2 mb-2">
                <a href="receipt.php?type=order&id=${orderId}&print=1" target="_blank" class="btn btn-sm btn-outline-secondary"><i class="bi bi-printer"></i> Print Receipt</a>
                <a href="walk_in_orders.php?edit=${orderId}" class="btn btn-sm btn-primary"><i class="bi bi-pencil"></i> Manage</a>
            </div>`;

            document.getElementById('orderModalBody').innerHTML = html;
            new bootstrap.Modal(document.getElementById('orderModal')).show();
        } catch(err){ console.error(err); }
    }

    // Delete functionality removed per request (button no longer present)

    // Event listeners
    document.getElementById('searchInput').addEventListener('input', applyFilters);
    document.getElementById('dateFrom').addEventListener('change', applyFilters);
    document.getElementById('dateTo').addEventListener('change', applyFilters);
    document.getElementById('statusFilter').addEventListener('change', loadOrders);
    document.getElementById('resetFilters').addEventListener('click', ()=>{
        document.getElementById('searchInput').value='';
        document.getElementById('dateFrom').value='';
        document.getElementById('dateTo').value='';
        document.getElementById('statusFilter').value='';
        loadOrders();
    });

    // Initial load
    loadOrders();
    </script>
    <script>
        (function () {
            var toggles = document.querySelectorAll('[data-sidebar-toggle]');
            if (!toggles.length) return;

            function openSidebar() {
                document.body.classList.remove('sidebar-collapsed');
                document.body.classList.add('sidebar-open');
            }

            function closeSidebar() {
                document.body.classList.add('sidebar-collapsed');
                document.body.classList.remove('sidebar-open');
            }

            function toggleSidebar() {
                if (document.body.classList.contains('sidebar-collapsed')) {
                    openSidebar();
                } else {
                    closeSidebar();
                }
            }

            toggles.forEach(function (btn) {
                btn.addEventListener('click', function (e) {
                    e.preventDefault();
                    toggleSidebar();
                });
            });

            window.addEventListener('resize', function () {
                if (window.innerWidth >= 993) {
                    document.body.classList.remove('sidebar-collapsed', 'sidebar-open');
                } else {
                    document.body.classList.add('sidebar-collapsed');
                }
            });
        })();
    </script>
</body>
</html>

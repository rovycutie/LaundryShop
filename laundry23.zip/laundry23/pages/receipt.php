<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

// Initialize variables to avoid undefined warnings
$siteName = 'Laundry Co.';
$title = 'Receipt';
$sizeClass = 'w58';
$payments = [];

$type = isset($_GET['type']) ? strtolower(trim($_GET['type'])) : '';
// Load site name from settings if available
if (file_exists('../includes/settings.php')) {
    $settings = include '../includes/settings.php';
    if (is_array($settings) && isset($settings['site_name'])) {
        $siteName = $settings['site_name'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Receipt</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/receipt.css">
</head>
<body>
<div class="receipt" style="max-width:350px;margin:30px auto;padding:20px;background:#fff;border:1px solid #eee;box-shadow:0 0 8px #eee;">
    <div style="text-align:center;font-size:22px;font-weight:bold;"><?php echo $settings['site_name'] ?></div>
    <div style="text-align:center;font-size:16px;margin-bottom:10px;">Receipt</div>
    <div style="margin-bottom:8px;">
        <strong>Size:</strong>
        <a href="?type=<?php echo urlencode($type); ?>&id=<?php echo $id; ?>&size=58" class="small" style="text-decoration:<?php echo $sizeClass==='w58'?'underline':'none'; ?>;">58mm</a> |
        <a href="?type=<?php echo urlencode($type); ?>&id=<?php echo $id; ?>&size=58safe" class="small" style="text-decoration:<?php echo $sizeClass==='w58s'?'underline':'none'; ?>;">58mm Safe</a> |
        <a href="?type=<?php echo urlencode($type); ?>&id=<?php echo $id; ?>&size=76" class="small" style="text-decoration:<?php echo $sizeClass==='w76'?'underline':'none'; ?>;">76mm</a> |
        <a href="?type=<?php echo urlencode($type); ?>&id=<?php echo $id; ?>&size=80" class="small" style="text-decoration:<?php echo $sizeClass==='w80'?'underline':'none'; ?>;">80mm</a> |
        <a href="?type=<?php echo urlencode($type); ?>&id=<?php echo $id; ?>&size=90" class="small" style="text-decoration:<?php echo $sizeClass==='w90'?'underline':'none'; ?>;">90mm</a>
    </div>
    <button class="btn-print" onclick="printReceiptWithQZ()">Print Receipt (QZ Tray)</button>
    <div id="qz-status" style="color: red; font-weight: bold; margin-top: 10px;"></div>
    <div id="printer-list" style="margin-top:10px;font-size:12px;color:#333;"></div>
    <div style="margin-top:10px;font-size:12px;color:#666;">If printing fails, open QZ Tray, go to <b>Settings &gt; Security</b> and enable <b>Allow unsigned requests</b> for development.</div>
</div>
<script src="../js/qz-tray.js"></script>
<script>
let receiptData = null;

async function fetchReceiptData() {
    // Get type and id from URL
    const urlParams = new URLSearchParams(window.location.search);
    const type = urlParams.get('type');
    const id = urlParams.get('id');
    if (!type || !id) return null;
    if (type === 'order') {
        const resp = await fetch(`../api/orders.php?action=get_order&id=${id}`);
        const data = await resp.json();
        if (data.success) return { type: 'order', ...data };
    } else if (type === 'reservation') {
        const resp = await fetch(`../api/reservations.php?action=get_reservation&id=${id}`);
        const data = await resp.json();
        if (data.success) return { type: 'reservation', ...data };
    }
    return null;
}

function getReceiptText() {
    if (!receiptData) {
        return 'Dr. HYGIENE\nReceipt\n-----------------------------\nThank you!\nNo refunds after 24 hours.\nPlease keep this receipt.\n-----------------------------';
    }
    let lines = [];
    lines.push(' ');
    lines.push(' ');
    lines.push('<?php echo $settings['site_name']?>');
    lines.push('Receipt');
    lines.push('-----------------------------');
    if (receiptData.type === 'order') {
        // Walk-in order formatted like reservation, but using order values
        const order = receiptData.order;
        const items = receiptData.items || [];
        const payments = receiptData.payments || [];
        const firstItem = items[0] || {};
        lines.push('Order #: ' + (order.order_number || order.id));
        lines.push('Customer: ' + (order.customer_name || ''));
        if (order.email) lines.push('Email: ' + order.email);
        lines.push('Phone: ' + (order.phone || ''));
        if (order.created_at) {
            let dt = new Date(order.created_at);
            lines.push('Date/Time: ' + dt.getFullYear() + '-' + String(dt.getMonth()+1).padStart(2,'0') + '-' + String(dt.getDate()).padStart(2,'0') + ' ' + String(dt.getHours()).padStart(2,'0') + ':' + String(dt.getMinutes()).padStart(2,'0'));
        }
        lines.push('-----------------------------');
        // Reservation-like section
        lines.push('Service: ' + (firstItem.service_name || ''));
        lines.push('Weight: ' + (firstItem.quantity !== undefined ? parseFloat(firstItem.quantity).toFixed(2) + ' kg' : ''));
        if (firstItem.unit_price !== undefined) {
            lines.push('Price Per Kg: ' + parseFloat(firstItem.unit_price).toFixed(2));
        }
        const estTotal = parseFloat(order.total_amount || order.total?.amount || 0);
        lines.push('Estimated Cost: Php ' + estTotal.toFixed(2));
        let paid = 0;
        payments.forEach(p => paid += parseFloat(p.amount || 0));
        lines.push('Paid: Php ' + paid.toFixed(2));
        lines.push('Outstanding: Php ' + (estTotal - paid).toFixed(2));
        if (payments.length > 0) {
            lines.push('Payments:');
            payments.forEach(p => {
                const when = (p.payment_date || '').substring(0, 16);
                lines.push(`  ${p.payment_method} Php ${parseFloat(p.amount || 0).toFixed(2)}${when ? ' (' + when + ')' : ''}`);
            });
        }
    } else if (receiptData.type === 'reservation') {
        // ...existing reservation formatting...
        const res = receiptData.reservation;
        const payments = receiptData.payments || [];
        lines.push('Reservation #: ' + (res.reservation_number || res.id));
        lines.push('Customer: ' + ((res.first_name ? res.first_name : '') + (res.last_name ? ' ' + res.last_name : '')));
        if (res.email) lines.push('Email: ' + res.email);
        lines.push('Phone: ' + (res.phone || ''));
        if (res.reserved_date && res.reserved_time) {
            lines.push('Date/Time: ' + res.reserved_date + ' ' + res.reserved_time);
        }
        lines.push('-----------------------------');
        lines.push('Service: ' + (res.service_name || ''));
        lines.push('Weight: ' + (res.weight_kg !== undefined ? parseFloat(res.weight_kg).toFixed(2) + ' kg' : ''));
        const est = parseFloat(res.estimated_cost || 0);
        lines.push('Estimated Cost: Php ' + est.toFixed(2));
        let paid = 0;
        payments.forEach(p => paid += parseFloat(p.amount || 0));
        lines.push('Paid: Php ' + paid.toFixed(2));
        lines.push('Outstanding: Php ' + (est - paid).toFixed(2));
        if (payments.length > 0) {
            lines.push('Payments:');
            payments.forEach(p => {
                const when = (p.payment_date || '').substring(0, 16);
                lines.push(`  ${p.payment_method} Php ${parseFloat(p.amount || 0).toFixed(2)}${when ? ' (' + when + ')' : ''}`);
            });
        }
        if (res.special_requests) {
            lines.push('Special Requests: ' + res.special_requests);
        }
    }
    lines.push('-----------------------------');
    lines.push('Thank you!');
    lines.push('No refunds after 24 hours.');
    lines.push('Please keep this receipt.');
    lines.push('-----------------------------');
    lines.push(' ');
    lines.push(' ');
    lines.push(' ');
    return lines.join('\n');
}

function updateQZStatus(msg, color) {
    var el = document.getElementById('qz-status');
    el.textContent = msg;
    el.style.color = color || 'red';
}

async function printReceiptWithQZ() {
    if (!window.qz) {
        updateQZStatus('QZ Tray library not loaded.', 'red');
        alert('QZ Tray is not loaded.');
        return;
    }
    updateQZStatus('Loading receipt data...', 'orange');
    receiptData = await fetchReceiptData();
    updateQZStatus('Connecting to QZ Tray...', 'orange');
    qz.websocket.connect().then(function() {
        updateQZStatus('Connected to QZ Tray.', 'green');
        return qz.printers.find();
    }).then(function(printers) {
        if (!printers || printers.length === 0) {
            updateQZStatus('No printers found. Check QZ Tray and printer connection.', 'red');
            throw new Error('No printers found');
        }
        document.getElementById('printer-list').innerHTML = '<b>Available Printers:</b><br>' + printers.map(function(p){return p;}).join('<br>');
        var printerName = printers.find(function(p){return p.toLowerCase().includes('xp-58');}) || printers[0];
        if (!printerName) {
            updateQZStatus('XP-58 printer not found. Using: ' + printers[0], 'orange');
            printerName = printers[0];
        } else {
            updateQZStatus('Using printer: ' + printerName, 'green');
        }
        var config = qz.configs.create(printerName);
        var escposData = getReceiptText();
        var data = [
            '\x1B\x40', // Initialize printer
            escposData,
            '\x1B\x6D'  // Cut
        ];
        return qz.print(config, data);
    }).then(function() {
        updateQZStatus('Receipt sent to printer!', 'green');
        qz.websocket.disconnect();
    }).catch(function(e) {
        updateQZStatus('Printing failed: ' + e, 'red');
        alert('Printing failed: ' + e);
        try { qz.websocket.disconnect(); } catch (err) {}
    });
}

window.addEventListener('DOMContentLoaded', function() {
    if (!window.qz) {
        updateQZStatus('QZ Tray library not loaded.', 'red');
    } else {
        updateQZStatus('QZ Tray library loaded. Ready to print.', 'green');
    }
});
</script>


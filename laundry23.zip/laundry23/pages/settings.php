<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

// Default settings now include contact number, address, and email
$settings = [
    'site_name' => 'Laundry Co.',
    'logo' => '',
    'sidebar_color' => '#667eea',
    'instagram_url' => '',
    'facebook_url' => '',
    'tiktok_url' => '',
    'contact_number' => '+63 912 345 6789',
    'address' => 'Your Street, City',
    'email' => 'support@laundryco.local',
];

// Load saved settings (if any)
if (file_exists('../includes/settings.php')) {
    $saved = include '../includes/settings.php';
    if (is_array($saved)) {
        $settings = array_merge($settings, $saved);
    }
}

// Ensure all keys exist in the settings array (merge again including new keys)
$settings = array_merge([
    'site_name' => 'Laundry Co.',
    'logo' => '',
    'sidebar_color' => '#667eea',
    'instagram_url' => '',
    'facebook_url' => '',
    'tiktok_url' => '',
    'contact_number' => '+63 912 345 6789',
    'address' => 'Your Street, City',
    'email' => 'support@laundryco.local',
], $settings);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle logo deletion
    if (isset($_POST['delete_logo']) && $_POST['delete_logo'] === '1') {
        if (!empty($settings['logo']) && file_exists($settings['logo'])) {
            unlink($settings['logo']);
        }
        $settings['logo'] = '';
    } else {
        foreach ($settings as $key => $value) {
            if ($key === 'logo' && isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
                $uploadDir = '../uploads/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                $ext = pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION);
                $uploadFile = $uploadDir . 'logo_' . time() . '.' . $ext;
                if (move_uploaded_file($_FILES['logo']['tmp_name'], $uploadFile)) {
                    $settings['logo'] = $uploadFile;
                } else {
                    echo '<div class="alert alert-danger">Failed to upload the logo. Please try again.</div>';
                }
            } elseif (isset($_POST[$key])) {
                $settings[$key] = htmlspecialchars($_POST[$key]);
            }
        }
    }

    file_put_contents('../includes/settings.php', '<?php return ' . var_export($settings, true) . ';');
    header('Location: settings.php?success=1');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo 'Settings - ' . htmlspecialchars($settings['site_name'] ?? 'Laundry Co.'); ?></title>
    <?php
    $logoRaw = $settings['logo'] ?? '';
    $detect = preg_replace('#^\.\./(uploads/.*)$#','$1',$logoRaw);
    $absLogo = $detect ? realpath(__DIR__ . '/../' . ltrim(str_replace(['../','./'],'', $detect), '/')) : false;
    if (!$absLogo || !is_file($absLogo)) {
        $dir = realpath(__DIR__ . '/../uploads');
        if ($dir) { $c = glob($dir.'/logo_*.*'); if($c){ usort($c, fn($a,$b)=>filemtime($b)<=>filemtime($a)); $absLogo=$c[0]; $logoRaw='../uploads/'.basename($absLogo); } }
    }
    $faviconPath = ($absLogo && is_file($absLogo)) ? $logoRaw : '../uploads/wash_and_fold.jpg';
    if ($absLogo && is_file($absLogo)) { $mt=@filemtime($absLogo); if($mt){ $faviconPath .= (strpos($faviconPath,'?')===false?'?v=':'&v=').$mt; } }
    ?>
    <link rel="icon" type="image/png" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link rel="apple-touch-icon" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        body > .d-flex > nav.sidebar {
            background-color: <?php echo $settings['sidebar_color']; ?> !important;
            background-image: none !important;
        }
    </style>
</head>
<body class="app-shell sidebar-collapsed">
    <div class="d-flex">
        <!-- Sidebar -->
        <nav class="sidebar">
            <button type="button" class="sidebar-close-btn" data-sidebar-toggle aria-label="Close navigation">
                &times;
            </button>

            <div class="sidebar-header text-center">
                <?php if (!empty($settings['logo'])): ?>
                    <img src="<?php echo $settings['logo']; ?>" alt="Logo" class="img-thumbnail rounded-circle mx-auto d-block" style="width: 120px; height: 120px; object-fit: cover; background: #fff;">
                <?php endif; ?>
                <h5 class="mt-2 mb-0" style="font-weight: bold; text-align: center; width: 100%;"><?php echo $settings['site_name']; ?></h5>
            </div>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="walk_in_orders.php"><i class="bi bi-bag-check"></i> Walk-In Orders</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="reservations.php"><i class="bi bi-calendar-check"></i> Reservations</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="services.php"><i class="bi bi-list-ul"></i> Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="customers.php"><i class="bi bi-clock-history"></i> Order History</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="settings.php"><i class="bi bi-gear"></i> Settings</a>
                </li>
            </ul>
            <div class="sidebar-footer">
                <a href="../includes/logout.php" class="btn btn-sm btn-danger w-100">Logout</a>
            </div>
        </nav>

        <div class="sidebar-backdrop" data-sidebar-toggle></div>

        <!-- Main Content -->
        <main class="main-content app-main">
            <div class="topbar">
                <button class="sidebar-toggle-btn" type="button" data-sidebar-toggle aria-label="Toggle navigation">
                    <span></span>
                </button>
                <h2 class="topbar-title">
                    <span>Settings</span>
                </h2>
            </div>
                    <br>
            <header class="page-header">
                <h1>Settings</h1>
            </header>
            <form method="POST" class="mt-4" enctype="multipart/form-data" id="settingsForm">
                <div class="mb-3">
                    <label for="site_name" class="form-label">Site Name</label>
                    <input type="text" id="site_name" name="site_name" class="form-control" value="<?php echo $settings['site_name']; ?>">
                </div>
                <div class="mb-3">
                    <label for="logo" class="form-label">Upload Logo</label>
                    <input type="file" id="logo" name="logo" class="form-control" accept="image/*">
                    <input type="hidden" name="delete_logo" id="delete_logo" value="0">
                    <div id="logoPreviewContainer" class="mt-2">
                        <?php if (!empty($settings['logo'])): ?>
                            <img id="logoPreview" src="<?php echo $settings['logo']; ?>" alt="Logo" class="img-thumbnail rounded-circle" style="max-width: 120px; max-height: 120px; object-fit: cover; background: #fff;">
                            <button type="button" class="btn btn-outline-danger btn-sm ms-2" id="deleteLogoBtn">Delete Logo</button>
                        <?php else: ?>
                            <img id="logoPreview" src="#" alt="Logo Preview" class="img-thumbnail rounded-circle d-none" style="max-width: 120px; max-height: 120px; object-fit: cover; background: #fff;">
                        <?php endif; ?>
                    </div>
                    <!-- Cropping Modal -->
                    <div class="modal fade" id="cropperModal" tabindex="-1">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Crop Logo</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <div><img id="cropperImage" src="#" style="max-width:100%;"></div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                    <button type="button" class="btn btn-primary" id="cropLogoBtn">Crop & Use</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="sidebar_color" class="form-label">Sidebar Background Color</label>
                    <input type="color" id="sidebar_color" name="sidebar_color" class="form-control form-control-color" value="<?php echo $settings['sidebar_color']; ?>">
                </div>
                <!-- New contact info fields -->
                <div class="mb-3 p-3 border rounded">
                    <h6 class="mb-3">Business Contact Info</h6>
                    <div class="mb-2">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" id="email" name="email" placeholder="support@laundryco.local" class="form-control" value="<?php echo htmlspecialchars($settings['email']); ?>">
                    </div>
                    <div class="mb-2">
                        <label for="contact_number" class="form-label">Contact Number</label>
                        <input type="text" id="contact_number" name="contact_number" placeholder="+63 912 345 6789" class="form-control" value="<?php echo htmlspecialchars($settings['contact_number']); ?>">
                    </div>
                    <div class="mb-2">
                        <label for="address" class="form-label">Address</label>
                        <input type="text" id="address" name="address" placeholder="123 Laundry St, City" class="form-control" value="<?php echo htmlspecialchars($settings['address']); ?>">
                    </div>
                </div>
                <div class="mb-3 p-3 border rounded">
                    <h6 class="mb-3">Social Media Links</h6>
                    <div class="mb-2">
                        <label for="instagram_url" class="form-label">Instagram URL</label>
                        <input type="url" id="instagram_url" name="instagram_url" placeholder="https://instagram.com/yourpage" class="form-control" value="<?php echo $settings['instagram_url']; ?>">
                    </div>
                    <div class="mb-2">
                        <label for="facebook_url" class="form-label">Facebook URL</label>
                        <input type="url" id="facebook_url" name="facebook_url" placeholder="https://facebook.com/yourpage" class="form-control" value="<?php echo $settings['facebook_url']; ?>">
                    </div>
                    <div class="mb-2">
                        <label for="tiktok_url" class="form-label">TikTok URL</label>
                        <input type="url" id="tiktok_url" name="tiktok_url" placeholder="https://tiktok.com/@yourpage" class="form-control" value="<?php echo $settings['tiktok_url']; ?>">
                    </div>
                    <p class="small text-muted mb-0">Leave blank to hide a platform on the public landing page.</p>
                </div>
                <button type="submit" class="btn btn-primary">Save Settings</button>
            </form>
        </main>
    </div>

    <link href="https://cdn.jsdelivr.net/npm/cropperjs@1.5.13/dist/cropper.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/cropperjs@1.5.13/dist/cropper.min.js"></script>
    <script>
    // Logo preview, crop, and delete logic
    let cropper;
    const logoInput = document.getElementById('logo');
    const logoPreview = document.getElementById('logoPreview');
    const logoPreviewContainer = document.getElementById('logoPreviewContainer');
    const cropperModal = new bootstrap.Modal(document.getElementById('cropperModal'));
    const cropperImage = document.getElementById('cropperImage');
    const cropLogoBtn = document.getElementById('cropLogoBtn');
    const deleteLogoBtn = document.getElementById('deleteLogoBtn');
    const deleteLogoInput = document.getElementById('delete_logo');

    if (logoInput) {
        logoInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file && file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = function(evt) {
                    cropperImage.src = evt.target.result;
                    cropperModal.show();
                };
                reader.readAsDataURL(file);
            }
        });
    }

    document.getElementById('cropperModal').addEventListener('shown.bs.modal', function () {
        cropper = new Cropper(cropperImage, {
            aspectRatio: 1,
            viewMode: 1,
            dragMode: 'move',
            autoCropArea: 1,
            responsive: true,
            background: false
        });
    });
    document.getElementById('cropperModal').addEventListener('hidden.bs.modal', function () {
        if (cropper) {
            cropper.destroy();
            cropper = null;
        }
    });

    if (cropLogoBtn) {
        cropLogoBtn.addEventListener('click', function() {
            if (cropper) {
                cropper.getCroppedCanvas({ width: 300, height: 300 }).toBlob(function(blob) {
                    const url = URL.createObjectURL(blob);
                    logoPreview.src = url;
                    logoPreview.classList.remove('d-none');
                    const dt = new DataTransfer();
                    const file = new File([blob], 'cropped_logo.png', { type: 'image/png' });
                    dt.items.add(file);
                    logoInput.files = dt.files;
                    cropperModal.hide();
                }, 'image/png');
            }
        });
    }

    if (deleteLogoBtn) {
        deleteLogoBtn.addEventListener('click', function() {
            if (confirm('Are you sure you want to delete the logo?')) {
                deleteLogoInput.value = '1';
                document.getElementById('settingsForm').submit();
            }
        });
    }
    </script>
    <script>
        (function () {
            var toggles = document.querySelectorAll('[data-sidebar-toggle]');
            if (!toggles.length) return;

            function openSidebar() {
                document.body.classList.remove('sidebar-collapsed');
                document.body.classList.add('sidebar-open');
            }

            function closeSidebar() {
                document.body.classList.add('sidebar-collapsed');
                document.body.classList.remove('sidebar-open');
            }

            function toggleSidebar() {
                if (document.body.classList.contains('sidebar-collapsed')) {
                    openSidebar();
                } else {
                    closeSidebar();
                }
            }

            toggles.forEach(function (btn) {
                btn.addEventListener('click', function (e) {
                    e.preventDefault();
                    toggleSidebar();
                });
            });

            window.addEventListener('resize', function () {
                if (window.innerWidth >= 993) {
                    document.body.classList.remove('sidebar-collapsed', 'sidebar-open');
                } else {
                    document.body.classList.add('sidebar-collapsed');
                }
            });
        })();
    </script>
</body>
</html>
<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

$settings = include '../includes/settings.php';
if (!is_array($settings)) {
    $settings = [
        'site_name' => 'Laundry Co.',
        'logo' => '',
        'sidebar_color' => '#667eea',
    ];
}

$stats = getDashboardStats($conn);
$ordersData = $conn->query("SELECT o.id, o.order_number AS reference, CONCAT(c.first_name, ' ', c.last_name) AS customer_name,
                                o.total_amount AS amount, o.status, o.due_date AS schedule, o.created_at,
                                'order' AS record_type
                            FROM orders o
                            LEFT JOIN customers c ON o.customer_id = c.id
                            ORDER BY o.created_at DESC LIMIT 10")->fetch_all(MYSQLI_ASSOC);

$reservationsData = $conn->query("SELECT r.id, r.reservation_number AS reference,
                                    CONCAT(r.first_name, ' ', r.last_name) AS customer_name,
                                    r.estimated_cost AS amount, r.status,
                                    CONCAT(r.reserved_date, ' ', r.reserved_time) AS schedule,
                                    r.created_at, 'reservation' AS record_type
                                FROM reservations r
                                ORDER BY r.created_at DESC LIMIT 10")->fetch_all(MYSQLI_ASSOC);

$recentEntries = array_merge($ordersData ?? [], $reservationsData ?? []);
usort($recentEntries, function ($a, $b) {
    return strtotime($b['created_at']) <=> strtotime($a['created_at']);
});
$recentEntries = array_slice($recentEntries, 0, 5);

$orderTimeframes = getOrderTimeframeStats($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo 'Dashboard - ' . htmlspecialchars($settings['site_name'] ?? 'Laundry Co.'); ?></title>
    <?php
    $logoRaw = $settings['logo'] ?? '';
    $normalized = $logoRaw;
    // For pages/ directory keep '../uploads' if present; strip leading ../ for detection
    $detect = preg_replace('#^\.\./(uploads/.*)$#','$1',$normalized);
    $absLogo = $detect ? realpath(__DIR__ . '/../' . ltrim(str_replace(['../','./'],'', $detect), '/')) : false;
    if (!$absLogo || !is_file($absLogo)) {
        $candDir = realpath(__DIR__ . '/../uploads');
        if ($candDir) { $cands = glob($candDir.'/logo_*.*'); if($cands){ usort($cands, fn($a,$b)=>filemtime($b)<=>filemtime($a)); $absLogo = $cands[0]; $normalized = '../uploads/' . basename($absLogo); } }
    }
    $faviconPath = ($absLogo && is_file($absLogo)) ? $normalized : '../uploads/wash_and_fold.jpg';
    if ($absLogo && is_file($absLogo)) { $mtime=@filemtime($absLogo); if($mtime){ $faviconPath .= (strpos($faviconPath,'?')===false?'?v=':'&v=').$mtime; } }
    ?>
    <link rel="icon" type="image/png" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link rel="apple-touch-icon" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        .sidebar {
            background-color: <?php echo $settings['sidebar_color']; ?> !important;
        }
        
        body > .d-flex > nav.sidebar {
            background-color: <?php echo $settings['sidebar_color']; ?> !important;
            background-image: none !important;
        }

        /* Remove bullets / markers from sidebar nav to avoid the black square */
        .sidebar .nav {
            list-style: none;
            padding-left: 0;
            margin: 0;
        }

        .order-metrics-row .mini-stat-card {
            border-radius: 16px;
            border: 1px solid #f1f1f5;
            padding: 16px 18px;
            background: #fff;
            box-shadow: 0 6px 18px rgba(15, 23, 42, 0.06);
            height: 100%;
        }

        .order-metrics-row .mini-stat-card small.label {
            font-size: 0.72rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #6c757d;
        }

        .order-metrics-row .mini-stat-card h3 {
            font-weight: 700;
        }

        .order-metrics-row .mini-stat-card .percent {
            font-weight: 600;
            color: #0b7285;
        }
    </style>
</head>
<body class="app-shell sidebar-collapsed">
    <div class="d-flex">
        <!-- Sidebar -->
        <nav class="sidebar">
            <!-- collapse/uncollapse button for mobile/tablet -->
            <button type="button" class="sidebar-close-btn" data-sidebar-toggle aria-label="Close navigation">
                &times;
            </button>

            <div class="sidebar-header text-center">
                <?php if (!empty($settings['logo'])): ?>
                    <img src="<?php echo $settings['logo']; ?>" alt="Logo" class="img-thumbnail rounded-circle mx-auto d-block" style="width: 120px; height: 120px; object-fit: cover; background: #fff;">
                <?php endif; ?>
                <h5 class="mt-2 mb-0" style="font-weight: bold; text-align: center; width: 100%;"><?php echo $settings['site_name']; ?></h5>
            </div>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link active" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="walk_in_orders.php"><i class="bi bi-bag-check"></i> Walk-In Orders</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="reservations.php"><i class="bi bi-calendar-check"></i> Reservations</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="services.php"><i class="bi bi-list-ul"></i> Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="customers.php"><i class="bi bi-clock-history"></i> Order History</a>
                </li>
                <?php if ($auth->isAdmin()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="settings.php"><i class="bi bi-gear"></i> Settings</a>
                </li>
                
                <?php endif; ?>
            </ul>
            <div class="sidebar-footer">
                <small>Logged in as: <?php echo htmlspecialchars($_SESSION['full_name']); ?></small>
                <br>
                <a href="../includes/logout.php" class="btn btn-sm btn-danger mt-2">Logout</a>
            </div>
        </nav>

        <!-- Backdrop for mobile / tablet when menu is open -->
        <div class="sidebar-backdrop" data-sidebar-toggle></div>

        <!-- Main Content -->
        <main class="main-content app-main">
            <!-- Mobile / tablet top bar with hamburger -->
            <div class="topbar">
                <button class="sidebar-toggle-btn" type="button" data-sidebar-toggle aria-label="Toggle navigation">
                    <span></span>
                </button>
                <h2 class="topbar-title">
                    <span>Dashboard</span>
                </h2>
            </div>
                    <br>      
            <header class="page-header">
                <h1>Dashboard</h1>
            </header>


            <!-- Stats Cards -->
            <div class="row mb-4">
                <div class="col-12 col-sm-6 col-lg-3 mb-3 mb-lg-0">
                    <div class="stat-card">
                        <div class="stat-icon" style="background-color: #e7f5ff;">
                            <i class="bi bi-bag-check" style="color: #0066cc;"></i>
                        </div>
                        <div class="stat-content">
                            <h6>Today's Orders</h6>
                            <h3><?php echo $stats['today_orders']; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-lg-3 mb-3 mb-lg-0">
                    <div class="stat-card">
                        <div class="stat-icon" style="background-color: #fff4e7;">
                            <i class="bi bi-exclamation-circle" style="color: #ff9900;"></i>
                        </div>
                        <div class="stat-content">
                            <h6>Pending Orders</h6>
                            <h3><?php echo $stats['pending_orders']; ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-lg-3 mb-3 mb-lg-0">
                    <div class="stat-card">
                        <div class="stat-icon" style="background-color: #e6f7e6;">
                            <i class="bi bi-cash-coin" style="color: #00b300;"></i>
                        </div>
                        <div class="stat-content">
                            <h6>Daily Revenue</h6>
                            <h3><?php echo formatCurrency($stats['daily_revenue']); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-lg-3 mb-3 mb-lg-0">
                    <div class="stat-card h-100">
                        <div class="stat-icon" style="background-color: #f5e7ff;">
                            <i class="bi bi-collection" style="color: #7700cc;"></i>
                        </div>
                        <div class="stat-content w-100">
                            <h6>Order Breakdown</h6>
                            <div class="d-flex flex-column flex-md-row justify-content-between mt-2 gap-2">
                                <div class="text-md-start text-center">
                                    <small class="text-muted d-block">Walk-In</small>
                                    <h4 class="mb-0"><?php echo $stats['walk_in_percent']; ?>%</h4>
                                    <small class="text-muted d-block"><?php echo number_format($stats['walk_in_total']); ?> total</small>
                                </div>
                                <div class="text-md-end text-center">
                                    <small class="text-muted d-block">Reservations</small>
                                    <h4 class="mb-0"><?php echo $stats['reservation_percent']; ?>%</h4>
                                    <small class="text-muted d-block"><?php echo number_format($stats['reservation_total']); ?> total</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Extended Revenue Cards -->
            <div class="row mb-4">
                <div class="col-12 col-sm-6 col-lg-4 mb-3 mb-lg-0">
                    <div class="stat-card">
                        <div class="stat-icon" style="background-color:#e3f2fd;">
                            <i class="bi bi-calendar-week" style="color:#0d6efd;"></i>
                        </div>
                        <div class="stat-content">
                            <h6>Week Revenue</h6>
                            <h3><?php echo formatCurrency($stats['week_revenue']); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-lg-4 mb-3 mb-lg-0">
                    <div class="stat-card">
                        <div class="stat-icon" style="background-color:#fff3e0;display:flex;align-items:center;justify-content:center;">
                            <span class="month-label"><?php echo strtoupper(date('M')); ?></span>
                        </div>
                        <div class="stat-content">
                            <h6>Month Revenue</h6>
                            <h3><?php echo formatCurrency($stats['month_revenue']); ?></h3>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-lg-4 mb-3 mb-lg-0">
                    <div class="stat-card">
                        <div class="stat-icon" style="background-color:#e8f5e9;">
                            <i class="bi bi-bar-chart-line" style="color:#2e7d32;"></i>
                        </div>
                        <div class="stat-content">
                            <h6>Year Revenue</h6>
                            <h3><?php echo formatCurrency($stats['year_revenue']); ?></h3>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Order Distribution -->
            <div class="row g-3 order-metrics-row mb-4">
                <?php
                $timeframes = [
                    'today' => "Today's Orders",
                    'week' => 'This Week',
                    'month' => 'This Month',
                    'year' => 'This Year'
                ];
                $exclusiveTotal = (int)($orderTimeframes['exclusive_total'] ?? 0);
                $totalSummary = $exclusiveTotal > 0
                    ? 'of ' . number_format($exclusiveTotal) . ' orders this year'
                    : 'No orders recorded yet';
                foreach ($timeframes as $key => $label):
                    $count = (int)($orderTimeframes[$key] ?? 0);
                    $percentKey = $key . '_percent';
                    $percent = isset($orderTimeframes[$percentKey]) ? $orderTimeframes[$percentKey] : 0;
                ?>
                <div class="col-md-3 col-sm-6">
                    <div class="mini-stat-card">
                        <small class="label"><?php echo $label; ?></small>
                        <div class="d-flex align-items-baseline justify-content-between mt-1">
                            <h3 class="mb-0"><?php echo number_format($count); ?></h3>
                            <span class="percent"><?php echo $percent; ?>%</span>
                        </div>
                        <small class="text-muted"><?php echo $totalSummary; ?></small>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Order Percentage Chart -->
            <div class="card border-0 shadow-sm mb-4" style="background:#dff3ff;">
                <div class="card-body py-3">
                    <h5 class="fw-semibold mb-3">Order Share by Timeframe</h5>
                    <div style="height: 170px;">
                        <canvas id="orderPercentChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Recent Orders -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Recent Orders</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Reference</th>
                                    <th>Customer</th>
                                    <th>Type</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Schedule</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($recentEntries)): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted">No recent activity yet.</td>
                                </tr>
                                <?php endif; ?>
                                <?php foreach ($recentEntries as $entry): ?>
                                <?php
                                    $isOrder = $entry['record_type'] === 'order';
                                    $amount = isset($entry['amount']) ? formatCurrency($entry['amount']) : formatCurrency(0);
                                    $schedule = $entry['schedule'] ? date('M d, Y H:i', strtotime($entry['schedule'])) : '—';
                                    $typeBadge = $isOrder ? '<span class="badge bg-primary">Walk-In</span>' : '<span class="badge bg-info">Reservation</span>';
                                    $actionUrl = $isOrder ? "walk_in_orders.php?edit=" . $entry['id'] : "reservations.php?view=" . $entry['id'];
                                ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($entry['reference']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($entry['customer_name']); ?></td>
                                    <td><?php echo $typeBadge; ?></td>
                                    <td><?php echo $amount; ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo getStatusBadge($entry['status']); ?>">
                                            <?php echo ucfirst(str_replace('_', ' ', $entry['status'])); ?>
                                        </span>
                                    </td>
                                    <td><?php echo $schedule; ?></td>
                                    <td>
                                        <a href="<?php echo $actionUrl; ?>" class="btn btn-sm btn-info">View</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- small helper script, include once per page or in a shared footer -->
    <script>
        (function () {
            var toggles = document.querySelectorAll('[data-sidebar-toggle]');
            if (!toggles.length) return;

            function openSidebar() {
                document.body.classList.remove('sidebar-collapsed');
                document.body.classList.add('sidebar-open');
            }

            function closeSidebar() {
                document.body.classList.add('sidebar-collapsed');
                document.body.classList.remove('sidebar-open');
            }

            function toggleSidebar() {
                if (document.body.classList.contains('sidebar-collapsed')) {
                    openSidebar();
                } else {
                    closeSidebar();
                }
            }

            toggles.forEach(function (btn) {
                btn.addEventListener('click', function (e) {
                    e.preventDefault();
                    toggleSidebar();
                });
            });

            // Close sidebar when resizing to desktop
            window.addEventListener('resize', function () {
                if (window.innerWidth >= 993) {
                    document.body.classList.remove('sidebar-collapsed', 'sidebar-open');
                } else {
                    // keep it collapsed by default on smaller screens
                    document.body.classList.add('sidebar-collapsed');
                }
            });
        })();
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        (function(){
            const ctx = document.getElementById('orderPercentChart');
            if (!ctx) return;
            const labels = <?php echo json_encode(['Today', 'This Week', 'This Month', 'This Year']); ?>;
            const data = <?php echo json_encode([
                (float)($orderTimeframes['today_percent'] ?? 0),
                (float)($orderTimeframes['week_percent'] ?? 0),
                (float)($orderTimeframes['month_percent'] ?? 0),
                (float)($orderTimeframes['year_percent'] ?? 0)
            ]); ?>;

            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels,
                    datasets: [{
                        label: '% of total orders',
                        data,
                        backgroundColor: '#1d4ed8',
                        borderRadius: 4,
                        borderSkipped: false
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            max: 80,
                            ticks: {
                                callback: value => value + '%',
                                font: { size: 11 }
                            },
                            grid: { color: 'rgba(29,78,216,0.1)' }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { font: { size: 11 } }
                        }
                    },
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: ctx => ctx.parsed.y.toFixed(1) + '%'
                            }
                        }
                    }
                }
            });
        })();
    </script>
</body>
</html>

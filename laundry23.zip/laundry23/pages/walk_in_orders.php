<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

$services = getServices($conn);
$edit_order = null;
$order_items = [];
$payments = [];

if (isset($_GET['edit'])) {
    $order_id = (int)$_GET['edit'];
    // Modified: join customers to fetch name/phone/email for display
    $edit_order = $conn->query("SELECT o.*, c.first_name AS customer_first_name, c.last_name AS customer_last_name, c.phone AS customer_phone, c.email AS customer_email
                                 FROM orders o
                                 LEFT JOIN customers c ON o.customer_id = c.id
                                 WHERE o.id = $order_id")->fetch_assoc();
    $order_items = $conn->query("SELECT oi.*, s.name FROM order_items oi JOIN services s ON oi.service_id = s.id WHERE oi.order_id = $order_id")->fetch_all(MYSQLI_ASSOC);
    $payments = $conn->query("SELECT * FROM payments WHERE order_id = $order_id")->fetch_all(MYSQLI_ASSOC);
}

$settings = include '../includes/settings.php';
if (!is_array($settings)) {
    $settings = [
        'site_name' => 'Laundry Co.',
        'logo' => '',
        'sidebar_color' => '#667eea',
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo 'Walk-In Orders - ' . htmlspecialchars($settings['site_name'] ?? 'Laundry Co. POS'); ?></title>
    <?php
    $logoRaw = $settings['logo'] ?? '';
    $detect = preg_replace('#^\.\./(uploads/.*)$#','$1',$logoRaw);
    $absLogo = $detect ? realpath(__DIR__ . '/../' . ltrim(str_replace(['../','./'],'', $detect), '/')) : false;
    if (!$absLogo || !is_file($absLogo)) {
        $dir = realpath(__DIR__ . '/../uploads');
        if ($dir) { $c = glob($dir.'/logo_*.*'); if($c){ usort($c, fn($a,$b)=>filemtime($b)<=>filemtime($a)); $absLogo=$c[0]; $logoRaw='../uploads/'.basename($absLogo); } }
    }
    $faviconPath = ($absLogo && is_file($absLogo)) ? $logoRaw : '../uploads/wash_and_fold.jpg';
    if ($absLogo && is_file($absLogo)) { $mt=@filemtime($absLogo); if($mt){ $faviconPath .= (strpos($faviconPath,'?')===false?'?v=':'&v=').$mt; } }
    ?>
    <link rel="icon" type="image/png" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link rel="apple-touch-icon" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        body > .d-flex > nav.sidebar {
            background-color: <?php echo $settings['sidebar_color']; ?> !important;
            background-image: none !important;
        }
        /* Mobile & tablet: title left, action button right */
        @media (max-width: 991.98px) {
            .page-header {
                flex-direction: row;
                align-items: center;
            }
            .page-header h1 {
                margin-bottom: 0;
            }
            .page-header > *:last-child {
                margin-left: auto;
            }
        }
    </style>
</head>
<body class="app-shell sidebar-collapsed">
    <div class="d-flex">
        <!-- Sidebar -->
        <nav class="sidebar">
            <button type="button" class="sidebar-close-btn" data-sidebar-toggle aria-label="Close navigation">
                &times;
            </button>

            <div class="sidebar-header text-center">
                <?php if (!empty($settings['logo'])): ?>
                    <img src="<?php echo $settings['logo']; ?>" alt="Logo" class="img-thumbnail rounded-circle mx-auto d-block" style="width: 120px; height: 120px; object-fit: cover; background: #fff;">
                <?php endif; ?>
                <h5 class="mt-2 mb-0" style="font-weight: bold; text-align: center; width: 100%;"><?php echo $settings['site_name']; ?></h5>
            </div>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="walk_in_orders.php"><i class="bi bi-bag-check"></i> Walk-In Orders</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="reservations.php"><i class="bi bi-calendar-check"></i> Reservations</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="services.php"><i class="bi bi-list-ul"></i> Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="customers.php"><i class="bi bi-clock-history"></i> Order History</a>
                </li>
                <?php if ($auth->isAdmin()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="settings.php"><i class="bi bi-gear"></i> Settings</a>
                </li>
                <?php endif; ?>
            </ul>
            <div class="sidebar-footer">
                <a href="../includes/logout.php" class="btn btn-sm btn-danger w-100">Logout</a>
            </div>
        </nav>

        <!-- Backdrop for mobile / tablet when menu is open -->
        <div class="sidebar-backdrop" data-sidebar-toggle></div>

        <!-- Main Content -->
        <main class="main-content app-main">
            <!-- Mobile / tablet top bar with hamburger -->
            <div class="topbar">
                <button class="sidebar-toggle-btn" type="button" data-sidebar-toggle aria-label="Toggle navigation">
                    <span></span>
                </button>
                <h2 class="topbar-title">
                    <span>Walk-In Orders</span>
                </h2>
            </div>
                    <br>
            <header class="page-header">
                <h1>Walk-In Orders</h1>
                <?php if (!$edit_order): ?>
                <button class="btn btn-primary" id="newOrderBtn"><i class="bi bi-plus-circle"></i> New Order</button>
                <?php else: ?>
                <a href="walk_in_orders.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Back</a>
                <?php endif; ?>
            </header>

            <?php if (!$edit_order): ?>
                <!-- Kanban Columns -->
                <div class="row mb-3">
                    <div class="col-md-3">
                        <input id="searchInput" class="form-control" placeholder="Search name, phone, or reservation #">
                    </div>
                    <div class="col-md-2">
                        <input id="dateFrom" type="date" class="form-control" placeholder="From">
                    </div>
                    <div class="col-md-2">
                        <input id="dateTo" type="date" class="form-control" placeholder="To">
                    </div>
                    <div class="col-md-2">
                        <select id="statusFilter" class="form-select">
                            <option value="">All Status</option>
                            <option value="pending">Pending</option>
                            <option value="processing">Processing</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select id="serviceFilter" class="form-select">
                            <option value="">All Services</option>
                            <?php foreach ($services as $svc): ?>
                                <option value="<?php echo $svc['id']; ?>"><?php echo htmlspecialchars($svc['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="kanban-board">
                    <div class="kanban-column" id="pendingColumn">
                        <div class="kanban-column-header">Pending <span class="count" id="pendingCount">0</span></div>
                        <div class="kanban-column-body" id="pendingBody"></div>
                    </div>

                    <div class="kanban-column" id="processingColumn">
                        <div class="kanban-column-header">Processing <span class="count" id="processingCount">0</span></div>
                        <div class="kanban-column-body" id="processingBody"></div>
                    </div>

                    <div class="kanban-column" id="completedColumn">
                        <div class="kanban-column-header">Completed <span class="count" id="completedCount">0</span></div>
                        <div class="kanban-column-body" id="completedBody"></div>
                    </div>

                    <div class="kanban-column" id="cancelledColumn">
                        <div class="kanban-column-header">Cancelled <span class="count" id="cancelledCount">0</span></div>
                        <div class="kanban-column-body" id="cancelledBody"></div>
                    </div>
                </div>
            <?php else: ?>
                <!-- Order Details View (matched formatting to Reservations page) -->
                <div class="row">
                    <div class="col-md-8">
                        <div class="card mb-3">
                            <div class="card-header">
                                <h5>Order Details</h5>
                            </div>
                            <div class="card-body">
                                <p><strong>Order #:</strong> <?php echo htmlspecialchars($edit_order['order_number']); ?></p>
                                <p><strong>Status:</strong> <span class="badge bg-<?php echo getStatusBadge($edit_order['status']); ?>"><?php echo ucfirst(str_replace('_', ' ', $edit_order['status'])); ?></span></p>
                                <p><strong>Estimated Cost:</strong> <span id="orderEstimatedCost"><?php echo formatCurrency($edit_order['total_amount']); ?></span></p>
                                <p><strong>Date/Time:</strong> <?php echo date('M d, Y h:i A', strtotime($edit_order['due_date'])); ?></p>
                                <p>
                                    <a class="btn btn-sm btn-outline-secondary" href="receipt.php?type=order&id=<?php echo (int)$edit_order['id']; ?>&print=1" target="_blank">
                                        <i class="bi bi-printer"></i> Print Receipt
                                    </a>
                                    <a class="btn btn-sm btn-outline-success ms-2" href="#" id="mobilePrintBtn"><i class="bi bi-phone"></i> Print (Phone/Tablet)</a>
                                </p>
                                <script>
                                // Improved RawBT mobile printing for walk-in order
                                (function(){
                                    function buildEscPos(){
                                        var lines = [];
                                        lines.push('<?php echo addslashes($settings['site_name']); ?>');
                                        lines.push('Order Receipt');
                                        lines.push('-----------------------------');
                                        lines.push('Order #: <?php echo addslashes($edit_order['order_number']); ?>');
                                        var custName = '<?php echo addslashes(trim(($edit_order['customer_first_name'] ?? '').' '.($edit_order['customer_last_name'] ?? ''))); ?>';
                                        if (custName.trim()) lines.push('Customer: ' + custName);
                                        <?php if(!empty($edit_order['customer_email'])): ?>lines.push('Email: <?php echo addslashes($edit_order['customer_email']); ?>');<?php endif; ?>
                                        <?php if(!empty($edit_order['customer_phone'])): ?>lines.push('Phone: <?php echo addslashes($edit_order['customer_phone']); ?>');<?php endif; ?>
                                        <?php if(!empty($edit_order['due_date'])): ?>lines.push('Date/Time: <?php echo addslashes($edit_order['due_date']); ?>');<?php endif; ?>
                                        lines.push('-----------------------------');
                                        <?php if(!empty($order_items)): ?>
                                        lines.push('Items:');
                                        <?php foreach($order_items as $oi): $qty=(float)($oi['quantity']??0); $unit=(float)($oi['unit_price']??0); $sub=$qty*$unit; ?>
                                        lines.push(' <?php echo addslashes($oi['name']??'Service'); ?> <?php echo number_format($qty,2); ?>kg @PHP <?php echo number_format($unit,2); ?> = PHP <?php echo number_format($sub,2); ?>');
                                        <?php endforeach; ?>
                                        lines.push('-----------------------------');
                                        <?php endif; ?>
                                        lines.push('Total: PHP <?php echo number_format((float)$edit_order['total_amount'],2); ?>');
                                        lines.push('Paid: PHP <?php echo number_format($__paid,2); ?>');
                                        lines.push('Outstanding: PHP <?php echo number_format($__outstanding,2); ?>');
                                        <?php if(!empty($edit_order['notes'])): ?>lines.push('Note: <?php echo addslashes(preg_replace('/\s+/',' ',$edit_order['notes'])); ?>');<?php endif; ?>
                                        lines.push('-----------------------------');
                                        lines.push('Thank you!');
                                        lines.push('No refunds after 24 hours.');
                                        lines.push('Please keep this receipt.');
                                        lines.push('-----------------------------');
                                        var body = lines.join('\n');
                                        return '\x1B\x40' + body + '\n\n\n'; // init + body + feeds
                                    }
                                    function escposBytes(){
                                        var s = buildEscPos().replace(/[^\x00-\x7F]/g,'?');
                                        var a = new Uint8Array(s.length);
                                        for (var i=0;i<s.length;i++){ a[i]=s.charCodeAt(i); }
                                        return a;
                                    }
                                    function bytesToBase64(bytes){
                                        var bin=''; for(var i=0;i<bytes.length;i++){ bin += String.fromCharCode(bytes[i]); }
                                        return btoa(bin);
                                    }
                                    function mobilePrintOrder(){
                                        try {
                                            var bytes = escposBytes();
                                            var b64 = bytesToBase64(bytes);
                                            var filename = '<?php echo addslashes($edit_order['order_number']); ?>.bin';
                                            fetch('../save_receipt_bin.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ filename: filename, data: b64, no_server_print: true }) })
                                                .then(r => r.text())
                                                .then(txt => { console.log('save_receipt_bin:', txt); launchRawBT(b64); })
                                                .catch(err => { console.error(err); alert('Save failed'); });
                                        } catch(e){ console.error(e); alert('Mobile print error: '+ e); }
                                    }
                                    function launchRawBT(b64){
                                        // Use RawBT custom scheme (no querystring)
                                        var url = 'rawbt:base64,' + b64;
                                        console.log('Launching RawBT (order) length=', b64.length);
                                        var w = window.open(url,'_blank');
                                        if (!w) {
                                            // Android intent fallback if scheme is blocked by the browser
                                            var intent = 'intent:base64,' + b64 + '#Intent;scheme=rawbt;package=ru.a402d.rawbtprinter;end';
                                            window.location.href = intent;
                                        }
                                        setTimeout(function(){ console.log('If no print, open RawBT and allow USB permissions.'); }, 3000);
                                    }
                                    // Re-bind click to ensure latest handler is used
                                    document.getElementById('mobilePrintBtn')?.addEventListener('click', function(e){ e.preventDefault(); mobilePrintOrder(); });
                                })();
                                </script>
                                <hr>
                                <h6>Customer</h6>
                                <p><?php echo htmlspecialchars(trim(($edit_order['customer_first_name'] ?? '') . ' ' . ($edit_order['customer_last_name'] ?? ''))); ?></p>
                                <p><?php echo htmlspecialchars($edit_order['customer_phone'] ?? ''); ?><?php if(!empty($edit_order['customer_email'])): ?> - <?php echo htmlspecialchars($edit_order['customer_email']); ?><?php endif; ?></p>
                                <hr>
                                <h6>Service</h6>
                                <p>
                                    <?php
                                    // show first service name if available
                                    $firstItemName = isset($order_items[0]['name']) ? $order_items[0]['name'] : 'Service';
                                    echo htmlspecialchars($firstItemName);
                                    ?>
                                    — <span><?php echo formatCurrency($edit_order['total_amount']); ?></span>
                                </p>
                                <?php
                                // total weight across items (kg)
                                $total_weight = 0;
                                foreach ($order_items as $oi) { $total_weight += (float)($oi['quantity'] ?? 0); }
                                ?>
                                <p><strong>Weight:</strong> <?php echo number_format($total_weight, 2); ?> kg</p>
                                <p><strong>Note:</strong> <?php echo nl2br(htmlspecialchars($edit_order['notes'] ?? '')); ?></p>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <h5>Update Order Status</h5>
                            </div>
                            <div class="card-body">
                                <select id="statusSelect" class="form-select" data-order-id="<?php echo $edit_order['id']; ?>">
                                    <option value="pending" <?php echo $edit_order['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="processing" <?php echo $edit_order['status'] === 'processing' ? 'selected' : ''; ?>>Processing</option>
                                    <option value="completed" <?php echo ($edit_order['status'] === 'completed' || $edit_order['status'] === 'ready_for_pickup') ? 'selected' : ''; ?>>Completed</option>
                                    <option value="cancelled" <?php echo $edit_order['status'] === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                                <button class="btn btn-primary mt-2" id="updateStatusBtn">Update Status</button>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">Payments</h5>
                                <?php
                                $paid_amount = 0;
                                foreach ($payments as $payment) { $paid_amount += (float)$payment['amount']; }
                                $outstanding = max(0, (float)$edit_order['total_amount'] - $paid_amount);
                                $pay_status = $outstanding <= 0 ? 'paid' : ($paid_amount > 0 ? 'partial' : 'unpaid');
                                $pay_badge = $outstanding <= 0 ? 'success' : ($paid_amount > 0 ? 'warning' : 'danger');
                                ?>
                                <span id="paymentStatusBadge" class="badge bg-<?php echo $pay_badge; ?>"><?php echo ucfirst($pay_status); ?></span>
                            </div>
                            <div class="card-body">
                                <p><strong>Total:</strong> <span><?php echo formatCurrency($edit_order['total_amount']); ?></span></p>
                                <p><strong>Paid:</strong> <span id="paidAmountValue"><?php echo formatCurrency($paid_amount); ?></span></p>
                                <p><strong>Outstanding:</strong> <span id="outstandingAmountValue"><?php echo formatCurrency($outstanding); ?></span></p>

                                <?php if (!empty($order_items)): ?>
                                <div class="border rounded-3 p-2 mb-3 bg-light">
                                    <small class="text-muted d-block">Pricing breakdown</small>
                                    <?php
                                    $computed_total = 0;
                                    foreach ($order_items as $oi):
                                        $qty = isset($oi['quantity']) ? (float)$oi['quantity'] : 0;
                                        $unit = isset($oi['unit_price']) ? (float)$oi['unit_price'] : 0;
                                        $sub = $qty * $unit;
                                        $computed_total += $sub;
                                    ?>
                                    <div class="d-flex justify-content-between small">
                                        <span><?php echo htmlspecialchars($oi['name'] ?? 'Service'); ?> — <?php echo formatCurrency($unit); ?>/kg × <?php echo number_format($qty, 2); ?>kg</span>
                                        <strong><?php echo formatCurrency($sub); ?></strong>
                                    </div>
                                    <?php endforeach; ?>
                                    <div class="d-flex justify-content-between small border-top pt-1 mt-1">
                                        <span>Total</span>
                                        <strong><?php echo formatCurrency($computed_total); ?></strong>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <hr>
                                <h6>Payment History:</h6>
                                <?php if (count($payments) > 0): ?>
                                    <?php foreach ($payments as $payment): ?>
                                    <p class="mb-1">
                                        <small>
                                            <?php echo date('M d, Y h:i A', strtotime($payment['payment_date'])); ?> -
                                            <?php echo formatCurrency($payment['amount']); ?>
                                            (<?php echo ucfirst($payment['payment_method']); ?>)
                                        </small>
                                    </p>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p><small class="text-muted">No payments recorded</small></p>
                                <?php endif; ?>

                                <hr>
                                <form id="paymentForm" data-order-id="<?php echo $edit_order['id']; ?>">
                                    <div class="mb-2">
                                        <label class="form-label">Amount</label>
                                        <input type="number" class="form-control" name="amount" step="0.01" min="0.01" required>
                                    </div>
                                    <div class="mb-2">
                                        <label class="form-label">Method</label>
                                        <select class="form-select" name="payment_method">
                                            <option value="cash">Cash</option>
                                            <option value="card">Card</option>
                                            <option value="online">Online</option>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn btn-success w-100">Record Payment</button>
                                </form>
                                <script>
                                (function(){
                                    var badge = document.getElementById('paymentStatusBadge');
                                    var form = document.getElementById('paymentForm');
                                    if(badge && form && badge.textContent.trim().toLowerCase()==='paid'){
                                        form.style.display='none';
                                    }
                                })();
                                </script>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
    </main>
    </div>

    <!-- New Order Modal -->
    <div class="modal fade" id="newOrderModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Create New Order</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="newOrderForm">
                        <h6>Customer Information</h6>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">First Name</label>
                                <input type="text" class="form-control" name="first_name" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Last Name</label>
                                <input type="text" class="form-control" name="last_name" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Phone</label>
                                <input type="tel" class="form-control" name="phone" required inputmode="numeric" pattern="[0-9]*" maxlength="11" autocomplete="tel" placeholder="09xxxxxxxxx">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Email</label>
                                <input type="email" class="form-control" name="email">
                            </div>
                        </div>

                        <hr>
                        <h6>Order Items</h6>
                        <div id="itemsContainer">
                            <div class="order-item mb-3">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label class="form-label">Service</label>
                                        <select class="form-select service-select" name="service_id" required>
                                            <option value="">Select Service</option>
                                            <?php foreach ($services as $service): ?>
                                            <option value="<?php echo $service['id']; ?>" data-price="<?php echo $service['base_price']; ?>">
                                                <?php echo $service['name']; ?> - <?php echo formatCurrency($service['base_price']); ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label">Weight (kg)</label>
                                        <input type="number" class="form-control quantity" name="quantity" value="1" min="1" required>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label">Unit Price</label>
                                        <input type="number" class="form-control unit-price" name="unit_price" step="0.01" readonly>
                                    </div>
                                </div>
                                <button type="button" class="btn btn-sm btn-danger mt-2 remove-item">Remove</button>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notes</label>
                            <textarea class="form-control" name="notes" rows="2"></textarea>
                        </div>

                        <hr>
                        
                        <!-- Order Summary Preview -->
                        <div id="orderSummary" class="card bg-light mb-3" style="display:none;">
                            <div class="card-body">
                                <h6 class="card-title mb-3">Order Summary</h6>
                                <div class="row mb-2">
                                    <div class="col-6"><small><strong>Customer:</strong></small></div>
                                    <div class="col-6"><small id="summaryCustomer">-</small></div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-6"><small><strong>Phone:</strong></small></div>
                                    <div class="col-6"><small id="summaryPhone">-</small></div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-6"><small><strong>Kg:</strong></small></div>
                                    <div class="col-6"><small id="summaryItems">0</small></div>
                                </div>
                                <hr class="my-2">
                                <div class="row">
                                    <div class="col-6"><strong>Total:</strong></div>
                                    <div class="col-6"><strong id="summaryTotal">₱0.00</strong></div>
                                </div>
                            </div>
                        </div>

                        <h6>Total: <span id="totalAmount">₱0.00</span></h6>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="submitOrderBtn">Create Order</button>
                </div>
            </div>
        </div>

                <!-- Toast container for notifications -->
                <div id="toastContainer" class="position-fixed top-0 end-0 p-3" style="z-index:1060;"></div>
    </div>

    <!-- Update Order Status Modal (new, mirrors reservations modal) -->
    <div class="modal fade" id="updateOrderStatusModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Update Order Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="updateOrderStatusForm">
                        <select id="orderStatusSelectModal" class="form-select">
                            <option value="pending">Pending</option>
                            <option value="processing">Processing</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="submitOrderStatusBtn">Update</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/walk_in_orders.js"></script>
    <script>
        (function () {
            var toggles = document.querySelectorAll('[data-sidebar-toggle]');
            if (!toggles.length) return;

            function openSidebar() {
                document.body.classList.remove('sidebar-collapsed');
                document.body.classList.add('sidebar-open');
            }

            function closeSidebar() {
                document.body.classList.add('sidebar-collapsed');
                document.body.classList.remove('sidebar-open');
            }

            function toggleSidebar() {
                if (document.body.classList.contains('sidebar-collapsed')) {
                    openSidebar();
                } else {
                    closeSidebar();
                }
            }

            toggles.forEach(function (btn) {
                btn.addEventListener('click', function (e) {
                    e.preventDefault();
                    toggleSidebar();
                });
            });

            window.addEventListener('resize', function () {
                if (window.innerWidth >= 993) {
                    document.body.classList.remove('sidebar-collapsed', 'sidebar-open');
                } else {
                    document.body.classList.add('sidebar-collapsed');
                }
            });
        })();
    </script>
    <script>
        // Enforce digits-only for all phone inputs (including modal forms)
        document.querySelectorAll('input[name="phone"]').forEach(function(el){
            el.addEventListener('input', function(){
                const cleaned = this.value.replace(/[^0-9]/g,'');
                // Optional: limit to 11 digits (PH mobile format)
                this.value = cleaned.slice(0,11);
            });
            el.addEventListener('keypress', function(e){
                if(!/[0-9]/.test(e.key)) { e.preventDefault(); }
            });
            el.addEventListener('paste', function(e){
                e.preventDefault();
                const text = (e.clipboardData || window.clipboardData).getData('text');
                const cleaned = text.replace(/[^0-9]/g,'').slice(0,11);
                this.value = cleaned;
            });
        });
        // Dev test: visit this page with ?test_toast=1 to verify toasts.
        // If our showToast helper isn't present, this will create a simple fallback popup.
        (function(){
            try {
                if (location.search.indexOf('test_toast=1') !== -1) {
                    setTimeout(function(){
                        console.log('test_toast=1: showToast typeof ->', typeof window.showToast);
                        if (typeof window.showToast === 'function') {
                            window.showToast('Toast system: OK', 'success', 3000);
                            return;
                        }

                        // Fallback: create a simple, self-dismissing DOM popup in top-right
                        const id = 'fallback-toast-' + Date.now();
                        const el = document.createElement('div');
                        el.id = id;
                        el.textContent = 'Toast fallback: OK';
                        el.style.position = 'fixed';
                        el.style.top = '16px';
                        el.style.right = '16px';
                        el.style.background = '#0d6efd';
                        el.style.color = '#fff';
                        el.style.padding = '12px 16px';
                        el.style.borderRadius = '8px';
                        el.style.boxShadow = '0 4px 20px rgba(0,0,0,0.15)';
                        el.style.zIndex = 99999;
                        el.style.fontFamily = 'system-ui, Arial, sans-serif';
                        document.body.appendChild(el);
                        setTimeout(() => { el.style.transition = 'opacity 300ms'; el.style.opacity = '0'; setTimeout(()=>el.remove(), 350); }, 2600);
                        console.log('Fallback toast injected.');
                    }, 300);
                }
            } catch (e) { console.error('toast test error', e); }
        })();
    </script>
</body>
</html>

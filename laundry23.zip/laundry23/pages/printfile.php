<?php
// This script runs PrintFile to print the .bin file automatically
// Usage: POST { "path": "C:\\Users\\PC\\Downloads\\receipt.bin" }

$input = json_decode(file_get_contents('php://input'), true);
$binFile = isset($input['path']) ? $input['path'] : '';
$printFileExe = 'C:\xampp1\htdocs\print\prfile32.exe';

if ($binFile && file_exists($binFile)) {
    shell_exec('"' . $printFileExe . '" /p "' . $binFile . '"');
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'File not found']);
}
<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

$settings = include '../includes/settings.php';
if (!is_array($settings)) {
    $settings = [
        'site_name' => 'Laundry Co.',
        'logo' => '',
        'sidebar_color' => '#667eea',
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo 'Service Management - ' . htmlspecialchars($settings['site_name'] ?? 'Laundry Co.'); ?></title>
    <?php
    $logoRaw = $settings['logo'] ?? '';
    $detect = preg_replace('#^\.\./(uploads/.*)$#','$1',$logoRaw);
    $absLogo = $detect ? realpath(__DIR__ . '/../' . ltrim(str_replace(['../','./'],'', $detect), '/')) : false;
    if (!$absLogo || !is_file($absLogo)) {
        $dir = realpath(__DIR__ . '/../uploads');
        if ($dir) { $cand = glob($dir.'/logo_*.*'); if($cand){ usort($cand, fn($a,$b)=>filemtime($b)<=>filemtime($a)); $absLogo=$cand[0]; $logoRaw='../uploads/'.basename($absLogo); } }
    }
    $faviconPath = ($absLogo && is_file($absLogo)) ? $logoRaw : '../uploads/wash_and_fold.jpg';
    if ($absLogo && is_file($absLogo)) { $mt=@filemtime($absLogo); if($mt){ $faviconPath .= (strpos($faviconPath,'?')===false?'?v=':'&v=').$mt; } }
    ?>
    <link rel="icon" type="image/png" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link rel="apple-touch-icon" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        body > .d-flex > nav.sidebar {
            background-color: <?php echo $settings['sidebar_color']; ?> !important;
            background-image: none !important;
        }
        .sidebar-header h5 {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        @media (max-width: 991.98px) {
            .page-header {
                flex-direction: row;
                align-items: center;
            }
            .page-header h1 {
                margin-bottom: 0;
            }
            .page-header > *:last-child {
                margin-left: auto;
            }
        }
    </style>
</head>
<body class="app-shell sidebar-collapsed">
    <div class="d-flex">
        <nav class="sidebar">
            <button type="button" class="sidebar-close-btn" data-sidebar-toggle aria-label="Close navigation">
                &times;
            </button>

            <div class="sidebar-header d-flex flex-column align-items-center justify-content-center text-center" style="width: 100%;">
                <?php if (!empty($settings['logo'])): ?>
                    <img src="<?php echo $settings['logo']; ?>" alt="Logo" class="img-thumbnail rounded-circle" style="width: 120px; height: 120px; object-fit: cover; background: #fff;">
                <?php endif; ?>
                <h5 class="mt-2 mb-0 w-100" style="font-weight: bold; text-align: center; display: flex; justify-content: center; align-items: center;"><?php echo htmlspecialchars($settings['site_name']); ?></h5>
            </div>
            <ul class="nav flex-column">
                <li class="nav-item"><a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="walk_in_orders.php"><i class="bi bi-bag-check"></i> Walk-In Orders</a></li>
                <li class="nav-item"><a class="nav-link" href="reservations.php"><i class="bi bi-calendar-check"></i> Reservations</a></li>
                <li class="nav-item"><a class="nav-link active" href="services.php"><i class="bi bi-list-ul"></i> Services</a></li>
                <li class="nav-item"><a class="nav-link" href="customers.php"><i class="bi bi-clock-history"></i> Order History</a></li>
                <?php if ($auth->isAdmin()): ?><li class="nav-item"><a class="nav-link" href="settings.php"><i class="bi bi-gear"></i> Settings</a></li><?php endif; ?>
            </ul>
            <div class="sidebar-footer"><a href="../includes/logout.php" class="btn btn-sm btn-danger w-100">Logout</a></div>
        </nav>

        <div class="sidebar-backdrop" data-sidebar-toggle></div>

        <main class="main-content app-main">
            <div class="topbar">
                <button class="sidebar-toggle-btn" type="button" data-sidebar-toggle aria-label="Toggle navigation">
                    <span></span>
                </button>
                <h2 class="topbar-title">
                    <span>Services</span>
                </h2>
            </div>
                    <br>
            <header class="page-header d-flex align-items-center">
                <h1>Service Management</h1>
                <button id="newServiceBtn" class="btn btn-primary ms-3">+ New Service</button>
            </header>

            <div class="card mt-3">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="servicesTable">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Base Price</th>
                                    <th>Price/kg</th>
                                    <th>Turnaround (hrs)</th>
                                    <th>Available</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="servicesBody"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Service Modal -->
    <div class="modal fade" id="serviceModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header"><h5 class="modal-title">Service</h5><button class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                    <form id="serviceForm">
                        <input type="hidden" name="id" id="serviceId">
                        <input type="hidden" name="delete_image" id="deleteImageFlag" value="0">
                        <div class="mb-2"><label class="form-label">Name</label><input class="form-control" name="name" id="serviceName" required></div>
                        <div class="mb-2"><label class="form-label">Description</label><textarea class="form-control" name="description" id="serviceDescription"></textarea></div>
                        <div class="row g-2">
                            <div class="col-md-4"><label class="form-label">Base Price</label><input type="number" step="0.01" class="form-control" name="base_price" id="serviceBase" required></div>
                            <div class="col-md-4"><label class="form-label">Price per kg</label><input type="number" step="0.01" class="form-control" name="price_per_kg" id="servicePerKg" required></div>
                            <div class="col-md-4"><label class="form-label">Turnaround (hrs)</label><input type="number" class="form-control" name="turnaround_hours" id="serviceTurnaround" required></div>
                        </div>
                        <div class="mt-3">
                            <label class="form-label">Service Image (optional)</label>
                            <input type="file" class="form-control" name="image" id="serviceImage" accept="image/*">
                            <div class="mt-2 d-flex align-items-center" id="serviceImagePreviewWrap">
                                <img id="serviceImagePreview" src="#" alt="Preview" class="img-thumbnail d-none" style="max-width:150px; max-height:120px; object-fit:cover;">
                                <button type="button" class="btn btn-outline-danger btn-sm ms-2 d-none" id="deleteServiceImageBtn">Delete Image</button>
                            </div>
                            <div class="form-text">Different image per service para iba-iba sa landing page.</div>
                        </div>

                        <!-- ensure a value is always sent for is_active -->
                        <input type="hidden" name="is_active" id="serviceActiveHidden" value="1">

                        <div class="form-check form-switch mt-2">
                            <input
                                class="form-check-input"
                                type="checkbox"
                                id="serviceActive"
                                checked
                            >
                            <label class="form-check-label" for="serviceActive">Available</label>
                        </div>
                    </form>
                </div>
                <div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button id="saveServiceBtn" class="btn btn-primary">Save</button></div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/services.js"></script>
    <script>
        (function () {
            var toggles = document.querySelectorAll('[data-sidebar-toggle]');
            if (!toggles.length) return;

            function openSidebar() {
                document.body.classList.remove('sidebar-collapsed');
                document.body.classList.add('sidebar-open');
            }

            function closeSidebar() {
                document.body.classList.add('sidebar-collapsed');
                document.body.classList.remove('sidebar-open');
            }

            function toggleSidebar() {
                if (document.body.classList.contains('sidebar-collapsed')) {
                    openSidebar();
                } else {
                    closeSidebar();
                }
            }

            toggles.forEach(function (btn) {
                btn.addEventListener('click', function (e) {
                    e.preventDefault();
                    toggleSidebar();
                });
            });

            window.addEventListener('resize', function () {
                if (window.innerWidth >= 993) {
                    document.body.classList.remove('sidebar-collapsed', 'sidebar-open');
                } else {
                    document.body.classList.add('sidebar-collapsed');
                }
            });
        })();

        // sync the "Available" switch with the hidden is_active input
        (function () {
            var checkbox = document.getElementById('serviceActive');
            var hidden   = document.getElementById('serviceActiveHidden');

            if (!checkbox || !hidden) return;

            function syncActive() {
                hidden.value = checkbox.checked ? '1' : '0';
            }

            checkbox.addEventListener('change', syncActive);
            // initialize on load
            syncActive();

            // optional helper if you set values from JS when editing
            window.setServiceActive = function (isActive) {
                checkbox.checked = !!Number(isActive);
                syncActive();
            };
        })();
    </script>
    <script>
    // Image preview & delete logic for service modal
    (function(){
        const input = document.getElementById('serviceImage');
        const preview = document.getElementById('serviceImagePreview');
        const delBtn = document.getElementById('deleteServiceImageBtn');
        const delFlag = document.getElementById('deleteImageFlag');
        if(!input) return;
        input.addEventListener('change', e => {
            const f = e.target.files[0];
            if (f && f.type.startsWith('image/')) {
                const r = new FileReader();
                r.onload = ev => { preview.src = ev.target.result; preview.classList.remove('d-none'); delBtn.classList.remove('d-none'); delFlag.value='0'; };
                r.readAsDataURL(f);
            }
        });
        delBtn && delBtn.addEventListener('click', () => {
            if(confirm('Remove current image?')){
                preview.src='#'; preview.classList.add('d-none'); delBtn.classList.add('d-none'); delFlag.value='1'; input.value='';
            }
        });
        // Expose hook to set existing image when editing
        window.setServiceImage = function(path){
            if(path){ preview.src = path; preview.classList.remove('d-none'); delBtn.classList.remove('d-none'); delFlag.value='0'; }
            else { preview.src='#'; preview.classList.add('d-none'); delBtn.classList.add('d-none'); delFlag.value='0'; }
        };
        // If user selects a new file after marking delete, reset delete flag
        input.addEventListener('click', () => { if (delFlag.value === '1') delFlag.value='0'; });
    })();
    </script>
</body>
</html>

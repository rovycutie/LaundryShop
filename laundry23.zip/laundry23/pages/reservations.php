<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

if (!$auth->isLoggedIn()) {
    header('Location: ../login.php');
    exit();
}

$settings = include '../includes/settings.php';
if (!is_array($settings)) {
    $settings = [
        'site_name' => 'Laundry Co.',
        'logo' => '',
        'sidebar_color' => '#667eea',
    ];
}

ensureReservationPaymentsTable($conn);

$view_reservation = null;
$reservation_payments = [];
$reservation_paid_total = 0;
if (isset($_GET['view'])) {
    $rid = (int)$_GET['view'];
    $stmt = $conn->prepare("SELECT r.*, s.name as service_name, s.base_price as service_base_price, s.price_per_kg as service_price_per_kg FROM reservations r JOIN services s ON r.service_id = s.id WHERE r.id = ?");
    $stmt->bind_param('i', $rid);
    $stmt->execute();
    $view_reservation = $stmt->get_result()->fetch_assoc();

    if ($view_reservation) {
        $payStmt = $conn->prepare("SELECT * FROM reservation_payments WHERE reservation_id = ? ORDER BY payment_date DESC");
        $payStmt->bind_param('i', $rid);
        $payStmt->execute();
        $reservation_payments = $payStmt->get_result()->fetch_all(MYSQLI_ASSOC);
        foreach ($reservation_payments as $payment) {
            $reservation_paid_total += (float)$payment['amount'];
        }
    }
}

$calculated_total = 0;
$service_base_price = 0;
$service_price_per_kg = 0;
if ($view_reservation) {
    $service_base_price = isset($view_reservation['service_base_price']) ? (float)$view_reservation['service_base_price'] : 0;
    $service_price_per_kg = isset($view_reservation['service_price_per_kg']) ? (float)$view_reservation['service_price_per_kg'] : 0;
    $weight_value = isset($view_reservation['weight_kg']) ? (float)$view_reservation['weight_kg'] : 0;
    $calculated_total = round($service_base_price + ($weight_value * $service_price_per_kg), 2);
}

$estimated_total = $calculated_total > 0 ? $calculated_total : ($view_reservation ? (float)$view_reservation['estimated_cost'] : 0);
$payment_outstanding = max(0, $estimated_total - $reservation_paid_total);
if ($estimated_total <= 0 && $reservation_paid_total <= 0) {
    $payment_status = 'unpaid';
} elseif ($payment_outstanding <= 0) {
    $payment_status = 'paid';
} else {
    $payment_status = $reservation_paid_total > 0 ? 'partial' : 'unpaid';
}
$payment_badge_class = $payment_status === 'paid' ? 'success' : ($payment_status === 'partial' ? 'warning' : 'danger');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo 'Reservations - ' . htmlspecialchars($settings['site_name'] ?? 'Laundry Co. POS'); ?></title>
    <?php
    $logoRaw = $settings['logo'] ?? '';
    $detect = preg_replace('#^\.\./(uploads/.*)$#','$1',$logoRaw);
    $absLogo = $detect ? realpath(__DIR__ . '/../' . ltrim(str_replace(['../','./'],'', $detect), '/')) : false;
    if (!$absLogo || !is_file($absLogo)) {
        $dir = realpath(__DIR__ . '/../uploads');
        if ($dir) { $c = glob($dir.'/logo_*.*'); if($c){ usort($c, fn($a,$b)=>filemtime($b)<=>filemtime($a)); $absLogo=$c[0]; $logoRaw='../uploads/'.basename($absLogo); } }
    }
    $faviconPath = ($absLogo && is_file($absLogo)) ? $logoRaw : '../uploads/wash_and_fold.jpg';
    if ($absLogo && is_file($absLogo)) { $mt=@filemtime($absLogo); if($mt){ $faviconPath .= (strpos($faviconPath,'?')===false?'?v=':'&v=').$mt; } }
    ?>
    <link rel="icon" type="image/png" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link rel="apple-touch-icon" href="<?php echo htmlspecialchars($faviconPath); ?>" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        body > .d-flex > nav.sidebar {
            background-color: <?php echo $settings['sidebar_color']; ?> !important;
            background-image: none !important;
        }
        /* removed the mobile-only .page-header overrides to undo the change */
    </style>
</head>
<body class="app-shell sidebar-collapsed">
    <div class="d-flex">
        <!-- Sidebar -->
        <nav class="sidebar">
            <button type="button" class="sidebar-close-btn" data-sidebar-toggle aria-label="Close navigation">
                &times;
            </button>

            <div class="sidebar-header text-center">
                <?php if (!empty($settings['logo'])): ?>
                    <img src="<?php echo $settings['logo']; ?>" alt="Logo" class="img-thumbnail rounded-circle mx-auto d-block" style="width: 120px; height: 120px; object-fit: cover; background: #fff;">
                <?php endif; ?>
                <h5 class="mt-2 mb-0" style="font-weight: bold; text-align: center; width: 100%;"><?php echo $settings['site_name']; ?></h5>
            </div>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="walk_in_orders.php"><i class="bi bi-bag-check"></i> Walk-In Orders</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="reservations.php"><i class="bi bi-calendar-check"></i> Reservations</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="services.php"><i class="bi bi-list-ul"></i> Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="customers.php"><i class="bi bi-clock-history"></i> Order History</a>
                </li>
                <?php if ($auth->isAdmin()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="settings.php"><i class="bi bi-gear"></i> Settings</a>
                </li>
                <?php endif; ?>
            </ul>
            <div class="sidebar-footer">
                <a href="../includes/logout.php" class="btn btn-sm btn-danger w-100">Logout</a>
            </div>
        </nav>

        <div class="sidebar-backdrop" data-sidebar-toggle></div>

        <!-- Main Content -->
        <main class="main-content app-main">
            <div class="topbar">
                <button class="sidebar-toggle-btn" type="button" data-sidebar-toggle aria-label="Toggle navigation">
                    <span></span>
                </button>
                <h2 class="topbar-title">
                    <span>Reservations</span>
                </h2>
            </div>
                    <br>    
            <header class="page-header">
                <h1>Reservations</h1>
                <?php if ($view_reservation): ?>
                    <a href="reservations.php" class="btn btn-secondary ms-3"><i class="bi bi-arrow-left"></i> Back</a>
                <?php endif; ?>
            </header>

                <div class="row mb-3">
                    <div class="col-md-3">
                        <input id="searchInput" class="form-control" placeholder="Search name, phone, or reservation #">
                    </div>
                    <div class="col-md-2">
                        <input id="dateFrom" type="date" class="form-control">
                    </div>
                    <div class="col-md-2">
                        <input id="dateTo" type="date" class="form-control">
                    </div>
                    <div class="col-md-2">
                        <select id="statusFilter" class="form-select">
                            <option value="">All Status</option>
                            <option value="pending">Pending</option>
                            <option value="processing">Processing</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select id="serviceFilter" class="form-select">
                            <option value="">All Services</option>
                            <?php foreach ($services as $svc): ?>
                                <option value="<?php echo $svc['id']; ?>"><?php echo htmlspecialchars($svc['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

            <?php if (!$view_reservation): ?>
            <div class="kanban-board">
                <div class="kanban-column" id="pendingColumn">
                    <div class="kanban-column-header">Pending <span class="count" id="pendingCount">0</span></div>
                    <div class="kanban-column-body" id="pendingBody"></div>
                </div>

                <div class="kanban-column" id="processingColumn">
                    <div class="kanban-column-header">Processing <span class="count" id="processingCount">0</span></div>
                    <div class="kanban-column-body" id="processingBody"></div>
                </div>

                <div class="kanban-column" id="completedColumn">
                    <div class="kanban-column-header">Completed <span class="count" id="completedCount">0</span></div>
                    <div class="kanban-column-body" id="completedBody"></div>
                </div>

                <div class="kanban-column" id="cancelledColumn">
                    <div class="kanban-column-header">Cancelled <span class="count" id="cancelledCount">0</span></div>
                    <div class="kanban-column-body" id="cancelledBody"></div>
                </div>
            </div>
            <?php else: ?>
                <!-- Reservation Details View -->
                <div class="row">
                    <div class="col-md-8">
                        <div class="card mb-3">
                            <div class="card-header">
                                <h5>Reservation Details</h5>
                            </div>
                            <div class="card-body">
                                <p><strong>Reservation #:</strong> <?php echo htmlspecialchars($view_reservation['reservation_number']); ?></p>
                                <?php $display_status = ($view_reservation['status'] === 'confirmed') ? 'processing' : $view_reservation['status']; ?>
                                <p><strong>Status:</strong> <span class="badge bg-<?php echo getStatusBadge($display_status); ?>"><?php echo ucfirst(str_replace('_', ' ', $display_status)); ?></span></p>
                                <p><strong>Estimated Cost:</strong> <span id="reservationEstimatedCost"><?php echo formatCurrency($estimated_total); ?></span></p>
                                <?php 
                                $dtDisplay = null;
                                if (!empty($view_reservation['reserved_date']) && !empty($view_reservation['reserved_time'])) {
                                    $rawDT = $view_reservation['reserved_date'] . ' ' . $view_reservation['reserved_time'];
                                    $dtDisplayObj = DateTime::createFromFormat('Y-m-d H:i:s', $rawDT, new DateTimeZone('Asia/Manila'));
                                    if ($dtDisplayObj) { $dtDisplay = $dtDisplayObj->format('M d, Y h:i A'); }
                                }
                                if (!$dtDisplay) { // fallback separate formatting
                                    $datePart = !empty($view_reservation['reserved_date']) ? date('M d, Y', strtotime($view_reservation['reserved_date'])) : '';
                                    $timePart = !empty($view_reservation['reserved_time']) ? date('h:i A', strtotime($view_reservation['reserved_time'])) : '';
                                    $dtDisplay = trim($datePart . ' ' . $timePart);
                                }
                                ?>
                                <p><strong>Date/Time:</strong> <?php echo htmlspecialchars($dtDisplay); ?></p>
                                <p>
                                    <a class="btn btn-sm btn-outline-secondary" href="receipt.php?type=reservation&id=<?php echo (int)$view_reservation['id']; ?>&print=1" target="_blank">
                                        <i class="bi bi-printer"></i> Print Receipt
                                    </a>
                                    <a class="btn btn-sm btn-outline-success ms-2" href="#" id="mobilePrintBtn">
                                        <i class="bi bi-phone"></i> Print (Phone/Tablet)
                                    </a>
                                </p>
                                <hr>
                                <h6>Customer</h6>
                                <p><?php echo htmlspecialchars($view_reservation['first_name'] . ' ' . $view_reservation['last_name']); ?></p>
                                <p><?php echo htmlspecialchars($view_reservation['phone']); ?> <?php if($view_reservation['email']): ?> - <?php echo htmlspecialchars($view_reservation['email']); ?><?php endif; ?></p>
                                <hr>
                                <h6>Service</h6>
                                <p><?php echo htmlspecialchars($view_reservation['service_name']); ?> — <span id="serviceTotalValue"><?php echo formatCurrency($estimated_total); ?></span></p>
                                <p><strong>Weight:</strong> <span id="reservationWeightValue"><?php echo htmlspecialchars($view_reservation['weight_kg']); ?></span> kg</p>
                                <p><strong>Special Requests:</strong> <?php echo nl2br(htmlspecialchars($view_reservation['special_requests'])); ?></p>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <h5>Update Reservation Status</h5>
                            </div>
                            <div class="card-body">
                                <select id="statusSelect" class="form-select" data-reservation-id="<?php echo $view_reservation['id']; ?>">
                                    <option value="pending" <?php echo $view_reservation['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="processing" <?php echo ($view_reservation['status'] === 'processing' || $view_reservation['status'] === 'confirmed') ? 'selected' : ''; ?>>Processing</option>
                                    <option value="completed" <?php echo $view_reservation['status'] === 'completed' ? 'selected' : ''; ?>>Completed</option>
                                    <option value="cancelled" <?php echo $view_reservation['status'] === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                                <button class="btn btn-primary mt-2" id="updateReservationStatusBtn">Update Status</button>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">Payments</h5>
                                <span id="reservationPaymentStatusBadge" class="badge bg-<?php echo $payment_badge_class; ?>">
                                    <?php echo ucfirst($payment_status); ?>
                                </span>
                            </div>
                            <div class="card-body">
                                <p><strong>Estimated Total:</strong> <span id="estimatedTotalValue"><?php echo formatCurrency($estimated_total); ?></span></p>
                                <p><strong>Paid:</strong> <span id="reservationPaidAmountValue"><?php echo formatCurrency($reservation_paid_total); ?></span></p>
                                <p><strong>Outstanding:</strong> <span id="reservationOutstandingAmountValue"><?php echo formatCurrency($payment_outstanding); ?></span></p>
                                <?php if ($service_base_price > 0 || $service_price_per_kg > 0): ?>
                                <div class="border rounded-3 p-2 mb-3 bg-light">
                                    <small class="text-muted d-block">Pricing breakdown</small>
                                    <div class="d-flex justify-content-between small">
                                        <span>Base fee</span>
                                        <strong id="pricingBaseValue"><?php echo formatCurrency($service_base_price); ?></strong>
                                    </div>
                                    <?php if ($service_price_per_kg > 0): ?>
                                    <div class="d-flex justify-content-between small">
                                        <span id="pricingPerKgLabel"><?php echo formatCurrency($service_price_per_kg); ?>/kg × <?php echo htmlspecialchars($view_reservation['weight_kg']); ?>kg</span>
                                        <strong id="pricingPerKgValue"><?php echo formatCurrency($service_price_per_kg * (float)$view_reservation['weight_kg']); ?></strong>
                                    </div>
                                    <?php endif; ?>
                                    <div class="d-flex justify-content-between small border-top pt-1 mt-1">
                                        <span>Total</span>
                                        <strong id="pricingTotalValue"><?php echo formatCurrency($estimated_total); ?></strong>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <hr>
                                <h6>Payment History:</h6>
                                <?php if (count($reservation_payments) > 0): ?>
                                    <?php foreach ($reservation_payments as $payment): ?>
                                        <p class="mb-1">
                                            <small>
                                                <?php echo date('M d, Y h:i A', strtotime($payment['payment_date'])); ?> -
                                                <?php echo formatCurrency($payment['amount']); ?>
                                                (<?php echo ucfirst($payment['payment_method']); ?>)
                                                <?php if (!empty($payment['notes'])): ?>
                                                    — <?php echo htmlspecialchars($payment['notes']); ?>
                                                <?php endif; ?>
                                            </small>
                                        </p>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p><small class="text-muted">No payments recorded</small></p>
                                <?php endif; ?>

                                <hr>
                                  <form id="reservationPaymentForm"
                                      data-reservation-id="<?php echo $view_reservation['id']; ?>"
                                      data-base-price="<?php echo $service_base_price; ?>"
                                      data-price-per-kg="<?php echo $service_price_per_kg; ?>"
                                      data-paid-total="<?php echo $reservation_paid_total; ?>"
                                      data-initial-total="<?php echo $estimated_total; ?>"
                                      data-initial-weight="<?php echo htmlspecialchars($view_reservation['weight_kg']); ?>">
                                    <div class="mb-2">
                                        <label class="form-label">Actual Weight (kg)</label>
                                        <input type="number" class="form-control" name="weight_kg" step="0.01" min="0" value="<?php echo htmlspecialchars($view_reservation['weight_kg']); ?>">
                                        <small class="text-muted">Update if the final weight differs from the reservation.</small>
                                    </div>
                                    <div class="mb-2">
                                        <label class="form-label">Amount</label>
                                        <input type="number" class="form-control" name="amount" step="0.01" min="0.01" value="<?php echo $payment_outstanding > 0 ? number_format($payment_outstanding, 2, '.', '') : ''; ?>" required>
                                    </div>
                                    <div class="mb-2">
                                        <label class="form-label">Method</label>
                                        <select class="form-select" name="payment_method">
                                            <option value="cash">Cash</option>
                                            <option value="card">Card</option>
                                            <option value="online">Online</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Notes <span class="text-muted" style="font-weight: normal;">(optional)</span></label>
                                        <textarea class="form-control" name="notes" rows="2" placeholder="Reference or remarks"></textarea>
                                    </div>
                                    <input type="hidden" name="reservation_id" value="<?php echo $view_reservation['id']; ?>">
                                    <button type="submit" class="btn btn-success w-100">Record Payment</button>
                                </form>
                                <script>
                                (function(){
                                    var badge = document.getElementById('reservationPaymentStatusBadge');
                                    var form = document.getElementById('reservationPaymentForm');
                                    if(badge && form && badge.textContent.trim().toLowerCase()==='paid'){
                                        form.style.display='none';
                                    }
                                })();
                                </script>
                                <?php if ($payment_status !== 'paid'): ?>
                                    <small class="text-muted d-block mt-2">Remaining balance updates automatically after each payment.</small>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </main>
    </div>

    <!-- Update Status Modal -->
    <div class="modal fade" id="updateStatusModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Update Reservation Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="updateStatusForm">
                        <select id="statusSelectModal" class="form-select">
                            <option value="pending">Pending</option>
                            <option value="processing">Processing</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="submitStatusBtn">Update</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/reservations.js"></script>
    <script>
        (function () {
            var toggles = document.querySelectorAll('[data-sidebar-toggle]');
            if (!toggles.length) return;

            function openSidebar() {
                document.body.classList.remove('sidebar-collapsed');
                document.body.classList.add('sidebar-open');
            }

            function closeSidebar() {
                document.body.classList.add('sidebar-collapsed');
                document.body.classList.remove('sidebar-open');
            }

            function toggleSidebar() {
                if (document.body.classList.contains('sidebar-collapsed')) {
                    openSidebar();
                } else {
                    closeSidebar();
                }
            }

            toggles.forEach(function (btn) {
                btn.addEventListener('click', function (e) {
                    e.preventDefault();
                    toggleSidebar();
                });
            });

            window.addEventListener('resize', function () {
                if (window.innerWidth >= 993) {
                    document.body.classList.remove('sidebar-collapsed', 'sidebar-open');
                } else {
                    document.body.classList.add('sidebar-collapsed');
                }
            });
        })();

        // Mobile/Tablet RawBT print for reservation detail
        (function(){
            if (!<?php echo $view_reservation ? 'true':'false'; ?>) return;
            function buildEscPos(){
                var lines = [];
                lines.push('<?php echo addslashes($settings['site_name']); ?>');
                lines.push('Reservation Receipt');
                lines.push('-----------------------------');
                lines.push('Reservation #: <?php echo addslashes($view_reservation['reservation_number']); ?>');
                lines.push('Customer: <?php echo addslashes(trim($view_reservation['first_name'].' '.$view_reservation['last_name'])); ?>');
                <?php if(!empty($view_reservation['email'])): ?>lines.push('Email: <?php echo addslashes($view_reservation['email']); ?>');<?php endif; ?>
                lines.push('Phone: <?php echo addslashes($view_reservation['phone']); ?>');
                <?php if(!empty($view_reservation['reserved_date']) && !empty($view_reservation['reserved_time'])): ?>lines.push('Date/Time: <?php echo addslashes($view_reservation['reserved_date'].' '.$view_reservation['reserved_time']); ?>');<?php endif; ?>
                lines.push('-----------------------------');
                lines.push('Service: <?php echo addslashes($view_reservation['service_name']); ?>');
                lines.push('Weight: <?php echo addslashes($view_reservation['weight_kg']); ?> kg');
                lines.push('Estimated: PHP <?php echo number_format((float)$estimated_total,2); ?>');
                lines.push('Paid: PHP <?php echo number_format((float)$reservation_paid_total,2); ?>');
                lines.push('Outstanding: PHP <?php echo number_format((float)$payment_outstanding,2); ?>');
                <?php if(!empty($view_reservation['special_requests'])): ?>lines.push('Requests: <?php echo addslashes(preg_replace('/\s+/',' ',$view_reservation['special_requests'])); ?>');<?php endif; ?>
                lines.push('-----------------------------');
                lines.push('Thank you!');
                lines.push('No refunds after 24 hours.');
                lines.push('Please keep this receipt.');
                lines.push('-----------------------------');
                // Join + ensure ASCII only
                var body = lines.join('\n');
                // ESC/POS init + body + feeds (no cut for simple 58mm auto tear)
                return '\x1B\x40' + body + '\n\n\n';
            }
            function escposBytes(){
                var escposStr = buildEscPos();
                // Replace any non-ASCII quickly (peso sign etc.)
                escposStr = escposStr.replace(/[^\x00-\x7F]/g, '?');
                var arr = new Uint8Array(escposStr.length);
                for (var i=0;i<escposStr.length;i++){ arr[i] = escposStr.charCodeAt(i); }
                return arr;
            }
            function bytesToBase64(bytes){
                var bin='';
                for(var i=0;i<bytes.length;i++){ bin += String.fromCharCode(bytes[i]); }
                return btoa(bin);
            }
            function mobilePrintReservation(){
                try {
                    var bytes = escposBytes();
                    var b64 = bytesToBase64(bytes);
                    var filename = '<?php echo addslashes($view_reservation['reservation_number']); ?>.bin';
                    fetch('../save_receipt_bin.php', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ filename: filename, data: b64, no_server_print: true }) })
                        .then(r => r.text())
                        .then(txt => { console.log('save_receipt_bin:', txt); launchRawBT(b64); })
                        .catch(err => { console.error(err); alert('Save failed'); });
                } catch(e){ console.error(e); alert('Mobile print error: '+ e); }
            }
            function launchRawBT(b64){
                // Correct RawBT URI scheme uses single-colon form: rawbt:base64,<DATA>
                var url = 'rawbt:base64,' + b64;
                console.log('Launching RawBT (reservation) length=', b64.length);
                var w = window.open(url, '_blank');
                if (!w) {
                    // Android intent fallback
                    var intent = 'intent:base64,' + b64 + '#Intent;scheme=rawbt;package=ru.a402d.rawbtprinter;end';
                    window.location.href = intent;
                }
                setTimeout(function(){ console.log('If no print, install/open RawBT and allow USB.'); }, 3000);
            }
            // Re-bind click (in case earlier version attached different handler)
            var btn = document.getElementById('mobilePrintBtn');
            if (btn){
                btn.addEventListener('click', function(e){ e.preventDefault(); try{ mobilePrintReservation(); }catch(err){ console.error(err); } }, { once:false });
            }
        })();
    </script>
    <script src="../js/sidebar.js"></script>
</body>
</html>